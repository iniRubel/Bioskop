<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class film_mod extends CI_Model{
	public function __construct() {
        $this->load->database();
        
    }

    public function count_table(){
    	$query = $this->db->query("select * from film;");
		return count ($query->result_array());
    }

	public function get_all(){
		$query = $this->db->query("select * from film order by id_film;");
		return $query->result_array();
	}

	public function get_nRow($n){
		$query = $this->db->query("select * from film order by id_film desc limit ".$n.";");
		return $query->result_array();
	}

	public function search($title){
		$query = $this->db->query("select * from film where judul like '%".$title."%';");
		return $query->result_array();
	}

	public function tambah_film($film){
		return $this->db->insert('film', $film);
	}
}