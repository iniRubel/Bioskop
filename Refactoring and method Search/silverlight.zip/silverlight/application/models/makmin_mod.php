<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class makmin_mod extends CI_Model{
	public function __construct() {
        $this->load->database();
        
    }

    public function count_table(){
    	$query = $this->db->query("select * from makmin;");
		return count ($query->result_array());
    }

	public function get_all(){
		$query = $this->db->query("select * from makmin order by id_makmin;");
		return $query->result_array();
	}

	public function get_nRow($n){
		$query = $this->db->query("select * from makmin order by id_makmin desc limit ".$n.";");
		return $query->result_array();
	}

	public function search($title){
		$query = $this->db->query("select * from makmin where nama like '%".$title."%';");
		return $query->result_array();
	}

	public function tambah_makmin($makmin){
		return $this->db->insert('makmin', $makmin);
	}
}