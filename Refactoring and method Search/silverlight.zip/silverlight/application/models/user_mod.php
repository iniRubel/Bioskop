<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class user_mod extends CI_Model{

	public function __construct() {
        $this->load->database();
        
    }

    public function is_ada($email){
		$this->db->where("email",$email);
	    $query = $this->db->get("users");
	    if ($query->num_rows() == 0){
	        return true;
	    }
	    else{
	        return false;
	    }
	}
 
	public function registrasi($akun){
		return $this->db->insert('users', $akun);
	}

	public function get_all(){
		$query = $this->db->query("select * from users;");
		$row = $query->result_array();
		return $row;
	}

	public function search($title){
		$query = $this->db->query("select * from users where nama like '%".$title."%';");
		$row = $query->result_array();
		return $row;
	}
	
}