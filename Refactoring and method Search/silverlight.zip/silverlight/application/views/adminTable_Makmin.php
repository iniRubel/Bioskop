<div class="container-fluid contain">
    <div class="row">
        <div class="col-12">
            <div style="display: flex;">
                <div class="accessories"><p></p></div>
                <h1 class="heading1">List All Makanan dan Minuman</h1> 
            </div>  
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="film_list">
                <a href="<?php echo base_url() ?>tambah_Makmin">
                <button type="button" class="btn btn-primary" style="width: 255px; height: 100%; border-radius: 1rem; padding: 20px"> 
                    <div>
                        <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/plus.svg">    
                    </div> 
                    <b>Tambah Makmin</b>
                </button>
                </a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <form style="width: 300px;"  class="example" action="<?php echo base_url().'admin_Makmin/makmin_search/'; ?>" style="margin:auto; max-width:300px" method="get">
                <input type="text" placeholder="Search.." name="scTabMakmin">
                <button type="submit">
                    <img style="width: 50%" src="<?php echo base_url()?>other/asset/icon/search.svg">
                </button>
                
            </form>
        </div>
        <div class="col-lg-9">
            <p style="color: white;"><?php echo "$search"; ?></p>
            <table class="table table-dark table-striped">
                <thead>
                    <tr>
                        <th style="width: 200px;">Gambar</th>
                        <th style="width: 200px;">Nama</th>
                        <th>Keterangan</th>
                        <th style="width: 200px;">harga</th>
                        <th style="width: 200px;">edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        foreach ($list as $row){
                    ?>
                        <tr>
                            <td><img class="film_list_img" src="<?php echo base_url()?>other/asset/makmin/<?php echo $row['id_makmin']?>.png"></td>
                            <td ><?php echo $row['nama']?></td>
                            <td><?php echo $row['keterangan']?></td>
                            <td><?php echo $row['harga']?></td>
                            <td><button style="width: 100px" type="button" class="btn btn-primary tombol">Edit</button></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>