<div class="container-fluid contain">
    <div class="row">
        <div class="col-12">
            <div style="display: flex;">
                <div class="accessories"><p></p></div>
                <h1 class="heading1">List Film</h1> 
            </div> 
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <form style="width: 300px;"  class="example" action="<?php echo base_url().'admin_User/user_search/'; ?>" style="margin:auto; max-width:300px" method="get">
                <input type="text" placeholder="Search.." name="scTabUser">
                <button type="submit">
                    <img style="width: 50%" src="<?php echo base_url()?>other/asset/icon/search.svg">
                </button>
                
            </form>
            
        </div>
        <div class="col-lg-9">
            <p style="color: white;"><?php echo "$search"; ?></p>
            <table class="table table-dark table-striped">
                <thead>
                    <tr>
                        <th style="width: 20px;">image</th>
                        <th style="width: 200px;">Email</th>
                        <th>Nama</th>
                        <th style="width: 200px;">Nomor Hp</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        foreach ($list as $row){
                    ?>
                        <tr>

                            <td><img style="width: 90%" src="<?php echo base_url()?>other/asset/icon/user.svg"></td>
                            <td ><?php echo $row['email']?></td>
                            <td><?php echo $row['nama']?></td>
                            <td><?php echo $row['nohp']?></td>
                            <td><button style="width: 100px" type="button" class="btn btn-primary tombol">Edit</button></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>