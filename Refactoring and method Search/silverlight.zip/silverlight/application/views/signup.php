<div class="container-fluid contain">
	<div class="row">
		<div class="col-12">
			<div style="display: flex;">
				<div class="accessories"><p></p></div>
				<h1 class="heading1">Sign up</h1>	
			</div>	
		</div>
	</div>
	<div class="row">
		<div class="col-md-4" style="padding-right: 27px;">
			<div class="sign_box">
				
				<form action="<?php echo base_url(). 'signup/register';?>" style="padding-bottom: 15px;" method="post">
					<div class="form_contain">
						Email
						<input type="email" name="email" required class="form-control form-rounded">
						<ul style='color: #b94a48; padding-top: 5px;'>
							<?php echo $this->session->flashdata('message2');?>
						</ul>	
					</div>
					<div class="form_contain">
						Nomor Hp
						<input type="tel" name="nomorHp" pattern="[0-9]{12}" required class="form-control form-rounded">	
					</div>
					<div class="form_contain">
						Nama Lengkap
						<input type="text" name="nama" required class="form-control form-rounded">	
					</div>
					<div class="form_contain">
						Sandi
						<input type="password" name="sandi" required class="form-control form-rounded">
						<ul style='color: #b94a48; padding-top: 5px;'>
							<?php echo $this->session->flashdata('message0');?>
							<?php echo $this->session->flashdata('message1');?>
						</ul>
					</div> 
					<div class="form_contain">
						Konfirmasi Sandi
						<input type="password" name="confsandi" required class="form-control form-rounded">
						<ul style='color: #b94a48; padding-top: 5px;'>
							<?php echo $this->session->flashdata('message1');?>
						</ul>	
					</div> 
					<div class="form_contain">
						<input type="checkbox" name="terms" value="yes" required style="margin-right: 12px;">I accept the terms of use & privacy policy
					</div>
					<div class="form_contain">
						<button type="submit" class="btn btn-primary tombol">Sign Up</button>
					</div>
				</form>

				<div style="text-align: center;">
					Sudah punya akun ? Sign In
				</div>
			</div>
		</div>
		<div class="col-md-8" style="padding-left: 27px;">
			<div style="background-color: gray; height: 575px; border-radius: 2rem">
				
			</div>
		</div>
	</div>


</div>