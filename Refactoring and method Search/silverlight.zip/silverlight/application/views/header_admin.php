<div class="container-fluid navigation">
	<div class="row justify-content-between">

		<div class="col-auto" style="margin-top: auto; margin-bottom: auto">
			<div class="row">
				<div class="col-auto" style="padding-right: 0px; margin-right: 50px;">
					<a href="<?php echo base_url() ?>home">
						<img style="height: 53px" src="<?php echo base_url()?>other/asset/icon/logo.svg" alt="">	
					</a>
				</div>
				<div class="col-auto" style="margin-top: auto; margin-bottom: auto; padding-left: 0px">
					<a href="<?php echo base_url() ?>admin_User" class="linknav">User</a>
					<a href="<?php echo base_url() ?>admin_Film" class="linknav">Film</a>
					<a href="<?php echo base_url() ?>admin_Makmin" class="linknav">Makmin</a>	
				</div>	
			</div>
		</div>

		<div class="col-auto">
			<div class="row">
				<div class="col-auto" style="margin-top: auto; margin-bottom: auto; padding-right: 0px">
					<a href="" class="linknav">Sign Out</a>	
				</div>
				<div class="col-auto" style="padding-left: 0px">
					<button type="button tombol" class="btn btn-primary tombol" style="width: 165px">Admin Mode</button>
				</div>	
			</div>
		</div>
		
	</div>
</div>