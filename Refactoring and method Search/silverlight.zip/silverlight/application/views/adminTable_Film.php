<div class="container-fluid contain">
    <div class="row">
        <div class="col-12">
            <div style="display: flex;">
                <div class="accessories"><p></p></div>
                <h1 class="heading1">List Film</h1> 
            </div> 
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="film_list">
                <a href="<?php echo base_url() ?>tambah_Film">
                <button type="button" class="btn btn-primary" style="width: 255px; height: 100%; border-radius: 1rem; padding: 20px"> 
                    <div>
                        <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/plus.svg">    
                    </div> 
                    <b>Tambah Film</b>
                </button>
                </a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <form style="width: 300px;"  class="example" action="<?php echo base_url().'admin_Film/film_search/'; ?>" style="margin:auto; max-width:300px" method="get">
                <input type="text" placeholder="Search.." name="scTabFilm">
                <button type="submit">
                    <img style="width: 50%" src="<?php echo base_url()?>other/asset/icon/search.svg">
                </button>
                
            </form>
            
        </div>
        <div class="col-lg-12">
            <p style="color: white;"><?php echo "$search"; ?></p>
            <table class="table table-dark table-striped">
                <thead>
                    <tr>
                        <th style="width: 200px;">Poster</th>
                        <th style="width: 200px;">Judul</th>
                        <th>Sinopsis</th>
                        <th style="width: 200px;">Sutradara</th>
                        <th style="width: 100px;">Durasi</th>
                        <th style="width: 200px;">Gendre</th>
                        <th>Link Trailer</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        foreach ($list as $row){
                    ?>
                        <tr>
                            <td><img class="film_list_img" src="<?php echo base_url()?>other/asset/film/<?php echo $row['id_film']?>.jpg"></td>
                            <td ><?php echo $row['judul']?></td>
                            <td><?php echo $row['sinopsis']?></td>
                            <td><?php echo $row['sutradara']?></td>
                            <td><?php echo $row['durasi']?></td>
                            <td><?php echo $row['gendre']?></td>
                            <td><?php echo $row['link_trailer']?></td>
                            <td><button style="width: 100px" type="button" class="btn btn-primary tombol">Edit</button></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>