<div class="container-fluid contain">
	<div class="row">
		<div class="col-12">
			<div style="display: flex;">
				<div class="accessories"><p></p></div>
				<h1 class="heading1">Tambah Makmin</h1>	
			</div>	
		</div>
	</div>
	<div class="row">
		<div class="col-md-8" style="padding-right: 27px;">
			<div class="sign_box">
				<form action="<?php echo base_url(). 'tambah_Makmin/tambah_Makmin';?>" style="padding-bottom: 15px;" method="post" enctype='multipart/form-data'>
					<div class="row">
						<div class="col-6">
							<div class="form_contain">
								Nama
								<input type="text" name="nama" required class="form-control form-rounded">	
							</div>
							<div class="form_contain">
								Keterangan
								<input type="text" name="keterangan" required class="form-control form-rounded">	
							</div>
							<div class="form_contain">
								Harga
								<input type="number" name="harga" required class="form-control form-rounded">	
							</div>
						</div>
						<div class="col-6">	
							<div class="form_contain">
								Gambar (.png)<br>
								<input type="file" style="margin-top: 14px" required name="gambar" size="20" id="imageFile">
								<ul style='color: #b94a48; padding-top: 5px;'>
									<?php echo $this->session->flashdata('message0');?>
								</ul>
							</div>
						</div>
					</div>
					<div class="form_contain">
						<button type="submit" class="btn btn-primary tombol">Tambah Makmin</button>
					</div>							
				</form>
			</div>
		</div>
	</div>
</div>