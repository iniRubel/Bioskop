<center>
    <img style="padding-top: 65px;" src="<?php echo base_url()?>other/asset/icon/logo.svg" alt="">
</center>
<div class="container-fluid contain">
	<div class="row">
		<div class="col-12">
			<div style="display: flex;">
				<div class="accessories"><p></p></div>
				<h1 class="heading1">Sedang Tayang</h1>	
			</div>	
		</div>
	</div>
	<div class="row justify-content-between">
        <?php 
            foreach ($tayang as $row){
        ?>
            <div class="col-lg-2">
                <div class="film_list">
                    <img class="film_list_img" src="<?php echo base_url()?>other/asset/film/<?php echo $row['id_film']?>.jpg" alt="">
                    <p><b><?php echo $row['judul'] ?></b></p>
                    <p style="font-size: 15px;color: #207ED9"><?php echo $row['gendre'] ?></p>
                    <button type="button" class="btn btn-primary tombol">Book Now</button>
                </div>
            </div>
        <?php } ?>
        
	</div>
</div>

<div class="container-fluid contain">
	<div class="row">
		<div class="col-12">
			<div style="background-color: gray; height: 500px; border-radius: 2rem">
			</div>	
		</div>
	</div>
</div>

<div class="container-fluid contain">
    <div class="row">
        <div class="col-12">
            <div style="display: flex;">
                <div class="accessories"><p></p></div>
                <h1 class="heading1">Akan Tayang</h1>   
            </div>  
        </div>
    </div>
    <div class="row justify-content-between">
        <?php 
            foreach ($akan as $row){
        ?>
            <div class="col-lg-2">
                <div class="film_list">
                    <img class="film_list_img" src="<?php echo base_url()?>other/asset/film/<?php echo $row['id_film']?>.jpg" alt="">
                    <p><b><?php echo $row['judul'] ?></b></p>
                    <p style="font-size: 15px;color: #207ED9"><?php echo $row['gendre'] ?></p>
                    <button type="button" class="btn btn-primary tombol">Book Now</button>
                </div>
            </div>
        <?php } ?>

        <div class="col-lg-2">
            <div class="film_list" style="height: 511.5px;">

                <button type="button" class="btn btn-primary" style="width: 255px; height: 100%; border-radius: 2rem;">
                    <div style="margin-bottom: 24px">
                        <img src="<?php echo base_url()?>other/asset/icon/next.svg">
                    </div>
                    <b>Lihat Semua</b>
                </button>
            </div>
        </div>
    </div>
</div>