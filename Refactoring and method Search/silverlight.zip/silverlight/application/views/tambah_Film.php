<div class="container-fluid contain">
	<div class="row">
		<div class="col-12">
			<div style="display: flex;">
				<div class="accessories"><p></p></div>
				<h1 class="heading1">Tambah Film</h1>	
			</div>	
		</div>
	</div>
	<div class="row">
		<div class="col-md-8" style="padding-right: 27px;">
			<div class="sign_box">
				<form action="<?php echo base_url(). 'tambah_Film/tambah_Film';?>" style="padding-bottom: 15px;" method="post" enctype='multipart/form-data'>
					<div class="row">
						<div class="col-6">
							<div class="form_contain">
								Judul
								<input type="text" name="judul" required class="form-control form-rounded">	
							</div>
							<div class="form_contain">
								Durasi
								<input type="text" name="durasi" required class="form-control form-rounded">	
							</div>
							<div class="form_contain">
								Gendre
								<input type="text" name="gendre" required class="form-control form-rounded">	
							</div>
							<div class="form_contain">
								Sutradara
								<input type="text" name="sutradara" required class="form-control form-rounded">	
							</div>
							<div class="form_contain">
								Link Trailer
								<input type="url" name="link_trailer" required class="form-control form-rounded">	
							</div>
						</div>
						<div class="col-6">
							<div class="form_contain">
								Sinopsis
								<textarea class="form-control form-rounded-textarea" name="sinopsis" rows="13"></textarea>
							</div>	
							<div class="form_contain">
								Poster (.jpg)<br>
								<input style="margin-top: 14px" type="file" required name="poster" size="20" id="imageFile">
								<ul style='color: #b94a48; padding-top: 5px;'>
									<?php echo $this->session->flashdata('message0');?>
								</ul>
							</div>
						</div>
					</div>
					<div class="form_contain">
						<button type="submit" class="btn btn-primary tombol">Tambah Film</button>
					</div>							
				</form>
			</div>
		</div>
	</div>
</div>