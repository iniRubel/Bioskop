<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin_Makmin extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('makmin_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function index(){
		$daftar["search"] = "";
		$daftar["list"] = $this->makmin_mod->get_all();
		
		$this->load->view('main');
		$this->load->view('header_admin');
		$this->load->view('adminTable_Makmin',$daftar);
		$this->load->view('footer');
	}

	public function makmin_search(){
		$search = $_GET["scTabMakmin"];
		$daftar["search"] = $search;
		$daftar["list"] = $this->makmin_mod->search($search);

		$this->load->view('main');
		$this->load->view('header_admin');
		$this->load->view('adminTable_Makmin', $daftar);
		$this->load->view('footer');
	}
}