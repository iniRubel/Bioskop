<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('user_mod');
		$this->load->model('film_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function index(){
		$daftar["tayang"] = $this->film_mod->get_all();
		$daftar["akan"] = $this->film_mod->get_nRow(4);
		$this->load->view('main');
		$this->load->view('header_st');
		$this->load->view('home', $daftar);
		$this->load->view('footer');
	}
}