<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin_User extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('user_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function index(){
		$daftar["search"] = "";
		$daftar["list"] = $this->user_mod->get_all();

		$this->load->view('main');
		$this->load->view('header_admin');
		$this->load->view('adminTable_User',$daftar);
		$this->load->view('footer');
	}

	public function user_search(){
		$search = $_GET["scTabUser"];
		$daftar["search"] = $search;
		$daftar["list"] = $this->user_mod->search($search);

		$this->load->view('main');
		$this->load->view('header_admin');
		$this->load->view('adminTable_User', $daftar);
		$this->load->view('footer');
	}
}