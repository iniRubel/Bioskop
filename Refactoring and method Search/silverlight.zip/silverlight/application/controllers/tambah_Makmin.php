<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class tambah_Makmin extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('makmin_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function index(){
		$this->load->view('main');
		$this->load->view('header_admin');
		$this->load->view('tambah_Makmin');
		$this->load->view('footer');
	}

	public function tambah_Makmin(){
		$num = $this->makmin_mod->count_table()+1;
		$id_makmin = 'MKN-'.$num;

		$config['upload_path']          = './other/asset/makmin';
		$config['allowed_types']        = 'png';
		$config['file_name'] 			= $id_makmin;
			 
		$this->load->library('upload', $config);

		if($this->upload->do_upload('gambar')){
            $uploadData = $this->upload->data();

            $film = array(
				'id_makmin' => $id_makmin,
				'nama' => $this->input->post('nama'),
				'keterangan' => $this->input->post('keterangan'),
				'harga' => $this->input->post('harga'),
			);

			$this->makmin_mod->tambah_makmin($film);
            redirect('admin_Makmin');
        }else{
        	$this->session->set_flashdata('message0', "<li>file gambar harus .png</li>");
            redirect('tambah_Makmin');
        }
	}
}