<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin_Film extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('film_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function index(){
		$daftar["search"] = "";
		$daftar["list"] = $this->film_mod->get_all();
		
		$this->load->view('main');
		$this->load->view('header_admin');
		$this->load->view('adminTable_Film',$daftar);
		$this->load->view('footer');
	}

	public function film_search(){
		$search = $_GET["scTabFilm"];
		$daftar["search"] = $search;
		$daftar["list"] = $this->film_mod->search($search);

		$this->load->view('main');
		$this->load->view('header_admin');
		$this->load->view('adminTable_Film', $daftar);
		$this->load->view('footer');
	}

}