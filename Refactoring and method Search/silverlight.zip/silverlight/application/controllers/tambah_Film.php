<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class tambah_Film extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('film_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function index(){
		$this->load->view('main');
		$this->load->view('header_admin');
		$this->load->view('tambah_Film');
		$this->load->view('footer');
	}

	public function tambah_Film(){
		$num = $this->film_mod->count_table()+1;
		$id_film = 'FLM-'.$num;
		
		$config['upload_path']          = './other/asset/film';
		$config['allowed_types']        = 'jpg';
		$config['file_name'] 			= $id_film;
			 
		$this->load->library('upload', $config);

		if($this->upload->do_upload('poster')){
            $uploadData = $this->upload->data();

            $film = array(
				'id_film' => $id_film,
				'judul' => $this->input->post('judul'),
				'durasi' => $this->input->post('durasi'),
				'sinopsis' => $this->input->post('sinopsis'),
				'gendre' => $this->input->post('gendre'),
				'sutradara' => $this->input->post('sutradara'),
				'link_trailer' => $this->input->post('link_trailer'),
			);

			$this->film_mod->tambah_film($film);
            redirect('admin_Film');
        }else{
        	$this->session->set_flashdata('message0', "<li>file poster harus .jpg</li>");
            redirect('tambah_Film');
        }
	}
}