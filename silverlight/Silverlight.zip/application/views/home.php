<center>
    <img style="padding-top: 65px;" src="<?php echo base_url()?>other/asset/icon/logo.svg" alt="">
</center>
<div class="container-fluid contain">
	<div class="row">
		<div class="col-12">
			<div style="display: flex;">
				<div class="accessories"><p></p></div>
				<h1 class="heading1">Sedang Tayang</h1>	
			</div>	
		</div>
	</div>
	<div class="row justify-content-between">
		<div class="col-lg-auto">
            <div class="film_list">
                <img class="film_list_img" src="<?php echo base_url()?>other/asset/film/it chapter two.jpg" alt="">
                <p><b>IT : Chapter Two</b></p>
                <p style="font-size: 15px;color: #207ED9">Horror, Thriller</p>
                <button type="button" class="btn btn-primary tombol">Book Now</button>
            </div>
        </div>

        <div class="col-lg-auto">
            <div class="film_list">
                <img class="film_list_img" src="<?php echo base_url()?>other/asset/film/gundala.jpg" alt="">
                <p><b>Gundala</b></p>
                <p style="font-size: 15px;color: #207ED9">Action</p>
                <button type="button" class="btn btn-primary tombol">Book Now</button>
            </div>
        </div>

        <div class="col-lg-auto">
            <div class="film_list">
                <img class="film_list_img" src="<?php echo base_url()?>other/asset/film/once upon a time in hollywood.jpg" alt="">
                <p><b>Once Upon In Time..</b></p>
                <p style="font-size: 15px;color: #207ED9">Horror, Thriller</p>
                <button type="button" class="btn btn-primary tombol">Book Now</button>
            </div>
        </div>

        <div class="col-lg-auto">
            <div class="film_list">
                <img class="film_list_img" src="<?php echo base_url()?>other/asset/film/ready or not.jpg" alt="">
                <p><b>Ready Or Not</b></p>
                <p style="font-size: 15px;color: #207ED9">Horror, Thriller</p>
                <button type="button" class="btn btn-primary tombol">Book Now</button>
            </div>
        </div>

        <div class="col-lg-auto">
            <div class="film_list">
                <img class="film_list_img" src="<?php echo base_url()?>other/asset/film/wheathering with you.jpg" alt="">
                <p><b>Wheathering With You</b></p>
                <p style="font-size: 15px;color: #207ED9">Horror, Thriller</p>
                <button type="button" class="btn btn-primary tombol">Book Now</button>
            </div>
        </div>
	</div>
</div>

<div class="container-fluid contain">
	<div class="row">
		<div class="col-12">
			<div style="background-color: gray; height: 500px; border-radius: 2rem">
			</div>	
		</div>
	</div>
</div>

<div class="container-fluid contain">
    <div class="row">
        <div class="col-12">
            <div style="display: flex;">
                <div class="accessories"><p></p></div>
                <h1 class="heading1">Akan Tayang</h1>   
            </div>  
        </div>
    </div>
    <div class="row justify-content-between">
        <div class="col-lg-auto">
            <div class="film_list">
                <img class="film_list_img" src="<?php echo base_url()?>other/asset/film/it chapter two.jpg" alt="">
                <p><b>IT : Chapter Two</b></p>
                <p style="font-size: 15px;color: #207ED9">Horror, Thriller</p>
                <button type="button" class="btn btn-primary tombol">Lihat Detail</button>
            </div>
        </div>

        <div class="col-lg-auto">
            <div class="film_list">
                <img class="film_list_img" src="<?php echo base_url()?>other/asset/film/gundala.jpg" alt="">
                <p><b>Gundala</b></p>
                <p style="font-size: 15px;color: #207ED9">Action</p>
                <button type="button" class="btn btn-primary tombol">Lihat Detail</button>
            </div>
        </div>

        <div class="col-lg-auto">
            <div class="film_list">
                <img class="film_list_img" src="<?php echo base_url()?>other/asset/film/once upon a time in hollywood.jpg" alt="">
                <p><b>Once Upon In Time..</b></p>
                <p style="font-size: 15px;color: #207ED9">Horror, Thriller</p>
                <button type="button" class="btn btn-primary tombol">Lihat Detail</button>
            </div>
        </div>

        <div class="col-lg-auto">
            <div class="film_list">
                <img class="film_list_img" src="<?php echo base_url()?>other/asset/film/ready or not.jpg" alt="">
                <p><b>Ready Or Not</b></p>
                <p style="font-size: 15px;color: #207ED9">Horror, Thriller</p>
                <button type="button" class="btn btn-primary tombol">Lihat Detail</button>
            </div>
        </div>

        <div class="col-lg-auto">
            <div class="film_list" style="height: 511.5px;">

                <button type="button" class="btn btn-primary" style="width: 255px; height: 100%; border-radius: 2rem;">
                    <div style="margin-bottom: 24px">
                        <img src="<?php echo base_url()?>other/asset/icon/next.svg">
                    </div>
                    <b>Lihat Semua</b>
                </button>
            </div>
        </div>
    </div>
</div>