<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class signup extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('signup_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function index(){
		$this->load->view('main');
		$this->load->view('header_nd');
		$this->load->view('signup');
		$this->load->view('footer');
	}

	public function register(){

		$email = $this->input->post('email');
		$nohp = $this->input->post('nomorHp');
		$nama = $this->input->post('nama');
		$sandi = $this->input->post('sandi');
		$confsandi = $this->input->post('confsandi');
		$terms = $this->input->post('terms');

		if ($sandi != $confsandi) {
			$this->session->set_flashdata('message0', "<li>Sandi tidak cocok</li>");
			redirect('signup');
		} else{
			$cekemail = $this->signup_mod->is_ada($email);
			if ($cekemail==true) {

				$akun = array(
					'email' => $email,
					'nohp' => $nohp,
					'nama' => $nama,
					'sandi' => md5($sandi),
				);
				$this->signup_mod->registrasi($akun);
				redirect('signup');
			} else {
				$this->session->set_flashdata('message1', "<li>Email sudah terdaftar</li>");
				redirect('signup');
			}
		}
		
	}
}