<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class users_mod extends CI_Model{

	public function __construct() {
        $this->load->database();
        
    }

    public function get($email, $type){
    	if ($type == 'admin') {
    		$this->db->where('email', $email);
			$query = $this->db->get('admin')->row_array();
			return $query;
    	} elseif ($type == 'users'){
    		$this->db->where('email', $email);
			$query = $this->db->get('users')->row_array();
			return $query;
    	}
		
	}

    public function get_all(){
		$query = $this->db->query("select * from users;");
		$row = $query->result_array();
		return $row;
	}

    public function count_table($type){
    	if ($type == 'admin') {
	    	$query = $this->db->query("select * from admin;");
			return count ($query->result_array());
		} elseif($type == 'users'){
			$query = $this->db->query("select * from users;");
			return count ($query->result_array());
		}
    }

    public function is_ada($email, $type){
    	if ($type == 'admin') {
    		$this->db->where("email",$email);
		    $query = $this->db->get("admin");
		    if ($query->num_rows() == 0){
		        return true;
		    }
		    else{
		        return false;
		    }
    	}elseif ($type == 'users'){
    		$this->db->where("email",$email);
		    $query = $this->db->get("users");
		    if ($query->num_rows() == 0){
		        return true;
		    }
		    else{
		        return false;
		    }
    	}
	}
 
	public function search($title){
		$query = $this->db->query("select * from users where nama like '%".$title."%';");
		$row = $query->result_array();
		return $row;
	}

	public function tambah_Users($akun,$type){
		if ($type == 'admin') {
			return $this->db->insert('admin', $akun);
		} elseif ($type == 'users'){
			return $this->db->insert('users', $akun);
		}
	}
	
}