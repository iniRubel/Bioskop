<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class tiket_mod extends CI_Model{
	public function __construct() {
        $this->load->database();
        
    }

 //    public function get($id_tiket){
		
	// }
	public function tambah_tikets($tikets){
		return $this->db->insert('tikets', $tikets);
	}
	public function get($id_tikets){
		$this->db->where('id_tikets', $id_tikets);
		$query = $this->db->get('tikets')->row_array();
		return $query;
	}
	
	public function getData_Tiket($nohp){
		
		$query = $this->db->query("select * FROM tikets k JOIN jadwal j on k.id_jadwal = j.id_jadwal JOIN theater t ON j.id_theater = t.id_theater join film f ON j.id_film = f.id_film JOIN bioskop b on t.id_bioskop = b.id_bioskop JOIN users u ON k.email = u.email where u.nohp = '".$nohp."'order by tanggal_beli desc, jam asc;");
		return $query->result_array();
	}public function getData_byID($id_tikets){
		$query = $this->db->query("select * FROM tikets k JOIN jadwal j on k.id_jadwal = j.id_jadwal JOIN theater t ON j.id_theater = t.id_theater join film f ON j.id_film = f.id_film JOIN bioskop b on t.id_bioskop = b.id_bioskop JOIN users u ON k.email = u.email where k.id_tikets = '".$id_tikets."';");
		return $query->row_array();
	}
	public function cek_Kursi($id_jadwal){
		$query = $this->db->query("select kursi FROM tikets WHERE id_jadwal = '".$id_jadwal."';");
		return $query->result_array();
	}



}