<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class bioskop_mod extends CI_Model{
	public function __construct() {
        $this->load->database();
        
    }

	public function get($id_bioskop){
		$this->db->where('id_bioskop', $id_bioskop);
		$query = $this->db->get('bioskop')->row_array();
		return $query;
	}

    public function count_table(){
    	$query = $this->db->query("select * from bioskop;");
		return count ($query->result_array());
    }

	public function get_all(){
		$query = $this->db->query("select * from bioskop order by nama_bioskop;");
		return $query->result_array();
	}

	public function get_all_Kota(){
		$query = $this->db->query("select kota from bioskop group BY kota order by kota ASC ;");
		return $query->result_array();
	}


	public function get_nRow($n){
		$query = $this->db->query("select * from bioskop order by id_bioskop desc limit ".$n.";");
		return $query->result_array();
	}

	public function is_ada($nama_bioskop){
		$this->db->where("nama_bioskop",$nama_bioskop);
	    $query = $this->db->get("bioskop");
	    if ($query->num_rows() == 0){
	        return true;
	    }
	    else{
	        return false;
	    }
	}

	public function is_adaId($id){
		$this->db->where("id_bioskop",$id);
	    $query = $this->db->get("bioskop");
	    if ($query->num_rows() == 0){
	        return true;
	    }
	    else{
	        return false;
	    }
	}

	public function search($title){
		$query = $this->db->query("select * from bioskop where nama_bioskop like '%".$title."%';");
		return $query->result_array();
	}

	public function tambah_bioskop($bioskop){
		return $this->db->insert('bioskop', $bioskop);
	}

	public function update_bioskop($id_bioskop, $new){
		$this->db->where('id_bioskop', $id_bioskop);
        return $this->db->update('bioskop', $new);
	}

	public function delete_bioskop($id_bioskop){
		$this->db->where('id_bioskop', $id_bioskop);
		$this->db->delete('bioskop');
	}
}