<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class film_mod extends CI_Model{
	public function __construct() {
        $this->load->database();
        
    }

    public function get($id_film){
		$this->db->where('id_film', $id_film);
		$query = $this->db->get('film')->row_array();
		return $query;
	}

	public function get_all(){
		$query = $this->db->query("select * from film order by rilis_end desc;");
		return $query->result_array();
	}

	public function get_tayang(){
		$dateNow = date("Y-m-d");
		$query = $this->db->query("select * from film where rilis_start <= '".$dateNow."' and '".$dateNow."' <= rilis_end order by rilis_start asc;");
		return $query->result_array();
	}

	public function get_akan($many){
		if ($many=="all") {
			$dateNow = date("Y-m-d");
			$query = $this->db->query("select * from film where rilis_start > '".$dateNow."' and '".$dateNow."' < rilis_end order by rilis_start desc;");
			return $query->result_array();
		} else if ($many=="notAll"){
			$dateNow = date("Y-m-d");
			$query = $this->db->query("select * from film where rilis_start > '".$dateNow."' and '".$dateNow."' < rilis_end order by rilis_start desc limit 5;");
			return $query->result_array();
		}
			
	}

    public function count_table(){
    	$query = $this->db->query("select * from film;");
		return count ($query->result_array());
    }

	public function get_nRow($n){
		$query = $this->db->query("select * from film order by id_film desc limit ".$n.";");
		return $query->result_array();
	}

	public function is_adaId($id){
		$this->db->where("id_film",$id);
	    $query = $this->db->get("film");
	    if ($query->num_rows() == 0){
	        return true;
	    }
	    else{
	        return false;
	    }
	}

	public function search($title){
		$query = $this->db->query("select * from film where judul like '%".$title."%';");
		return $query->result_array();
	}

	public function tambah_film($film){
		return $this->db->insert('film', $film);
	}

	public function update_film($id_film, $new){
		$this->db->where('id_film', $id_film);
        return $this->db->update('film', $new);
	}

	public function delete_film($id_film){
		$this->db->where('id_film', $id_film);
		$this->db->delete('film');
	}
	
}