<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class theater_mod extends CI_Model{
	public function __construct() {
        $this->load->database();
        
    }

    public function count_table(){
    	$query = $this->db->query("select * from theater;");
		return count ($query->result_array());
    }

	public function get($id_theater){
		$this->db->where('id_theater', $id_theater);
		$query = $this->db->get('theater')->row_array();
		return $query;
	}

	public function get_all(){
		$query = $this->db->query("select * from theater order by id_theater;");
		return $query->result_array();
	}

	public function get_withIdBioskop($id_bioskop){
		$query = $this->db->query("select * from theater where id_bioskop = '".$id_bioskop."';");
		return $query->result_array();
	}

	public function get_nRow($n){
		$query = $this->db->query("select * from theater order by id_theater desc limit ".$n.";");
		return $query->result_array();
	}

	public function is_ada($id_bioskop,$no_theater){
		$query = $this->db->query("select * from theater where id_bioskop = '".$id_bioskop."' and no_theater = '".$no_theater."';");
	    if ($query->num_rows() == 0){
	        return true;
	    }
	    else{
	        return false;
	    }
	}

	public function is_adaId($id){
		$this->db->where("id_theater",$id);
	    $query = $this->db->get("theater");
	    if ($query->num_rows() == 0){
	        return true;
	    }
	    else{
	        return false;
	    }
	}

	public function tambah_theater($theater){
		return $this->db->insert('theater', $theater);
	}

	public function update_theater($id_theater, $new){
		$this->db->where('id_theater', $id_theater);
        return $this->db->update('theater', $new);
	}

	public function delete_theater($id_theater){
		$this->db->where('id_theater', $id_theater);
		$this->db->delete('theater');
	}
}