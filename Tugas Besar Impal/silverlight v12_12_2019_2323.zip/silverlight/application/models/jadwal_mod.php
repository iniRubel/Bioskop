<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class jadwal_mod extends CI_Model{
	public function __construct() {
        $this->load->database();
        
    }

    public function count_table(){
    	$query = $this->db->query("select * from jadwal;");
		return count ($query->result_array());
    }

	public function get($id_jadwal){
		$this->db->where('id_jadwal', $id_jadwal);
		$query = $this->db->get('jadwal')->row_array();
		return $query;
	}

	public function get_all(){
		$query = $this->db->query("select * from jadwal order by id_jadwal;");
		return $query->result_array();
	}

	public function getJadwal_Tiket($id_jadwal){
		
		$query = $this->db->query("select * FROM jadwal j join theater t on j.id_theater = t.id_theater join film f on j.id_film = f.id_film join bioskop b on t.id_bioskop = b.id_bioskop where j.id_jadwal = '".$id_jadwal."';");
		return $query->row_array();
	}

	public function get_jadwalfilm($id_film){
		$today = date("Y-m-d");
		$query = $this->db->query("select group_concat(j.jam ORDER BY j.jam SEPARATOR ', ') as 'allJam',group_concat(j.id_jadwal ORDER BY j.jam SEPARATOR ', ') as 'allId', b.nama_bioskop,j.tanggal,b.alamat,b.kota from jadwal j JOIN theater t on j.id_theater=t.id_theater join bioskop b on b.id_bioskop=t.id_bioskop where j.tanggal>='".$today."' and j.status='active' and j.id_film = '".$id_film."' GROUP by b.nama_bioskop, j.tanggal;");
		return $query->result_array(); 
	}

	public function get_jadwalfilm_avilable($id_film){
		$today = date("Y-m-d");
		$query = $this->db->query("select j.tanggal from jadwal j JOIN theater t on j.id_theater=t.id_theater join bioskop b on b.id_bioskop=t.id_bioskop where j.tanggal>='".$today."' and j.status='active' and j.id_film = '".$id_film."' GROUP by j.tanggal");
		return $query->result_array(); 
	}

	public function get_jadwalTheater($tanggal,$id_theater){
		$query = $this->db->query("select * FROM jadwal WHERE id_theater='".$id_theater."' and tanggal='".$tanggal."';");
		return $query->result_array();
	}

	public function get_specJadwalTheater_jam($jam,$tanggal,$id_theater){
		$query = $this->db->query("select * from jadwal where tanggal = '".$tanggal."' and id_theater = '".$id_theater."' and jam = '".$jam."';");
		return $query->row_array();
	}

	public function get_specJadwalBioskop($id_bioskop){
		$today = date("Y-m-d");
		$query = $this->db->query("select *,group_concat(j.jam ORDER BY j.jam SEPARATOR ', ') as 'allJam' from jadwal j join theater t on j.id_theater=t.id_theater join bioskop b on t.id_bioskop=b.id_bioskop where j.tanggal >= '".$today."' and b.id_bioskop = '".$id_bioskop."' group by j.tanggal, j.id_film;");
		return $query->result_array();
	}

	public function get_memutar($id_theater){
		$query = $this->db->query("select j.id_jadwal,j.id_film,j.id_theater,f.judul,f.rilis_start,f.rilis_end,f.gendre,j.tanggal,group_concat(j.jam),j.status FROM jadwal j join film f on j.id_film = f.id_film where j.id_theater = '".$id_theater."' group by j.tanggal order by j.status desc, j.tanggal desc;");
		return $query->result_array();
	}

	public function is_adaId($id){
		$this->db->where("id_jadwal",$id);
	    $query = $this->db->get("jadwal");
	    if ($query->num_rows() == 0){
	        return true;
	    }
	    else{
	        return false;
	    }
	}

	public function is_ada_jadFilm($tanggal,$jam,$id_bioskop,$id_film){
		$query = $this->db->query("select * from jadwal j join theater t on j.id_theater=t.id_theater join bioskop b on t.id_bioskop=b.id_bioskop where j.tanggal = '".$tanggal."' and b.id_bioskop = '".$id_bioskop."' and j.jam = '".$jam."' and j.id_film = '".$id_film."';");
		if ($query->num_rows() == 0){
	        return true;
	    }
	    else{
	        return false;
	    }
	}
	public function is_ada_jadDate($tanggal,$id_theater){
		$query = $this->db->query("select * from jadwal j join theater t on j.id_theater=t.id_theater join bioskop b on t.id_bioskop=b.id_bioskop where j.tanggal = '".$tanggal."' and t.id_theater = '".$id_theater."';");
		if ($query->num_rows() == 0){
	        return true;
	    }
	    else{
	        return false;
	    }
	}

	public function tambah_jadwal($jadwal){
		return $this->db->insert('jadwal', $jadwal);
	}

	public function update_jadwal($id_jadwal, $new){
		$this->db->where('id_jadwal', $id_jadwal);
        return $this->db->update('jadwal', $new);
	}

	public function delete_jadwal($id_jadwal){
		$this->db->where('id_jadwal', $id_jadwal);
		$this->db->delete('jadwal');
	}
}