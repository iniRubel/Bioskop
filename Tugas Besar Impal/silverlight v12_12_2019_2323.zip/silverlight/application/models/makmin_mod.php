<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class makmin_mod extends CI_Model{
	public function __construct() {
        $this->load->database();
        
    }

    public function get($id_makmin){
		$this->db->where('id_makmin', $id_makmin);
		$query = $this->db->get('makmin')->row_array();
		return $query;
	}

	public function get_all(){
		$query = $this->db->query("select * from makmin order by nama_makmin;");
		return $query->result_array();
	}

    public function count_table(){
    	$query = $this->db->query("select * from makmin;");
		return count ($query->result_array());
    }

	public function get_nRow($n){
		$query = $this->db->query("select * from makmin order by id_makmin desc limit ".$n.";");
		return $query->result_array();
	}

	public function is_ada($nama_makmin){
		$this->db->where("nama_makmin",$nama_makmin);
	    $query = $this->db->get("makmin");
	    if ($query->num_rows() == 0){
	        return true;
	    }
	    else{
	        return false;
	    }
	}

	public function is_adaId($id){
		$this->db->where("id_makmin",$id);
	    $query = $this->db->get("makmin");
	    if ($query->num_rows() == 0){
	        return true;
	    }
	    else{
	        return false;
	    }
	}

	public function search($title){
		$query = $this->db->query("select * from makmin where nama_makmin like '%".$title."%';");
		return $query->result_array();
	}

	public function tambah_makmin($makmin){
		return $this->db->insert('makmin', $makmin);
	}

	public function update_makmin($id_makmin, $new){
		$this->db->where('id_makmin', $id_makmin);
        return $this->db->update('makmin', $new);
	}

	public function delete_makmin($id_makmin){
		$this->db->where('id_makmin', $id_makmin);
		$this->db->delete('makmin');
	}
}