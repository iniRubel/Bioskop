<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class users extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('users_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function signin(){
		$this->load->view('v_main');
		$this->load->view('v_header_nd');
		$this->load->view('v_signin');
		$this->load->view('v_footer');
	}

	public function signup(){
		$this->load->view('v_main');
		$this->load->view('v_header_nd');
		$this->load->view('v_signup');
		$this->load->view('v_footer');
	}

	public function validate($email,$nohp,$nama,$sandi){
		$err = 0;
		$errVal ="";

		//Check email
		if (empty($email)==true or filter_var($email, FILTER_VALIDATE_EMAIL)==false) {
            $err = $err+1;
            $errVal .= "Email, ";
        }

        //Check nomor telpon
        if (empty($nohp)==true or preg_match('/^[0-9]{12}+$/', $nohp)==false) {
			$err = $err+1;
			$errVal .="Nomor Hp, ";
		}

		//Check nama
		if (empty($nama)==true) {
            $err = $err+1;
            $errVal .= "Nama Lengkap, ";
        }

		//Check sandi
		if (empty($sandi)==true or strlen($sandi) < 8) {
            $err = $err+1;
            $errVal .= "Sandi, ";
        }
        $error = array();
        $error[0]=$err;
        $error[1]=$errVal;
        return $error;
	}

	public function register(){
		$email = trim($this->input->post('email'));
		$nohp = trim($this->input->post('nomorHp'));
		$nama = trim($this->input->post('nama'));
		$sandi = trim($this->input->post('sandi'));
		$confsandi = trim($this->input->post('confsandi'));
		$terms = trim($this->input->post('terms'));

		$error = $this->validate($email,$nohp,$nama,$sandi);
		if ($error[0]==0) {
			if ($terms == 'yes') {
				if ($sandi != $confsandi) {
					$this->session->set_flashdata('error', "Sandi dan confirmasi sandi berbeda");
					redirect('users/signup/');
				} else{
					$cekemail = $this->users_mod->is_ada($email,'users');
					if ($cekemail==true) {
						$akun = array(
							'email' => $email,
							'nohp' => $nohp,
							'nama' => $nama,
							'sandi' => md5($sandi),
						);

						$this->users_mod->tambah_Users($akun, 'users');
						$this->session->set_flashdata('update', "Pendaftaran Berhasil.<br>Silahkan cek email anda [".$email."] untuk konfirmasi registrasi");
						redirect('users/signup');
					} else {
						$this->session->set_flashdata('error', "Email sudah terdaftar");
		       			redirect('users/signup/');
					}
				}
			} else {
				$this->session->set_flashdata('error', "Terms tidak dicentang");
		       	redirect('users/signup/');
			}
		} else {
			$this->session->set_flashdata('error', $error[0]." Errors found. Data submit error: ".$error[1]);
	       	redirect('users/signup/');
		}		
	}

	public function masuk(){
		$email = trim($this->input->post('email'));
		$sandi = md5($this->input->post('sandi'));
		if ($this->users_mod->is_ada($email, 'users') == false) {
			$akun = $this->users_mod->get($email, 'users');
			if ($akun['sandi'] == $sandi) {

				$data_session = array(
					'email' => $akun['email'],
					'username' => $akun['nama'],
					'nohp' => $akun['nohp'],
					'type' => "users",
					'status' => "login",
				);
				$this->session->set_userdata($data_session);
				redirect('home');
			} else {
				$this->session->set_flashdata('error', "email atau sandi yang anda masukkan salah");
				redirect('users/signin/');
			}
		} else {
			$this->session->set_flashdata('error', "Email yang anda masukkan tidak terdaftar");
			redirect('users/signin/');
		}
	}

	public function signout(){
		$this->session->sess_destroy();
		redirect('home');
	}

}