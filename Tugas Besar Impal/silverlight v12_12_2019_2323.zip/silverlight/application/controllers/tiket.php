<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class tiket extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('theater_mod');
		$this->load->model('makmin_mod');
		$this->load->model('jadwal_mod');
		$this->load->model('tiket_mod');
		$this->load->library('session'); 
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function index(){
		$this->load->view('v_main');
		$this->load->view('v_header_kursi');
		$this->load->view('v_kursi'); 
		$this->load->view('v_footer');
	}

	public function validate_Kursi($kursi,$jumKursi){
		$err = 0;
		$errVal ="";

		//Check kursi
		
		if (empty($kursi)==false) {
			$seats = explode (",", $kursi);
			foreach ($seats as $sea) {
				if (preg_match('/^[0-9]{1,2}+[A-Z]$/', $sea)==false) {
					$err = $err+1;
					$errVal .= "Kursi[".$sea."], ";
				}
			}
		} else if (empty($kursi)==true) {
            $err = $err+1;
            $errVal .= "Kursi, ";
        }

        //Check nomor jumKursi
        if (empty($jumKursi)==true or is_numeric($jumKursi)==false) {
			$err = $err+1;
			$errVal .="Jumlah Kursi, ";
		}

        $error = array();
        $error[0]=$err;
        $error[1]=$errVal;
        return $error;
	}

	public function validate_Makmin($makmin,$totMakmin){
		$err = 0;
		$errVal ="";

		//Check makmin
		if (empty($makmin)==false) {
			$mak = explode (",", $makmin);
			if (count($mak) % 5 != 0) {
				$err = $err+1;
				$errVal .="Makmin array is not define well".$makmin;
			} else {
				$arrmak = explode (",#,", $makmin);
				foreach ($arrmak as $r ) {
					$arrmak2 = explode (",", $r);
					if (empty($arrmak2[0]) == true or preg_match('/^MKN-+[0-9A-Za-z]{13}$/', $arrmak2[0])==false){
						$err = $err+1;
						$errVal .="Makmin array is not define well";
					}

					if (empty($arrmak2[1]) == true){
						$err = $err+1;
						$errVal .="Makmin array is not define well";
					}

					if (empty($arrmak2[2]) == true or is_numeric($arrmak2[2])==false){
						$err = $err+1;
						$errVal .="Makmin array is not define well";
					}

					if (empty($arrmak2[3]) == true or is_numeric($arrmak2[3])==false){
						$err = $err+1;
						$errVal .="Makmin array is not define well";
					}
				}
			}
		}

        //Check totMakmin
        if(is_numeric($totMakmin)==false){
        	$err = $err+1;
			$errVal .="Total Makmin";
        } else {
        	if (empty($makmin)==false and $totMakmin == 0) {
        		$err = $err+1;
				$errVal .="Total Makmin not consistent";
        	}
        }
        $error = array();
        $error[0]=$err;
        $error[1]=$errVal;
        return $error;
	}

	public function pilih_kursi($id_jadwal){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "users"){
            redirect('users/signin');
        } else {
        	if ($this->jadwal_mod->is_adaId($id_jadwal)==false) {
        		$kursi_prev = trim($this->input->post('seats'));
        		$error = array();
        		if (empty($kursi_prev)==false) {
        			$error = $this->validate_Kursi($kursi_prev,1);
        		} else {
        			$error[0]=0;
        		}

        		if ($error[0]==0) {
        			$daftar["tiket"] = $this->jadwal_mod->getJadwal_Tiket($id_jadwal);
					$daftar["kursi"] = $this->tiket_mod->cek_Kursi($id_jadwal);
					$daftar["kursi_prev"] = trim($this->input->post('seats'));
					$kapasitas = $daftar["tiket"]['kapasitas'];
					$this->load->view('v_main');
					$this->load->view('v_header_kursi',$daftar);
					$this->load->view('v_kursi_'.$kapasitas,$daftar);	
        		}else {
        			redirect('home/');
        		}
        	} else {
				redirect('home/');
			}
        }
	}
	
	public function pilih_makmin($id_jadwal){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "users"){
            redirect('users/signin');
        } else {
        	if ($this->jadwal_mod->is_adaId($id_jadwal)==false) {
        		$kursi = trim($this->input->post('seats'));
        		$jumKursi = trim($this->input->post('jumkursi'));

        		$error = $this->validate_Kursi($kursi,$jumKursi);

        		if ($error[0]==0) {
        			$daftar["list"] = $this->makmin_mod->get_all();
					$daftar["tiket"] = $this->jadwal_mod->getJadwal_Tiket($id_jadwal);
					$daftar["seatslist"] = array(
						'seats' => $kursi,
						'jumkursi' => $jumKursi,
					);

					$this->load->view('v_main');
					$this->load->view('v_header_Makmin',$daftar);
					$this->load->view('v_makanan',$daftar);
        		}else{
        			$this->session->set_flashdata('warning', "Silahkan pilih kursi terlebih dahulu sebelum melanjutkan");
					redirect('tiket/pilih_kursi/'.$id_jadwal);
        		}	
        	} else {
				redirect('home/');
			}	
		}
	}

	public function pembayaran($id_jadwal){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "users"){
            redirect('users/signin');
        } else {
        	if ($this->jadwal_mod->is_adaId($id_jadwal)==false) {
        		$kursi = trim($this->input->post('seats'));
        		$jumKursi = trim($this->input->post('jumkursi'));

        		$makmin = trim($this->input->post('makmin'));
        		$totMakmin = trim($this->input->post('makmintotal'));

        		$error_kurs = $this->validate_Kursi($kursi,$jumKursi);
        		$error_mak = $this->validate_Makmin($makmin,$totMakmin);

        		if ($error_kurs[0]==0 and $error_mak[0]==0) {
        			$daftar["tiket"] = $this->jadwal_mod->getJadwal_Tiket($id_jadwal);
					$daftar["list"] = array(
						'seats' => $kursi,
						'jumkursi' => $jumKursi,
						'makmin' => $makmin,
						'makmintotal' => $totMakmin,
					);
					$this->session->set_flashdata('warning', $makmin);
					$this->load->view('v_main');
					$this->load->view('v_header_bayarPesanan',$daftar);
					$this->load->view('v_bayarPesanan',$daftar);
        		} else {
					$this->session->set_flashdata('warning', $error_mak[1]." ".$error_kurs[1]);
					redirect('tiket/pilih_kursi/'.$id_jadwal);
				}
	        		
        	}else {
				redirect('home/');
			}
		}
	}

	public function simpan_tiket() {
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "users"){
            redirect('users/signin');
        } else {
        	$nohp = $this->input->post('nohp');
			$tikets = array(
				'id_tikets' => $this->input->post('id_tikets'),
				'email' => $this->input->post('email'),
				'tanggal_beli'=> $this->input->post('tanggal'),
				'id_jadwal' => $this->input->post('id_jadwal'),
				'makmin' => $this->input->post('makmin'),
				'kursi' => $this->input->post('kursi'),
				'harga' => $this->input->post('harga'),
			);
			$this->tiket_mod->tambah_tikets($tikets);
			$daftar["tiket"] = $this->tiket_mod->getData_Tiket($email);
			redirect('tiket/lihat_tiket/'.$nohp);
		}
	}

	public function lihat_tiket($nohp) {
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "users"){
            redirect('users/signin');
        } else {
        	if ($this->session->userdata('nohp') == $nohp) {
        		$daftar["tiket"] = $this->tiket_mod->getData_Tiket($nohp);
				$this->load->view('v_main');
				$this->load->view('v_header_nd',$daftar);
				$this->load->view('v_lihatTiket',$daftar);
				$this->load->view('v_footer');
        	}else{
        		redirect('home/');
			}
        }
	}

	public function detail_tiket($id_tikets) {
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "users"){
            redirect('users/signin');
		} else {
			$daftar["tiket"] = $this->tiket_mod->getData_byID($id_tikets);
			if ($this->session->userdata('email') == $daftar["tiket"]['email']) {
				$this->load->view('v_main');
				$this->load->view('v_header_nd');
				$this->load->view('v_detail_Tiket',$daftar);
				$this->load->view('v_footer');
			}else{
        		redirect('home/');
			}
		}
	}

}