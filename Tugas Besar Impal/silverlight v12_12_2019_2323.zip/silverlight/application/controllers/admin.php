<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('film_mod');
		$this->load->model('makmin_mod');
		$this->load->model('bioskop_mod');
		$this->load->model('users_mod');
		$this->load->model('theater_mod');
		$this->load->model('jadwal_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function index(){
		if($this->session->userdata('status') == "login" and $this->session->userdata('type') == "admin"){
            redirect('admin/home');
        } else {
			$this->load->view('v_main');
			$this->load->view('v_header_admin');
			$this->load->view('v_signin_admin');
		}
	}

	public function signin(){
		$email = trim($this->input->post('email'));
		$sandi = md5($this->input->post('sandi'));
		if ($this->users_mod->is_ada($email, 'admin') == false) {
			$akun = $this->users_mod->get($email, 'admin');
			if ($akun['sandi'] == $sandi) {

				$data_session = array(
					'email' => $akun['email'],
					'username' => $akun['nama'],
					'nohp' => $akun['nohp'],
					'type' => "admin",
					'status' => "login",
				);
				$this->session->set_userdata($data_session);
				redirect('admin/home');
			} else {
				$this->session->set_flashdata('error', "email atau sandi yang anda masukkan salah");
				redirect('admin/');
			}
		} else {
			$this->session->set_flashdata('error', "email atau sandi yang anda masukkan salah");
			redirect('admin/');
		}
	}

	public function signout(){
		$this->session->sess_destroy();
		redirect('admin/');
	}

	public function home(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
        	$daftar["countFilm"] = $this->film_mod->count_table();
			$daftar["countMakmin"] = $this->makmin_mod->count_table();
			$daftar["countBioskop"] = $this->bioskop_mod->count_table();
			$daftar["countUsers"] = $this->users_mod->count_table('users');

			$this->load->view('v_main');
			$this->load->view('v_header_admin');
			$this->load->view('v_dashboard_admin');
			$this->load->view('v_adminHome',$daftar);
        }
	}

// Admin Film
	public function admin_Film(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$daftar["search"] = "";
			$daftar["list"] = $this->film_mod->get_all();
			
			$this->load->view('v_main');
			$this->load->view('v_header_admin');
			$this->load->view('v_dashboard_admin');
			$this->load->view('v_adminTable_Film',$daftar);
		}
	}

	public function cari_film(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$search = $_GET["scTabFilm"];
			$daftar["search"] = $search;
			$daftar["list"] = $this->film_mod->search($search);

			$this->load->view('v_main');
			$this->load->view('v_header_admin');
			$this->load->view('v_dashboard_admin');
			$this->load->view('v_adminTable_Film', $daftar);
		}
	}

	public function detail_film($id_film){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->film_mod->is_adaId($id_film)==false) {
				$daftar["data"] = $this->film_mod->get($id_film);

				$this->load->view('v_main');
				$this->load->view('v_header_admin');
				$this->load->view('v_dashboard_admin');
				$this->load->view('v_detail_film',$daftar);
			} else {
				redirect('admin/admin_Film/');
			}
		}
	}

	public function tambah_film(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$this->load->view('v_main');
			$this->load->view('v_header_admin');
			$this->load->view('v_dashboard_admin');
			$this->load->view('v_tambah_Film');
		}
	}

	public function edit_film($id_film){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->film_mod->is_adaId($id_film)==false) {
				$daftar["data"] = $this->film_mod->get($id_film);
				$this->load->view('v_main');
				$this->load->view('v_header_admin');
				$this->load->view('v_dashboard_admin');
				$this->load->view('v_edit_Film', $daftar);
			} else {
				redirect('admin/admin_Film/');
			}
		}
	}


// Admin Bioskop
	public function admin_Bioskop(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$daftar["search"] = "";
			$daftar["list"] = $this->bioskop_mod->get_all();

			
			$this->load->view('v_main');
			$this->load->view('v_header_admin');
			$this->load->view('v_dashboard_admin');
			$this->load->view('v_adminTable_Bioskop',$daftar);
		}
	}

	public function cari_bioskop(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$search = $_GET["scTabBioskop"];
			$daftar["search"] = $search;
			$daftar["list"] = $this->bioskop_mod->search($search);

			$this->load->view('v_main');
			$this->load->view('v_header_admin');
			$this->load->view('v_dashboard_admin');
			$this->load->view('v_adminTable_Bioskop', $daftar);
		}
	}

	public function detail_bioskop($id_bioskop){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->bioskop_mod->is_adaId($id_bioskop)==false) {
				$daftar["data"] = $this->bioskop_mod->get($id_bioskop);
				$daftar["theater"] = $this->theater_mod->get_withIdBioskop($id_bioskop);
				$daftar["memutar"] = 
				$this->load->view('v_main');
				$this->load->view('v_header_admin');
				$this->load->view('v_dashboard_admin');
				$this->load->view('v_detail_Bioskop',$daftar);
			} else {
				redirect('admin/admin_Bioskop/');
			}
		}
	}

	public function tambah_bioskop(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$this->load->view('v_main');
			$this->load->view('v_header_admin');
			$this->load->view('v_dashboard_admin');
			$this->load->view('v_tambah_Bioskop');
		}
	}

	public function edit_bioskop($id_bioskop){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->bioskop_mod->is_adaId($id_bioskop)==false) {
				$daftar["data"] = $this->bioskop_mod->get($id_bioskop);
				$this->load->view('v_main');
				$this->load->view('v_header_admin');
				$this->load->view('v_dashboard_admin');
				$this->load->view('v_edit_Bioskop', $daftar);
			} else {
				redirect('admin/admin_Bioskop/');
			}
		}
	}


//admin Makmin
	public function admin_Makmin(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$daftar["search"] = "";
			$daftar["list"] = $this->makmin_mod->get_all();
			
			$this->load->view('v_main');
			$this->load->view('v_header_admin');
			$this->load->view('v_dashboard_admin');
			$this->load->view('v_adminTable_Makmin',$daftar);
		}
	}

	public function cari_makmin(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$search = $_GET["scTabMakmin"];
			$daftar["search"] = $search;
			$daftar["list"] = $this->makmin_mod->search($search);

			$this->load->view('v_main');
			$this->load->view('v_header_admin');
			$this->load->view('v_dashboard_admin');
			$this->load->view('v_adminTable_Makmin',$daftar);
		}
	}

	public function detail_makmin($id_makmin){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->makmin_mod->is_adaId($id_makmin)==false) {
				$daftar["data"] = $this->makmin_mod->get($id_makmin);
				$this->load->view('v_main');
				$this->load->view('v_header_admin');
				$this->load->view('v_dashboard_admin');
				$this->load->view('v_detail_Makmin',$daftar);
			} else {
				redirect('admin/admin_Makmin/');
			}
		}
	}

	public function tambah_makmin(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$this->load->view('v_main');
			$this->load->view('v_header_admin');
			$this->load->view('v_dashboard_admin');
			$this->load->view('v_tambah_Makmin');
		}
	}

	public function edit_makmin($id_makmin){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->makmin_mod->is_adaId($id_makmin)==false) {
				$daftar["data"] = $this->makmin_mod->get($id_makmin);
				$this->load->view('v_main');
				$this->load->view('v_header_admin');
				$this->load->view('v_dashboard_admin');
				$this->load->view('v_edit_Makmin', $daftar);
			} else {
				redirect('admin/admin_Makmin/');
			}
		}
	}


//admin Theater
	public function detail_theater($id_theater){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
        	if ($this->theater_mod->is_adaId($id_theater)==false) {
				$daftar["theater"] = $this->theater_mod->get($id_theater);
				$daftar["Alltheater"] = $this->theater_mod->get_withIdBioskop($daftar["theater"]["id_bioskop"]);
				$daftar["filmTayang"] = $this->film_mod->get_tayang();
				$daftar["filmAkan"] = $this->film_mod->get_akan("all");
				$daftar["data"] = $this->bioskop_mod->get($daftar["theater"]["id_bioskop"]);
				$daftar["memutar"] = $this->jadwal_mod->get_memutar($id_theater);
				$daftar["allJadwalBioskop"] = $this->jadwal_mod->get_specJadwalBioskop($daftar["theater"]["id_bioskop"]);
				$this->load->view('v_main');
				$this->load->view('v_header_admin');
				$this->load->view('v_dashboard_admin');
				$this->load->view('v_detail_Theater',$daftar);
			} else {
				redirect('admin/admin_Bioskop/');
			}
		}
	}

//admin Users
	public function admin_Users(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$daftar["search"] = "";
			$daftar["list"] = $this->users_mod->get_all();
			
			$this->load->view('v_main');
			$this->load->view('v_header_admin');
			$this->load->view('v_dashboard_admin');
			$this->load->view('v_adminTable_Users',$daftar);
		}
	}
}