<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class makmin extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('makmin_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function validate($nama_makmin,$keterangan,$harga){
		$err = 0;
		$errVal ="";

		//Check nama makmin
		if (empty($nama_makmin) == true) {
            $err = $err+1;
            $errVal .= "Nama Makmin, ";
        }

        //Check keterangan
		if (empty($keterangan) == true) {
            $err = $err+1;
            $errVal .= "Keterangan, ";
        }

		//Check harga
		if (empty($harga)==true or is_numeric($harga)==false) {
            $err = $err+1;
            $errVal .= "Harga, ";
        }

        $error = array();
        $error[0]=$err;
        $error[1]=$errVal;
        return $error;	
	}

	public function tambah(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$nama_makmin = trim($this->input->post('nama_makmin'));
			$keterangan = trim($this->input->post('keterangan'));
			$harga = trim($this->input->post('harga'));

			$error = $this->validate($nama_makmin,$keterangan,$harga);

			if ($error[0]==0) {
				$id_Makmin = uniqid('MKN-');
				$cekada = $this->makmin_mod->is_ada($nama_makmin);
				if ($cekada==true) {
					$config['upload_path']          = './other/asset/makmin';
					$config['allowed_types']        = 'png';
					$config['file_name'] 			= $id_Makmin;
						 
					$this->load->library('upload', $config);

					if($this->upload->do_upload('gambarMakmin')){
						$uploadData = $this->upload->data();

						$makmin = array(
							'id_makmin' => $id_Makmin,
							'nama_makmin' => $nama_makmin,
							'keterangan' => $keterangan,
							'harga' => $harga,
						);

						$this->makmin_mod->tambah_makmin($makmin);
						$this->session->set_flashdata('update', "Makmin berhasil ditambah");
			        	redirect('admin/admin_Makmin');
					}else{
			        	$this->session->set_flashdata('error', "1 Errors found. Data submit error: noFile for 'gambarMakmin'");
						redirect('admin/tambah_makmin');
			        }
				} else {
					$this->session->set_flashdata('error', "Nama Makmin sudah terdaftar");
					redirect('admin/tambah_makmin');
				}	
			} else {
				$this->session->set_flashdata('error', $error[0]." Errors found. Data submit error: ".$error[1]);
	       		redirect('admin/tambah_makmin');
			}
		}	
	}

	public function edit($id){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->makmin_mod->is_adaId($id)==false) {
				$id_Makmin = $id;
				$nama_makmin = trim($this->input->post('nama_makmin'));
				$keterangan = trim($this->input->post('keterangan'));
				$harga = trim($this->input->post('harga'));

				$error = $this->validate($nama_makmin,$keterangan,$harga);
				if ($error[0]==0) {
					$cekada = $this->makmin_mod->is_ada($nama_makmin);
					$before = $this->makmin_mod->get($id_Makmin);
					if ($cekada==true or $before[nama_makmin]==$nama_makmin) {
						$makmin = array(
							'id_makmin' => $id_Makmin,
							'nama_makmin' => $nama_makmin,
							'keterangan' => $keterangan,
							'harga' => $harga,
						);

						if (!(!isset($_FILES['gambarMakmin']) || $_FILES['gambarMakmin']['error'] == UPLOAD_ERR_NO_FILE)) {
							unlink("./other/asset/makmin/".$id_Makmin.".png");
							$config['upload_path']          = './other/asset/makmin';
							$config['allowed_types']        = 'png';
							$config['file_name'] 			= $id_Makmin;
							$this->load->library('upload', $config);
							$this->upload->do_upload('gambarMakmin');
							$uploadData = $this->upload->data();
						}

						$this->makmin_mod->update_makmin($id_Makmin, $makmin);
						$this->session->set_flashdata('update', "Makmin berhasil diedit");
				        redirect('admin/detail_makmin/'.$id_Makmin);

				    } else {
				    	$this->session->set_flashdata('error', "Nama Makmin sudah terdaftar");
						redirect('admin/edit_makmin/'.$id_Makmin);
				    }
				} else {
					$this->session->set_flashdata('error', $error[0]." Errors found. Data submit error: ".$error[1]);
		       		redirect('admin/edit_makmin/'.$id_Makmin);
				}
			} else {
				redirect('admin/admin_Makmin/');
			}
		}	
	}

	public function hapus($id){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->makmin_mod->is_adaId($id)==false) {
				$id_Makmin = $id;
				if ($this->input->post('terms')=="yes") {
					$this->makmin_mod->delete_makmin($id_Makmin);
					unlink("./other/asset/makmin/".$id_Makmin.".png");
					$this->session->set_flashdata('update', "Makmin berhasil dihapus");
					redirect('admin/admin_Makmin');
				} else {
					$this->session->set_flashdata('error', "Makmin gagal dihapus");
				    redirect('admin/detail_makmin/'.$id_Makmin);
				}
			} else {
				redirect('admin/admin_Makmin/');
			}
		}
	}
	
}