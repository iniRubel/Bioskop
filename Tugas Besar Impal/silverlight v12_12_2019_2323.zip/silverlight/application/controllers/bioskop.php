<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class bioskop extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('bioskop_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function validate($nama_bioskop,$no_telp,$alamat,$kota){
		$err = 0;
		$errVal ="";

		//Check nama bioskop
		if (empty($nama_bioskop) == true) {
            $err = $err+1;
            $errVal .= "Nama Bioskop, ";
        }

        //Check noTelp
        if (empty($no_telp)==true or preg_match('/^[0-9]{12}+$/', $no_telp)==false) {
			$err = $err+1;
			$errVal .="Nomor Telpon, ";
		}

		//Check alamat
		if (empty($alamat)==true) {
            $err = $err+1;
            $errVal .= "Alamat, ";
        }

        //Check kota
		if (empty($kota)==true) {
            $err = $err+1;
            $errVal .= "Kota, ";
        }
        $error = array();
        $error[0]=$err;
        $error[1]=$errVal;
        return $error;	
	}

//admin punya
	public function tambah(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$nama_bioskop = trim($this->input->post('nama_bioskop'));
			$no_telp = trim($this->input->post('no_telp'));
			$alamat = trim($this->input->post('alamat'));
			$kota = trim($this->input->post('kota'));

			$error = $this->validate($nama_bioskop,$no_telp,$alamat,$kota);
	       	if ($error[0]==0) {
	       		$id_Bioskop = uniqid('BSKP-');

				$cekada = $this->bioskop_mod->is_ada($nama_bioskop);
				if ($cekada==true) {
					$config['upload_path']          = './other/asset/bioskop';
					$config['allowed_types']        = 'jpg';
					$config['file_name'] 			= $id_Bioskop;
						 
					$this->load->library('upload', $config);
					if ($this->upload->do_upload('gambarBioskop')) {
						$uploadData = $this->upload->data();

						$bioskop = array(
							'id_bioskop' => $id_Bioskop,
							'nama_bioskop' => $nama_bioskop,
							'no_telp' => $no_telp,
							'alamat' => $alamat,
							'kota' => $kota,
						);
						$this->bioskop_mod->tambah_bioskop($bioskop);
						$this->session->set_flashdata('update', "Bioskop berhasil ditambah");
				        redirect('admin/admin_Bioskop');
					} else {
						$this->session->set_flashdata('error', "1 Errors found. Data submit error: noFile for 'gambarBioskop'");
						redirect('admin/tambah_bioskop');
					}
				} else {
					$this->session->set_flashdata('error', "Nama Bioskop sudah terdaftar");
					redirect('admin/tambah_bioskop');
				}	
	       	} else {
	       		$this->session->set_flashdata('error', $error[0]." Errors found. Data submit error: ".$error[1]);
	       		redirect('admin/tambah_bioskop');
	       	}
       	}		
	}

	public function edit($id){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->bioskop_mod->is_adaId($id)==false) {
				$id_Bioskop = $id;
				$nama_bioskop = trim($this->input->post('nama_bioskop'));
				$no_telp = trim($this->input->post('no_telp'));
				$alamat = trim($this->input->post('alamat'));
				$kota = trim($this->input->post('kota'));

				$error = $this->validate($nama_bioskop,$no_telp,$alamat,$kota);
				if ($error[0]==0) {
					$cekada = $this->bioskop_mod->is_ada($nama_bioskop);
					$before = $this->bioskop_mod->get($id_Bioskop);
					if ($cekada==true or $before[nama_bioskop]==$nama_bioskop) {
						$bioskop = array(
							'nama_bioskop' => $nama_bioskop,
							'no_telp' => $no_telp,
							'alamat' => $alamat,
							'kota' => $kota,
						);

						if (!(!isset($_FILES['gambarBioskop']) || $_FILES['gambarBioskop']['error'] == UPLOAD_ERR_NO_FILE)) {
							unlink("./other/asset/bioskop/".$id_Bioskop.".jpg");
							$config['upload_path']          = './other/asset/bioskop';
							$config['allowed_types']        = 'jpg';
							$config['file_name'] 			= $id_Bioskop;
							$this->load->library('upload', $config);
							$this->upload->do_upload('gambarBioskop');
							$uploadData = $this->upload->data();
						}

						$this->bioskop_mod->update_bioskop($id_Bioskop, $bioskop);
						$this->session->set_flashdata('update', "Bioskop berhasil diedit");
				        redirect('admin/detail_bioskop/'.$id_Bioskop);

				    } else {
				    	$this->session->set_flashdata('error', "Nama Bioskop sudah terdaftar");
						redirect('admin/edit_bioskop/'.$id_Bioskop);
				    }
				} else {
					$this->session->set_flashdata('error', $error[0]." Errors found. Data submit error: ".$error[1]);
		       		redirect('admin/edit_bioskop/'.$id_Bioskop);
				}
			} else {
				redirect('admin/admin_Bioskop/');
			}
		}
	}

	public function hapus($id){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->bioskop_mod->is_adaId($id)==false) {
				$id_Bioskop = $id;
				if ($this->input->post('terms')=="yes") {
					$this->bioskop_mod->delete_bioskop($id_Bioskop);
					unlink("./other/asset/bioskop/".$id_Bioskop.".jpg");
					$this->session->set_flashdata('update', "Bioskop berhasil dihapus");
					redirect('admin/admin_Bioskop');
				} else {
					$this->session->set_flashdata('error', "Bioskop gagal dihapus");
				    redirect('admin/detail_bioskop/'.$id_Bioskop);
				}
			} else {
				redirect('admin/admin_Bioskop/');
			}
		}
	}
	
}