<?php

class x_unittest_makmin extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		$this->load->library('unit_test');
		
		$this->load->model('makmin_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function validate($nama_makmin,$keterangan,$harga){
		$err = 0;
		$errVal ="";

		//Check nama makmin
		if (empty($nama_makmin) == true) {
            $err = $err+1;
            $errVal .= "Nama Makmin, ";
        }

        //Check keterangan
		if (empty($keterangan) == true) {
            $err = $err+1;
            $errVal .= "Keterangan, ";
        }

		//Check harga
		if (empty($harga)==true or is_numeric($harga)==false) {
            $err = $err+1;
            $errVal .= "Harga, ";
        }

        $error = array();
        $error[0]=$err;
        $error[1]=$errVal;
        return $error;	
	}

	public function tambah($ses, $a, $b, $c,$gambar){
		if($ses=='admin'){
			$nama_makmin = trim($a);
			$keterangan = trim($b);
			$harga = trim($c);

			$error = $this->validate($nama_makmin,$keterangan,$harga);

			if ($error[0]==0) {
				$id_Makmin = "randomly generated";
				$cekada = $this->makmin_mod->is_ada($nama_makmin);
				if ($cekada==true) {
					if($gambar == true){
						$makmin = array(
							'id_makmin' => $id_Makmin,
							'nama_makmin' => $nama_makmin,
							'keterangan' => $keterangan,
							'harga' => $harga,
						);
						return $hasil= array($makmin, 'gambar upload = true') ;
					}else{
			        	return "gambar upload = false";
			        }
				} else {
					return "Nama Makmin sudah terdaftar";
				}	
			} else {
				return $error[0]." Errors found. Data submit error: ".$error[1];
			}	
		} else {
			return "bukan admin";
		}
			
	}

	public function edit($ses, $a, $b, $c, $d, $gambar){
		if($ses=='admin'){
			if ($this->makmin_mod->is_adaId($a)==false) {
				$id_Makmin = $a;
				$nama_makmin = trim($b);
				$keterangan = trim($c);
				$harga = trim($d);

				$error = $this->validate($nama_makmin,$keterangan,$harga);
				if ($error[0]==0) {
					$cekada = $this->makmin_mod->is_ada($nama_makmin);
					$before = $this->makmin_mod->get($id_Makmin);
					if ($cekada==true or $before[nama_makmin]==$nama_makmin) {
						$makmin = array(
							'id_makmin' => $id_Makmin,
							'nama_makmin' => $nama_makmin,
							'keterangan' => $keterangan,
							'harga' => $harga,
						);

						$hasiltest='';
						if ($gambar==true) {
							$hasiltest .='gambar update = true';
						} else {
							$hasiltest .='gambar update = false';
						}

						return $hasil= array($makmin, $hasiltest) ;

				    } else {
				    	return "Nama Makmin sudah terdaftar";
				    }
				} else {
					return $error[0]." Errors found. Data submit error: ".$error[1];
				}
			} else {
				return "Nothing happen";
			}	
		}
	}

	public function hapus($ses, $a, $term){
		if($ses=='admin'){
			if ($this->makmin_mod->is_adaId($a)==false) {
				$id_Makmin = $a;
				if ($term=="yes") {
					return "Makmin berhasil dihapus";
				} else {
					return "Makmin gagal dihapus";
				}
			} else {
				return "Nothing happen";
			}
		}
	}

	public function report_dataNormal(){
		//Method validate()
		$validate = $this->validate("Nama Makmin","iniket kk","14000");
		$hasil = array(0, "");
		$this->unit->run($validate, $hasil, "validate() Makmin testing - Data Normal");

		//Method tamabah()
		$tambah = $this->tambah("admin","Nama Makmin","iniket kk","14000",true);
		$makmin_tambah = array(
			'id_makmin' => "randomly generated",
			'nama_makmin' => "Nama Makmin",
			'keterangan' => "iniket kk",
			'harga' => "14000",
		);
		$hasil2 = array($makmin_tambah, "gambar upload = true");
		$this->unit->run($tambah, $hasil2, "tambah() Makmin testing - Data Normal");

		//Method edit()
		$edit = $this->edit("admin","MKN-5debbb0d4d881","Nama Makmin Baru","iniket baru kk","14000",false);
		$makmin_edit = array(
			'id_makmin' => "MKN-5debbb0d4d881",
			'nama_makmin' => "Nama Makmin Baru",
			'keterangan' => "iniket baru kk",
			'harga' => "14000",
		);
		$hasil3 = array($makmin_edit, "gambar update = false");
		$this->unit->run($edit, $hasil3, "edit() Makmin testing - Data Normal");

		//Method hapus()
		$hapus = $this->hapus("admin", "MKN-5debbb0d4d881", "yes");
		$this->unit->run($hapus, "Makmin berhasil dihapus", "hapus() Makmin testing - Data Normal");

		echo $this->unit->report();
	}

	public function report_dataSalah(){

		//Method validate()
		$validate = $this->validate("Nama Makmin","iniket kk","14K");
		$hasil = array(1, "Harga, ");
		$this->unit->run($validate, $hasil, "validate() Makmin testing - Data Salah");

		//Method tamabah()
		$tambah = $this->tambah("admin","Sandwitch","iniket kk","14000",true);
		$hasil2 = "Nama Makmin sudah terdaftar";
		$this->unit->run($tambah, $hasil2, "tambah() Makmin testing - Data Salah");

		//Method edit()
		$edit = $this->edit("admin","MKN-5debbb0d4d881"," ","iniket baru kk","14K",false);
		$hasil3 = "2 Errors found. Data submit error: Nama Makmin, Harga, ";
		$this->unit->run($edit, $hasil3, "edit() Makmin testing - Data Salah");

		//Method hapus()
		$hapus = $this->hapus("admin", " ", " ");
		$this->unit->run($hapus, "Nothing happen", "hapus() Makmin testing - Data Salah");

		echo $this->unit->report();
	}
}