<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class theater extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('theater_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function validate($no_theater,$kapasitas,$id_bioskop){
		$err = 0;
		$errVal ="";

		//Check no_theater
		if (empty($no_theater) == true or preg_match('/^thr-+[0-9]{1,2}$/', $no_theater)==false) {
            $err = $err+1;
            $errVal .= "No_theater, ";
        }

        //Check kapasitas
        if (empty($kapasitas)==true or ($kapasitas == 160 or $kapasitas == 238)==false) {
			$err = $err+1;
			$errVal .="Kapasitas, ";
		}

		//Check id_bioskop
		if (empty($id_bioskop)==true or preg_match('/^BSKP-+[0-9A-Za-z]{13}$/', $id_bioskop)==false) {
            $err = $err+1;
            $errVal .= "id_bioskop, ";
        }
        $error = array();
        $error[0]=$err;
        $error[1]=$errVal;
        return $error;
	}

	public function tambah($id_bioskop){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$no_theater = 'thr-'.trim($this->input->post('no_theater'));
			$kapasitas = trim($this->input->post('kapasitas'));

			$error = $this->validate($no_theater,$kapasitas,trim($id_bioskop));

			if ($error[0]==0) {
				$id_theater = uniqid('THTR-');
				$cekada = $this->theater_mod->is_ada($id_bioskop,$no_theater);
				if ($cekada==true) {
					$theater = array(
						'id_theater' => $id_theater,
						'no_theater' => $no_theater,
						'kapasitas' => $kapasitas,
						'id_bioskop' => $id_bioskop,
					);

					$this->theater_mod->tambah_theater($theater);
					$this->session->set_flashdata('updateTheater', "Theater berhasil ditambah");
			        redirect('admin/detail_bioskop/'.$id_bioskop);
			    } else {
					$this->session->set_flashdata('errorTheater', "Nomor Theater sudah terdaftar di Bioskop ini");
					redirect('admin/detail_bioskop/'.$id_bioskop);
				}
			} else {
				$this->session->set_flashdata('errorTheater', $error[0]." Errors found. Data submit error: ".$error[1]);
	       		redirect('admin/detail_bioskop/'.$id_bioskop);
			}	
		}
	}

	public function edit($id_theater){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->theater_mod->is_adaId($id_theater)==false) {
				$id_theater = $id_theater;
				$no_theater = trim($this->input->post('no_theater'));
				$kapasitas = trim($this->input->post('kapasitas'));
				$id_bioskop = trim($this->input->post('id_bioskop'));

				$error = $this->validate($no_theater,$kapasitas,$id_bioskop);

				if ($error[0]==0) {
					$theater = array(
						'id_theater' => $id_theater,
						'no_theater' => $no_theater,
						'kapasitas' => $kapasitas,
						'id_bioskop' => $id_bioskop,
					);

					$this->theater_mod->update_theater($id_theater, $theater);
					$this->session->set_flashdata('updateTheater', "Theater berhasil diedit");
				    redirect('admin/detail_bioskop/'.$id_bioskop);
				} else {
					$this->session->set_flashdata('errorTheater', $error[0]." Errors found. Data submit error: ".$error[1]);
		       		redirect('admin/detail_bioskop/'.$id_bioskop);
				}	
			} else {
				redirect('admin/admin_bioskop/');
			}	
		}
	}

	public function hapus($id_theater){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->theater_mod->is_adaId($id_theater)==false) {
				$id_theater = $id_theater;
				$th = $this->theater_mod->get($id_theater);
				if ($this->input->post('terms')=="yes") {
					$this->theater_mod->delete_theater($id_theater);
					$this->session->set_flashdata('update', "Theater berhasil dihapus");
					redirect('admin/detail_bioskop/'.$th['id_bioskop']);
				} else {
					$this->session->set_flashdata('error', "Theater gagal dihapus");
				    redirect('admin/detail_bioskop/'.$th['id_bioskop']);
				}
			} else {
				redirect('admin/admin_bioskop/');
			}
		}
	}

}