<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class film extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('users_mod');
		$this->load->model('film_mod');
		$this->load->model('jadwal_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function validate($judul,$durasi,$sinopsis,$gendre,$sutradara,$rating,$link_trailer,$rilisRange){
		$err = 0;
		$errVal ="";

		//Check judul
		if (empty($judul) == true) {
            $err = $err+1;
            $errVal .= "Judul, ";
        }

        //Check durasi
		if (empty($durasi) == true or preg_match("/^[0-9]{1,3}+ Minutes$/", $durasi)==false ) {
            $err = $err+1;
            $errVal .= "Durasi, ";
        }

        //Check sinopsis
		if (empty($sinopsis) == true) {
            $err = $err+1;
            $errVal .= "Sinopsis, ";
        }

        //Check gendre
		if (empty($gendre) == true) {
            $err = $err+1;
            $errVal .= "Gendre, ";
        }

        //Check sutradara
		if (empty($sutradara) == true) {
            $err = $err+1;
            $errVal .= "Sutradara, ";
        }

        //Check rating
		if (empty($rating) == true or ($rating == "rating_su" or $rating == "rating_13" or $rating == "rating_17" or $rating == "rating_21")==false) {
            $err = $err+1;
            $errVal .= "Rating, ";
        }

        //Check link_trailer
		if (empty($link_trailer) == true) {
            $err = $err+1;
            $errVal .= "Link trailer, ";
        }

        //Check rilisRange
		if (empty($rilisRange) == true or preg_match("/^[0-9]{4}+-[0-9]{1,2}+-[0-9]{1,2}+ - +[0-9]{4}+-[0-9]{1,2}+-[0-9]{1,2}$/", $rilisRange)==false) {
            $err = $err+1;
            $errVal .= "Rilis, ";
        }
        
        $error = array();
        $error[0]=$err;
        $error[1]=$errVal;
        return $error;	
	}

//admin punya
	public function tambah(){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$judul =  trim($this->input->post('judul'));
			$durasi =  trim($this->input->post('durasi').' Minutes');
			$sinopsis = trim($this->input->post('sinopsis'));
			$gendre = trim($this->input->post('gendre'));
			$sutradara = trim($this->input->post('sutradara'));
			$rating = trim($this->input->post('rating'));
			$link_trailer = trim($this->input->post('link_trailer'));
			$rilisRange = trim($this->input->post('rilisRange'));
			
			$error = $this->validate($judul,$durasi,$sinopsis,$gendre,$sutradara,$rating,$link_trailer,$rilisRange);

			if ($error[0]==0) {
				$id_film = uniqid('FLM-');

				$config['upload_path']          = './other/asset/film';
				$config['allowed_types']        = 'jpg';
				$config['file_name'] 			= $id_film.'_img';
				$this->load->library('upload', $config);
				$fileErr = 0;
				$fileErrVal = "";
				if (!($this->upload->do_upload('poster'))) {
					$fileErr = $fileErr+1;
					$fileErrVal .= "'poster', ";
				}
				if (!($this->upload->do_upload('gambarFilm1'))) {
					$fileErr = $fileErr+1;
					$fileErrVal .= "'gambarFilm1', ";
				}
				if (!($this->upload->do_upload('gambarFilm2'))) {
					$fileErr = $fileErr+1;
					$fileErrVal .= "'gambarFilm2', ";
				}
				if (!($this->upload->do_upload('gambarFilm3'))) {
					$fileErr = $fileErr+1;
					$fileErrVal .= "'gambarFilm3', ";
				}
				
				
				if ($fileErr==0) {
					$uploadData = $this->upload->data();

			        $dateSplit = explode(" - ",$rilisRange);
			        $film = array(
						'id_film' => $id_film,
						'judul' => $judul,
						'durasi' => $durasi,
						'sinopsis' => $sinopsis,
						'gendre' => $gendre,
						'sutradara' => $sutradara,
						'rating' => $rating,
						'link_trailer' => $link_trailer,
						'rilis_start'=> $dateSplit[0],
						'rilis_end'=> $dateSplit[1],
					);

					$this->film_mod->tambah_film($film);
					$this->session->set_flashdata('update', "Film berhasil ditambah");
			        redirect('admin/admin_Film');
				} else {
					$this->session->set_flashdata('error', $fileErr." Errors found. Data submit error: noFile for ".$fileErrVal);
		       		redirect('admin/tambah_film');
				}
			} else {
				$this->session->set_flashdata('error', $error[0]." Errors found. Data submit error: ".$error[1]);
	       		redirect('admin/tambah_film');
			}
		}
	}

	public function edit($id){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->film_mod->is_adaId($id)==false) {
				$id_film = $id;
				$judul =  trim($this->input->post('judul'));
				$durasi =  trim($this->input->post('durasi').' Minutes');
				$sinopsis = trim($this->input->post('sinopsis'));
				$gendre = trim($this->input->post('gendre'));
				$sutradara = trim($this->input->post('sutradara'));
				$rating = trim($this->input->post('rating'));
				$link_trailer = trim($this->input->post('link_trailer'));
				$rilisRange = trim($this->input->post('rilisRange'));
				
				$config['upload_path']          = './other/asset/film';
				$config['allowed_types']        = 'jpg';
				$config['file_name'] 			= $id_film.'_img';
				$this->load->library('upload', $config);

				if (!(!isset($_FILES['poster']) || $_FILES['poster']['error'] == UPLOAD_ERR_NO_FILE)) {
					unlink("./other/asset/film/".$id_film."_img.jpg");
					$this->upload->do_upload('poster');
				}

				if (!(!isset($_FILES['gambarFilm1']) || $_FILES['gambarFilm1']['error'] == UPLOAD_ERR_NO_FILE)) {
					unlink("./other/asset/film/".$id_film."_img1.jpg");
					$this->upload->do_upload('gambarFilm1');
				}

				if (!(!isset($_FILES['gambarFilm2']) || $_FILES['gambarFilm2']['error'] == UPLOAD_ERR_NO_FILE)) {
					unlink("./other/asset/film/".$id_film."_img2.jpg");
					$this->upload->do_upload('gambarFilm2');
				}

				if (!(!isset($_FILES['gambarFilm3']) || $_FILES['gambarFilm3']['error'] == UPLOAD_ERR_NO_FILE)) {
					unlink("./other/asset/film/".$id_film."_img3.jpg");
					$this->upload->do_upload('gambarFilm3');
				}
				
		        $uploadData = $this->upload->data();

		        $error = $this->validate($judul,$durasi,$sinopsis,$gendre,$sutradara,$rating,$link_trailer,$rilisRange);
		        if ($error[0]==0) {
		        	$rilisRange = $this->input->post('rilisRange');
			        $dateSplit = explode(" - ",$rilisRange);

			        $film = array(
						'id_film' => $id_film,
						'judul' => $judul,
						'durasi' => $durasi,
						'sinopsis' => $sinopsis,
						'gendre' => $gendre,
						'sutradara' => $sutradara,
						'rating' => $rating,
						'link_trailer' => $link_trailer,
						'rilis_start'=> $dateSplit[0],
						'rilis_end'=> $dateSplit[1],
					);

					$this->film_mod->update_film($id_film, $film);
					$this->session->set_flashdata('update', "Film berhasil diedit");
			        redirect('admin/detail_Film/'.$id_film);
		        } else {
		        	$this->session->set_flashdata('error', $error[0]." Errors found. Data submit error: ".$error[1]);
		       		redirect('admin/edit_film/'.$id_film);
		        }
		    } else {
				redirect('admin/admin_Film/');
			}
		}
	}

	public function hapus($id){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			if ($this->film_mod->is_adaId($id)==false) {
				$id_Film = $id;
				if ($this->input->post('terms')=="yes") {
					$this->film_mod->delete_film($id_Film);
					unlink("./other/asset/film/".$id_Film."_img.jpg");
					unlink("./other/asset/film/".$id_Film."_img1.jpg");
					unlink("./other/asset/film/".$id_Film."_img2.jpg");
					unlink("./other/asset/film/".$id_Film."_img3.jpg");
					$this->session->set_flashdata('update', "Film berhasil dihapus");
					redirect('admin/admin_Film');
				} else {
					$this->session->set_flashdata('error', "Film gagal dihapus");
				    redirect('admin/detail_film/'.$id_Film);
				}
			} else {
				redirect('admin/admin_Film/');
			}
		}
	}

//user punya

	public function book($id_film){
		if ($this->film_mod->is_adaId($id_film)==false) {
			$daftar["data"] = $this->film_mod->get($id_film);
			$daftar["avilable"] = $this->jadwal_mod->get_jadwalfilm_avilable($id_film); 
			$daftar["jadwal"] = $this->jadwal_mod->get_jadwalfilm($id_film); 
			$this->load->view('v_main');
			$this->load->view('v_header_nd');
			$this->load->view('v_film',$daftar);
			$this->load->view('v_footer');
		} else {
			redirect('home/');
		}
	}


}