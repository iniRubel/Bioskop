<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class kursi extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('makmin_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function index(){
		$this->load->view('v_main');
		$this->load->view('v_header_kursi');
		$this->load->view('v_kursi');
		$this->load->view('v_footer');
	}
	public function pesan_kursi(){
		$daftar["search"] = "";
		$daftar["list"] = $this->makmin_mod->get_all();

		$daftar["tiket"] = array(
			'judulfilm' => $this->input->post('judulfilm'),
			'namabioskop' => $this->input->post('namabioskop'),
			'haritanggal' => $this->input->post('haritanggal'),
			'jam' => $this->input->post('jam'),
			'alamat' => $this->input->post('alamat'),
			'seats' => $this->input->post('seats'),
			'jumkursi' => $this->input->post('jumkursi'),
		);
		$this->load->view('v_main');
		$this->load->view('v_header_Makmin');
		$this->load->view('v_makanan',$daftar);
		$this->load->view('v_footer');
	}

}