<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('users_mod');
		$this->load->model('film_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function index(){
		$daftar["tayang"] = $this->film_mod->get_tayang();
		$daftar["akan"] = $this->film_mod->get_akan("notAll");
		$this->load->view('v_main');
		$this->load->view('v_header_st');
		$this->load->view('v_home', $daftar);
		$this->load->view('v_footer');
	}
}