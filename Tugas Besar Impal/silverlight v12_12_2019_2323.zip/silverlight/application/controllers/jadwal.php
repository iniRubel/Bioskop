<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class jadwal extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('jadwal_mod');
		$this->load->model('theater_mod');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}

	public function validate($tanggal,$jam,$oldJam,$id_theater,$id_film,$status){
		$err = 0;
		$errVal ="";

		//Check tanggal
		if (empty($tanggal) == true or preg_match("/^[0-9]{4}+-[0-9]{1,2}+-[0-9]{1,2}$/", $tanggal)==false) {
            $err = $err+1;
            $errVal .= "Tanggal, ";
        }

        //Check jam
        if (empty($jam)==false) {
        	$i=0;
	        foreach ($jam as $row) {
	        	if (empty($row) == true or preg_match("/^[0-9]{2}+:[0-9]{2}+:[0-9]{2}$/", $row)==false) {
		            $err = $err+1;
		            $errVal .= "jam[".$i."], ";
		            $i=$i+1;
		        }
	        }
        } else {
        	$err = $err+1;
        	$errVal .= "Jam[null], ";
        }

        //Check oldJam
        $x=0;
	    foreach ($oldJam as $row) {
	        if (empty($row) == true or preg_match("/^[0-9]{2}+:[0-9]{2}+:[0-9]{2}$/", $row)==false) {
		        $err = $err+1;
		        $errVal .= "oldJam[".$x."], ";
		        $x=$x+1;
		    }
	    }
          
		//Check id_theater
		if (empty($id_theater)==true or preg_match('/^THTR-+[0-9A-Za-z]{13}$/', $id_theater)==false) {
            $err = $err+1;
            $errVal .= "id_theater, ";
        }

        //Check id_film
		if (empty($id_film)==true or preg_match('/^FLM-+[0-9A-Za-z]{13}$/', $id_film)==false) {
            $err = $err+1;
            $errVal .= "id_film, ";
        }

        $error = array();
        $error[0]=$err;
        $error[1]=$errVal;
        return $error;

        //Check status
        if (empty($status)==true or $status!="nonactive" or $status!="active") {
            $err = $err+1;
            $errVal .= "status, ";
        }

        $error = array();
        $error[0]=$err;
        $error[1]=$errVal;
        return $error;
	}

	public function tambah($id_theater){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$tanggal = trim($this->input->post('tanggal'));
			$jam = $_POST['jam'];
			$id_film = trim($this->input->post('id_film'));
			$id_theater = trim($id_theater);
			$status = "nonactive";


			$error = $this->validate($tanggal,$jam,$jam,$id_theater,$id_film,$status);

			if ($error[0]==0) {
				$sameDate = "";
				$errDate = 0;
				$theater = $this->theater_mod->get($id_theater);
				if ($this->jadwal_mod->is_ada_jadDate($tanggal,$theater['id_theater']) == false) {
					$errDate = $errDate + 1;
				} else {
					foreach ($jam as $jab) {
						$cekadaF = $this->jadwal_mod->is_ada_jadFilm($tanggal,$jab,$theater['id_bioskop'],$id_film);
						if ($cekadaF == false) {
							$sameDate .= $jab.", ";
							$errDate = $errDate + 1;
						}
					}
				}
					

				
				if ($errDate==0) {
					foreach ($jam as $row) {
						$id_jadwal = uniqid('JDW-');
						$jadwal = array(
							'id_jadwal' => $id_jadwal,
							'tanggal' => $tanggal,
							'jam' => $row,
							'id_theater' => $id_theater,
							'id_film' => $id_film,
							'status' => "nonactive",
						);

						$this->jadwal_mod->tambah_jadwal($jadwal);
					}
					$this->session->set_flashdata('update', "Jadwal berhasil ditambah");
			        redirect('admin/detail_theater/'.$id_theater);
			    } else {
					$this->session->set_flashdata('error', "Jadwal sudah terdaftar di Theater ini atau Theater lain - [".$tanggal."] [".$sameDate."]");
					redirect('admin/detail_theater/'.$id_theater);
				}
			} else {
				$this->session->set_flashdata('error', $error[0]." Errors found. Data submit error: ".$error[1]);
	       		redirect('admin/detail_theater/'.$id_theater);
			}	
		}
	}

	public function ubahJadwal($id_theater){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$tanggal = trim($this->input->post('tanggal'));

			$jam = $_POST['jam'];
			$oldJam = trim($this->input->post('oldJam'));
			$oldJamList = explode(",",$oldJam);

			$id_film = trim($this->input->post('id_film'));
			$id_theater = trim($id_theater);
			$status = trim($this->input->post('status'));


			$error = $this->validate($tanggal,$jam,$oldJamList,$id_theater,$id_film,$status);


			if ($error[0]==0) {
				if ($status=='nonactive') {

					$hapus=array_diff($oldJamList,$jam);
					foreach ($hapus as $hap){
						$jadHapus = $this->jadwal_mod->get_specJadwalTheater_jam($hap,$tanggal,$id_theater);
						$this->jadwal_mod->delete_jadwal($jadHapus['id_jadwal']);
					}

					$sameDate = "";
					$errDate = 0;

					$tambah=array_diff($jam,$oldJamList);
					$theater = $this->theater_mod->get($id_theater);
					foreach ($tambah as $tam){
						$cekada = $this->jadwal_mod->is_ada_jadFilm($tanggal,$tam,$theater['id_bioskop'],$id_film);
						if ($cekada == false) {
							$sameDate .= $tam.", ";
							$errDate = $errDate + 1;
						} else {
							$id_jadwal = uniqid('JDW-');
							$jadTambah = array(
								'id_jadwal' => $id_jadwal,
								'tanggal' => $tanggal,
								'jam' => $tam,
								'id_theater' => $id_theater,
								'id_film' => $id_film,
								'status' => $status,
							);

							$this->jadwal_mod->tambah_jadwal($jadTambah);	
						}	
					}

					if ($errDate > 0) {
						$this->session->set_flashdata('error', "Tanggal [".$tanggal."] dan atau Jam [".$sameDate."] tidak dapat ditambah karena Jam Jadwal sudah terdaftar di Theater lain");
					}
					
							
					$this->session->set_flashdata('update', "Jadwal berhasil diubah");
				    redirect('admin/detail_theater/'.$id_theater);
				    
				} else {
					$this->session->set_flashdata('error', "Status jadwal dalam keadaan Aktif. Tidak dapat mengubah jadwal");
					redirect('admin/detail_theater/'.$id_theater);
				}
			} else {
				$this->session->set_flashdata('error', $error[0]." Errors found. Data submit error: ".$error[1]);
	       		redirect('admin/detail_theater/'.$id_theater);
			}	
		}
	}

	public function aktifJadwal($id_theater){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$id_theater = trim($id_theater);
			$tanggal = trim($this->input->post('tanggal'));

			$err = 0;
			$errVal ="";

			//Check tanggal
			if (empty($tanggal) == true or preg_match("/^[0-9]{4}+-[0-9]{1,2}+-[0-9]{1,2}$/", $tanggal)==false) {
	            $err = $err+1;
	            $errVal .= "Tanggal, ";
	        }

	        //Check id_theater
			if (empty($id_theater)==true or preg_match('/^THTR-+[0-9A-Za-z]{13}$/', $id_theater)==false) {
	            $err = $err+1;
	            $errVal .= "id_theater, ";
	        }

	        if ($err==0) {

	        	$activate = $this->jadwal_mod->get_jadwalTheater($tanggal,$id_theater);
	        	foreach ($activate as $row) {
	        		$activJadwal = array(
						'id_jadwal' => $row['id_jadwal'],
						'tanggal' => $row['tanggal'],
						'jam' => $row['jam'],
						'id_theater' => $row['id_theater'],
						'id_film' => $row['id_film'],
						'status' => 'active',
					);
	        		$this->jadwal_mod->update_jadwal($row['id_jadwal'], $activJadwal);	
	        	}

				$this->session->set_flashdata('update', "Jadwal berhasil diaktifkan");
				redirect('admin/detail_theater/'.$id_theater);
				    
				
			} else {
				$this->session->set_flashdata('error', $error[0]." Errors found. Data submit error: ".$error[1]);
	       		redirect('admin/detail_theater/'.$id_theater);
			}
		}
	}

	public function hapusJadwal($id_theater){
		if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
            redirect('admin/');
        } else {
			$id_theater = trim($id_theater);
			$tanggal = trim($this->input->post('tanggal'));

			$err = 0;
			$errVal ="";

			//Check tanggal
			if (empty($tanggal) == true or preg_match("/^[0-9]{4}+-[0-9]{1,2}+-[0-9]{1,2}$/", $tanggal)==false) {
	            $err = $err+1;
	            $errVal .= "Tanggal, ";
	        }

	        //Check id_theater
			if (empty($id_theater)==true or preg_match('/^THTR-+[0-9A-Za-z]{13}$/', $id_theater)==false) {
	            $err = $err+1;
	            $errVal .= "id_theater, ";
	        }

	        if ($err==0) {

	        	$activate = $this->jadwal_mod->get_jadwalTheater($tanggal,$id_theater);
	        	foreach ($activate as $jad) {
	        		$this->jadwal_mod->delete_jadwal($jad['id_jadwal']);	
	        	}

				$this->session->set_flashdata('update', "Jadwal - ".$tanggal." berhasil dikosongkan");
				redirect('admin/detail_theater/'.$id_theater);
				    
				
			} else {
				$this->session->set_flashdata('error', $error[0]." Errors found. Data submit error: ".$error[1]);
	       		redirect('admin/detail_theater/'.$id_theater);
			}
		}
	}


}