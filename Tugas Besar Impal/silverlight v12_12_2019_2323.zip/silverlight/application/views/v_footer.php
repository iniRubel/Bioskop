<center>
    <div class="social">
        <img class="social_icon" src="<?php echo base_url()?>other/asset/social/f.svg" alt="">
        <img class="social_icon" src="<?php echo base_url()?>other/asset/social/t.svg" alt="">
        <img class="social_icon" src="<?php echo base_url()?>other/asset/social/y.svg" alt="">
        <img class="social_icon" src="<?php echo base_url()?>other/asset/social/i.svg" alt="">
    </div>
</center>

<div class="footer">
    <div class="container-fluid contain">
        <div class="row">
            <div class="col-lg-3">
                <h3><b>Silverlight Media</b></h3>
                <p>Profile</p>
                <p>Media Center</p>
                <p>Advertisement</p>
                <p>Job Opportunities</p>
                <a href="<?php echo base_url() ?>admin" class="linknav">Staff</a>
            </div>
            <div class="col-lg-3">
                <h3><b>Film</b></h3>
                <p>Sedang Tayang</p>
                <p>Akan Tayang</p>
                <p>Film Pilihan</p>

            </div>
            <div class="col-lg-3">
                <h3><b>Our Cinema</b></h3>
                <p>Cinema Region</p>
                <p>IMAX at SIlverlight Theater</p>
                <p>Dolby at Silverlight Theater</p>
                <p>RealID 3D at Silverlight Theater</p>
            </div>
            <div class="col-lg-3">
                <h3><b>Help</b></h3>
                <p>Sitemap</p>
                <p>Privacy Policy</p>
                <p>Terms & Conditions</p>
                <p>FAQ's</p>
            </div>
        </div>

</div>
    <center>
        <img style="margin-top: 65px" src="<?php echo base_url()?>other/asset/icon/logo.svg" alt="">
    </center>

</div>
</div>