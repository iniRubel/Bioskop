<div style="background-image: url('<?php echo base_url()?>other/asset/latar/page1.png'); background-size: cover; background-repeat: repeat-y; background-position: 50% 10px; background-size: 1850px;">

<div class="container-fluid contain" style="margin-top: 90px;">
	<div style="padding: 0px 140px 0px 140px" style="margin-top: 90px;">
		<div class="row">
			<div class="col-3">
				<div class="col-12">
					<img class="film_detail_poster" src="<?php echo base_url()?>other/asset/film/<?php echo $data['id_film']?>_img.jpg" alt="">	
				</div>
				<div class="col-5">
					<img class="film_detail_poster" src="<?php echo base_url()?>other/asset/icon/<?php echo $data['rating']?>.svg" alt="">	
				</div>
			</div>
			<div class="col-9" style="padding-left: 40px">
				<div class="row">
					<h1 class="heading1"><?php echo $data['judul']?></h1>
					<iframe class="film_detail_vid" src="<?php echo $data['link_trailer'] ?>" frameborder="0" allowfullscreen></iframe>
				</div>
				<div class="row">
					<p style="font-size: 15px;color: #207ED9"><?php echo $data['gendre'] ?></p>
				</div>
				<div class="row">
					<p class="tulisan"><?php echo $data['sinopsis']?></p>
				</div>
				<div class="row">
					<p class="tulisan"><span style="font-weight: bold;">Durasi: </span><?php echo $data['durasi']?></p>
				</div>
				<div class="row">
					<p class="tulisan"><span style="font-weight: bold;">Sutradara: </span><?php echo $data['sutradara']?></p>
				</div>
				<div class="row" style="margin-top: 25px;">
					<div class="col-4">
                        <img class="film_detail_img" src="<?php echo base_url()?>other/asset/film/<?php echo $data['id_film']?>_img1.jpg" alt="">
                    </div>
					<div class="col-4">
						<img class="film_detail_img" src="<?php echo base_url()?>other/asset/film/<?php echo $data['id_film']?>_img2.jpg" alt="">
					</div>
					<div class="col-4">
						<img class="film_detail_img" src="<?php echo base_url()?>other/asset/film/<?php echo $data['id_film']?>_img3.jpg" alt="">
					</div>
					
				</div>
			</div>
		</div>
	</div>
</div>
<div class="container-fluid contain" style="margin-bottom: 300px;">
	<div style="padding: 0px 140px 0px 140px">
		<div class="row">
			<div class="col-12">
				<div style="display: flex;">
				<div class="accessories"><p></p></div>
				<h1 class="heading1">Pesan Tiket</h1>	
			</div>	
			</div>
		</div>

		<?php
			if (empty($avilable)==true){
				echo "<p style='color: white; font-weight: bold;'>Jadwal Masih Belum Tersedia</p>";
			} else {

		?>
		<div class="row" style="margin-bottom: 40px;">
			<input type="text" id="firstDate" style="display: none" value="<?php echo $avilable[0]['tanggal']?>" />
			<?php
				foreach ($avilable as $avil) {
			?>
				<button id="<?php echo $avil['tanggal'].'_b';?>" onclick="showJadwal('<?php echo $avil['tanggal'];?>')" class="book_hari btn <?php if($avil['tanggal']==$avilable[0]['tanggal']) { echo 'btn-primary ';} else {echo 'btn-secondary ';}?>">
					<?php echo date('D', strtotime($avil['tanggal']));?><br>
					<?php echo date('d', strtotime($avil['tanggal']));?>
				</button>
			<?php
				}
			?>
		</div>
		<div class="row">
			<?php
				foreach ($jadwal as $jad) {
			?>
				<div class="<?php echo $jad['tanggal'];?> col-12 film_list" style="padding: 40px 40px 30px 40px; margin-bottom: 20px; <?php if($jad['tanggal']==$avilable[0]['tanggal']) { echo 'display: block; ';} else {echo 'display: none; ';}?>">
					<span style="font-size: 30px; font-weight: bold"><?php echo $jad['nama_bioskop'];?></span><br>
					<span style="font-size: 18px;"><?php echo $jad['alamat'];?> | </span><span style="font-size: 18px;"><?php echo $jad['kota'];?></span><br><br>
					<div class="row" style="padding-left: 20px;">
						<?php
							 $jamList = explode(",",$jad['allJam']);
							 $idList = explode(",",$jad['allId']);
							 $inx = 0;
							 foreach ($jamList as $jam) {
						?>
							<div style="width: 150px; margin-right: 20px; margin-bottom: 20px;">
								<a href="<?php echo base_url()."tiket/pilih_kursi/".trim($idList[$inx])?>" style="<?php if($jad['tanggal']==date("Y-m-d") and time() >= strtotime($jam)) { echo 'pointer-events: none;';}?>">
		                            <button id="table_theater_button" type="button" class="btn btn-primary tombol <?php if($jad['tanggal']==date("Y-m-d") and time() >= strtotime($jam)) { echo 'btn-secondary';}?>" style="height: 100%; padding: 15px;" <?php if($jad['tanggal']==date("Y-m-d") and time() >= strtotime($jam)) { echo 'disabled';}?>> 
		                                <b><?php echo substr(trim($jam), 0, 5) ?></b>
		                            </button>
		                        </a>
	                        </div>
						<?php
								$inx = $inx + 1;
							}
						?>
					</div>
				</div>
			<?php
				}
			?>
			<script>
                var prev = document.getElementById("firstDate").value;

                function showJadwal(tanggal) {

                	var x = document.getElementsByClassName(tanggal);
                    for (i = 0; i < x.length; i++) {
					    if (x[i].style.display === "none") {
                        	x[i].style.display = "block";
                    	}
					}
                    document.getElementById(tanggal+'_b').classList.add("btn-primary");
                    document.getElementById(tanggal+'_b').classList.remove("btn-secondary");

					var p = document.getElementsByClassName(prev);
		            if (prev != tanggal) {
			        	for (j = 0; j < p.length; j++) {
						    if (p[j].style.display === "block") {
			                	p[j].style.display = "none";
		                	}
						}    		
		            }
		            document.getElementById(prev+'_b').classList.add("btn-secondary");
		            document.getElementById(prev+'_b').classList.remove("btn-primary");
                   	prev=tanggal;
                } 
                </script>
		</div>
		<?php
			}
		?>
	</div>
</div>
