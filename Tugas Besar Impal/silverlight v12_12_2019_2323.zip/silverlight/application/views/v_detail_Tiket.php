<div style="margin-top: 80px;" class="container-fluid contain">
	<div class="row">
		<div class="col-12">
            <div class="row">
			<div style="display: flex;">
				<div class="accessories"><p></p></div>
				<h1 class="heading1">Detail Tiket</h1>
                <p style="color: white;font-size: 20px;margin-top: 26px;margin-left: 40px;">id. <?php echo $tiket['id_tikets']?></p>	
			</div>
            <div class="col-9">
            <div style="background-color: white;display: flex;border-radius: 30px;" class="detail">
                <img style="border-radius: 30px;padding: 20px;height: 280px;width: 190px;" src="<?php echo base_url()?>other/asset/film/<?php echo $tiket['id_film']?>_img.jpg">
                <div style="width: 350px;">
                    <p style="font-size: 25px;margin-top: 30px;"><b><?php echo $tiket['judul']?></b></p>
                    <p style="font-size: 20px;margin-top: 20px;">Cinema</p>
                    <p style="margin-left: 40px;"><b><?php echo $tiket['nama_bioskop']?></b></p>
                    <p style="color: #969696;margin-left: 40px;"><?php echo $tiket['alamat']?></p>
                </div>
                <div>
                    <p style="margin-top: 35px;font-size: 20px;">Tanggal</p>
                    <p><b><?php echo $tiket['tanggal']?></b></p>
                    <p>Jam</p>
                    <p style="margin-left: 40px;"><b><?php echo $tiket['jam']?></b></p>
                    <p>Seats</p>
                    <p style="margin-left: 40px;color: #1E77CD"><?php echo $tiket['kursi']?></p>
                </div>               
            </div>
            <script type="text/javascript">
                $(document).ready(function(){
                    var data = "<?php echo $tiket['makmin']; ?>";
                    var makanan = data.split(",")
                    var m = 1;
                    if (makanan.length > 1) {
                    while (m <= makanan.length) {
                        $("#makmin").append("<p style='margin-left:40px;'><b>"+makanan[m]+"</b></p>");
                        m = m+5;
                    }
                    m = 2;
                    while (m <= makanan.length) {
                        $("#hargamakmin").append("<p>"+makanan[m]+" x "+makanan[m+1]+"</p>");
                        m = m+5;
                    }
                    }
                })
            </script>
            <div class="col-7">
                <div style="display: flex;background-color: white;border-radius: 30px;margin-top: 20px; padding: 10px;" class="sad">
                    <div id="makmin" style="margin-right: 228px;">
                        <p><b>Snacks and Drinks</b></p>
                    </div>
                    <div id="hargamakmin">
                        <p></p></br>
                    </div>
                    
                </div>
            </div>
            </div>
            <div class="col-3">
                <div style="background-color: white;padding: 20px;border-radius: 30px;" class="barcode">
                    <center>
                    <img style="height: 220px;width:220px; " src="<?php echo base_url()?>other/asset/icon/barcode.png">
                    </center>
                </div>
                <div style="display: flex;background-color: #0EA34A;margin-top: 40px;padding-left: 40px;padding-top: 15px;border-radius: 30px;color: white;" class="harga">
                    <p style="margin-right: 100px;"><b>Total</b></p>
                    <p><b>Rp. <c><?php echo $tiket['harga']; ?></c></b></p>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>