<div style="background-image: url('<?php echo base_url()?>other/asset/latar/home.png'); background-size: cover;background-repeat: no-repeat; background-position: 50% 30%; background-size: 700px; height: 100%">

<div class="container-fluid contain" style="margin-top: 90px;">
	<div class="row justify-content-center">
		<div class="col-4">
			<div style="display: flex;">
				<div class="accessories"><p></p></div>
				<h1 class="heading1">Sign In</h1>

			</div>
		</div>
	</div>
	<div class="row justify-content-center">
		<div class="col-4" style="padding-right: 27px;">
			<?php  
                if (empty($this->session->flashdata('error'))==false) {
                    echo "
                        <div class='col-12 alert alert-danger' role='alert' style='margin-bottom: 40px;'>
                            ".$this->session->flashdata('error')."
                        </div>
                    ";
                }
            ?>
			<div class="sign_box">
				<form action="<?php echo base_url(). 'admin/signin';?>" style="padding-bottom: 15px;" method="post">
					<div class="form_contain">
						Email
						<input type="email" name="email" required class="form-control form-rounded">
						<ul style='color: #b94a48; padding-top: 5px;'>
							<?php echo $this->session->flashdata('message2');?>
						</ul>	
					</div>
					<div class="form_contain">
						Sandi
						<input type="password" name="sandi" required class="form-control form-rounded">
						<ul style='color: #b94a48; padding-top: 5px;'>
							<?php echo $this->session->flashdata('message0');?>
							<?php echo $this->session->flashdata('message1');?>
						</ul>
						<div style="text-align: right; color: #0069d9">
							Lupa Sandi?
						</div>
					</div>
					<div class="form_contain">
						<button type="submit" class="btn btn-primary tombol">Sign In</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
</div>