<div style="background-image: url('<?php echo base_url()?>other/asset/latar/home.png'); background-size: cover;background-repeat: no-repeat; background-position: 50% 50%; background-size: 2500px;">
    

<center style="margin-top: 90px;">
    <img style="padding-top: 65px;" src="<?php echo base_url()?>other/asset/icon/logo.svg" alt="">
</center>
<div class="container-fluid contain">
	<div class="row">
		<div class="col-12">
			<div style="display: flex;">
				<div class="accessories"><p></p></div>
				<h1 class="heading1">Sedang Tayang</h1>	
			</div>	
		</div>
	</div>
	<div class="row">
        <?php 
            foreach ($tayang as $row){
        ?>
            <div class="col-lg-2" style="margin-bottom: 30px">
                <div class="film_list" style="height: 100%; position: relative; width: 100%; ">
                    <img class="film_list_img" src="<?php echo base_url()?>other/asset/film/<?php echo $row['id_film']?>_img.jpg" alt="">
                    <p><b><?php echo $row['judul'] ?></b></p>
                    <p style="font-size: 15px;color: #207ED9 "><?php echo $row['gendre'] ?></p>
                    <div>
                        <br>
                    </div>
                    <div style="position: absolute; width: 100%; bottom: 15px; padding-right: 30px;">
                        <a href="<?php echo base_url()?>film/book/<?php echo $row['id_film']?>"><button type="button" class="btn btn-primary tombol">Book Now</button></a>   
                    </div>
                        
                </div>
            </div>
        <?php } ?>
	</div>
</div>

<div class="container-fluid contain">
	<div class="row">
		<div class="col-12">
			<div style="background-color: gray; height: 600px; border-radius: 2rem">
                <img class="post_img" src="<?php echo base_url()?>other/asset/post/knives out.jpg" alt="">
                <div class="post_gradient">
                    <div class="post_block">
                        <img style="padding-top: 65px; width: 200px" src="<?php echo base_url()?>other/asset/icon/logo.svg" alt="">
                        <h1 class="post_title">Everyone Have A Motive. No One Has A Clue</h1>
                        <p class="post_deskription">Sebuah pembunuhan telah terjadi, tapi pelakunya masih tidak diketahui. Ada diantara mereka bisa saja melakukannya</p>   
                        <a href="<?php echo base_url()?>film/book/FLM-5dd6a43d1c473"><button type="button" class="btn btn-primary tombol">Book Now</button></a>
                    </div> 
                </div>
			</div>	
		</div>
	</div>
</div>

<div class="container-fluid contain">
    <div class="row">
        <div class="col-12">
            <div style="display: flex;">
                <div class="accessories"><p></p></div>
                <h1 class="heading1">Akan Tayang</h1>   
            </div>  
        </div>
    </div>
    <div class="row">
        <?php 
            foreach ($akan as $row){
        ?>
            <div class="col-lg-2" style="margin-bottom: 30px">
                <div class="film_list" style="height: 100%; position: relative; width: 100%; ">
                    <img class="film_list_img" src="<?php echo base_url()?>other/asset/film/<?php echo $row['id_film']?>_img.jpg" alt="">
                    <p><b><?php echo $row['judul'] ?></b></p>
                    <p style="font-size: 15px;color: #207ED9 "><?php echo $row['gendre'] ?></p>
                    <div>
                        <br>
                    </div>
                    <div style="position: absolute; width: 100%; bottom: 15px; padding-right: 30px;">
                        <a href="<?php echo base_url()?>film/book/<?php echo $row['id_film']?>"><button type="button" class="btn btn-primary tombol">Book Now</button></a>   
                    </div>
 
                </div>
            </div>
        <?php } ?>

            <div class="col-lg-2" style="margin-bottom: 30px">
                <div class="film_list" style="height: 100%; position: relative; width: 100%; ">
                    <button type="button" class="btn btn-primary" style="width: 100%; height: 100%; border-radius: 2rem;">
                        <div style="margin-bottom: 24px">
                            <img src="<?php echo base_url()?>other/asset/icon/next.svg">
                        </div>
                        <b>Lihat Semua</b>
                    </button>
                </div>
            </div>
    </div>
</div>

</div>