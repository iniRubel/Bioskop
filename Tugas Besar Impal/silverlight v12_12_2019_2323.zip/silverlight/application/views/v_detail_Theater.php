        <div class="col-10 dashboard-right" style="margin-left: 300px;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-10">
                        <div style="display: flex;">
                            <div class="accessories" style="height: 100px;"><p></p></div>
                            <h1 class="heading1" style="font-size: 80px"><a style="color: white" href="<?php echo base_url()?>admin/admin_Bioskop">Bioskop</a> > <a style="color: white" href="<?php echo base_url()."admin/detail_bioskop/".$data['id_bioskop']?>"><?php echo $data['nama_bioskop'] ?></a> ></h1> 
                        </div> 
                    </div>
                </div>

                <div class="row" style="margin-bottom: 40px;">
                    <div class="col-3">
                        <img class="bioskop_list_img" src="<?php echo base_url()?>other/asset/bioskop/<?php echo $data['id_bioskop']?>.jpg" alt="">
                    </div>
                    <div class="col-9" style="padding-left: 60px">
                        <div class="row" style="margin-bottom: 25px">
                            <span class="tulisan" style="font-weight: bold; font-size: 30px"><?php echo $data['nama_bioskop']?></span>
                        </div>
                        <div class="row" style="margin-bottom: 25px">
                            <div>
                                <span class="tulisan" style="font-weight: bold;">Alamat:</span><br>
                                <span class="tulisan"><?php echo $data['alamat']?></span>
                            </div>
                        </div>
                        <div class="row" style="margin-bottom: 25px">
                            <div>
                                <span class="tulisan" style="font-weight: bold;">Nomor Telpon: </span><br>
                                <span class="tulisan"><?php echo $data['no_telp']?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 film_list">
                        <div class="row">
                            <?php foreach ($Alltheater as $thr) {?>
                                <div class="col-2" style="padding-bottom: 20px;">
                                    <a href="<?php echo base_url()."admin/detail_theater/".$thr['id_theater']?>">
                                        <button id="table_theater_button" type="button" class="btn btn-primary <?php if($theater['id_theater']!=$thr['id_theater']) { echo 'btn-secondary';} ?>" style="width: 100%; height: 100%; border-radius: 1rem; padding: 20px"> 
                                            <div>
                                                <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/bioskop.svg">    
                                            </div> 
                                            <b><?php echo $thr['no_theater']?></b>
                                        </button>
                                    </a>
                                </div>
                            <?php }?>

                            <div class="col-12" style=";margin-top: 25px; padding: 45px">
                                <?php  
                                    if (empty($this->session->flashdata('update'))==false) {
                                        echo "
                                            <div class='col-12 alert alert-success' role='alert' style='margin-bottom: 40px;'>
                                                ".$this->session->flashdata('update')."
                                            </div>
                                        ";
                                    }
                                    if (empty($this->session->flashdata('error'))==false) {
                                        echo "
                                            <div class='col-12 alert alert-danger' role='alert' style='margin-bottom: 40px;'>
                                                ".$this->session->flashdata('error')."
                                            </div>
                                        ";
                                    }
                                ?>
                                <div style="display: flex;">
                                    <div class="accessories"><p></p></div>
                                    <h1 class="heading1"><?php echo $theater['no_theater'] ?> at <span style="color: grey"><?php echo $data['nama_bioskop']?></span></h1>
                                </div>
                                    <div class="add_box">
                                        <span style="font-size: 30px; color: #2196F3" onclick="formTamJadwalSh()"><b>Tambah Jadwal</b></span><br><br>
                                        <form action="<?php echo base_url(). 'jadwal/tambah/'. $theater['id_theater'];?>" style="padding-bottom: 15px; padding-left: 50px;" method="post">
                                            <div id="formTamJadwal">
                                            <?php foreach ($allJadwalBioskop as $jadBioskop) { ?>  
                                                <div id='<?php echo $jadBioskop['tanggal']."_".$jadBioskop['id_film']?>' class='col-12 alert alert-warning' role='alert' style='margin-bottom: 40px; display: none'>
                                                    <?php echo "Film ini sudah terisi di tanggal yang sama dalam bisokop ini pada jadwal berikut: <br>[".$jadBioskop['tanggal']."] [".$jadBioskop['allJam']."]"; ?>
                                                </div>
                                            <?php } ?>

                                            <div  class="row" >


                                                <div class="col-3">
                                                    <label for="exampleFormControlSelect1">Judul Film</label><br>
                                                    <div class="form-group">
                                                        <select id="filmselect" name="id_film" class="form-control form-rounded" style="height: 44px; width: 100%;" required onchange="previewPoster(); previewTaken()">
                                                            <option value="">--- Film ---</option>
                                                            <?php
                                                                foreach ($filmTayang as $row) {
                                                                    echo "<option id='".$row['rilis_start']."_".$row['rilis_end']."' value='".$row['id_film']."'>".$row['judul']." - ".$row['durasi']."</option>";
                                                                }
                                                                foreach ($filmAkan as $row) {
                                                                    echo "<option id='".$row['rilis_start']."_".$row['rilis_end']."' value='".$row['id_film']."'>".$row['judul']." - ".$row['durasi']."</option>";
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                    
                                                    <div id="demo">
                                                        
                                                    </div>
                                                    <script>
                                                        function previewPoster() {
                                                            var x = document.getElementById("filmselect").value;
                                                            if (x != "") {
                                                                var local = <?php echo json_encode(base_url().'other/asset/film/')?>;
                                                                document.getElementById("demo").innerHTML = "<img class='film_detail_poster' src='"+local+x+"_img.jpg'/>";    
                                                            }else{
                                                                document.getElementById("demo").innerHTML = "<br>";
                                                            }

                                                        }
                                                    </script>
                                                </div>

                                                <div class="col-9" style="padding-left: 50PX;">
                                                    <label for="exampleFormControlSelect1">Tanggal Tayang</label><br>
                                                    <div class="form-group">
                                                        <input id="rilis" class="form-control form-rounded" type="text" name="tanggal" style="width: 200px;" required onchange="previewTaken()">

                                                        <script>
                                                            function isEmpty(obj) {
                                                                for(var key in obj) {
                                                                    if(obj.hasOwnProperty(key))
                                                                        return false;
                                                                }
                                                                return true;
                                                            }
                                                            var prev = null;
                                                            function previewTaken(){
                                                                var f = $('#filmselect').val();
                                                                var g = $('#rilis').val();
                                                                
                                                                var x = document.getElementById(g+'_'+f);
                                                                if (x!=null) {
                                                                    if (x.style.display === "none") {
                                                                        x.style.display = "block";
                                                                    } else {
                                                                        x.style.display = "none";
                                                                    }    
                                                                }

                                                                var p = document.getElementById(prev);
                                                                if (p!=null) {
                                                                    if (p.style.display === "block") {
                                                                        p.style.display = "none";
                                                                    }   
                                                                }
                                                                prev = g+"_"+f;
                                                            }
                                                        </script>

                                                        <script>
                                                            document.getElementById('filmselect').addEventListener('change', function(e) {
                                                            // Date Picket
                                                                var rilis = e.target.options[e.target.selectedIndex].getAttribute('id').split("_");
                                                                var today = new Date();

                                                                if (new Date(rilis[0]) <= today) {
                                                                    today = today;
                                                                } else if (new Date(rilis[0]) > today){
                                                                    today = new Date(rilis[0]);
                                                                }
                                                                var end =  new Date(rilis[1]);
                                                                
                                                                var dd = String(today.getDate()).padStart(2, '0');
                                                                var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
                                                                var yyyy = today.getFullYear();


                                                                today = yyyy + '-' + mm + '-' + dd;
                                                                $('#rilis').daterangepicker({
                                                                    "singleDatePicker": true,
                                                                    "locale": {
                                                                        "format": "YYYY-MM-DD",
                                                                        "separator": " - ",
                                                                        "applyLabel": "Apply",
                                                                        "cancelLabel": "Cancel",
                                                                        "fromLabel": "From",
                                                                        "toLabel": "To",
                                                                        "customRangeLabel": "Custom",
                                                                        "weekLabel": "W",
                                                                        "daysOfWeek": [
                                                                            "Min",
                                                                            "Sen",
                                                                            "Sel",
                                                                            "Rab",
                                                                            "Kam",
                                                                            "Jum",
                                                                            "Sab"
                                                                        ],
                                                                        "monthNames": [
                                                                            "January",
                                                                            "February",
                                                                            "March",
                                                                            "April",
                                                                            "May",
                                                                            "June",
                                                                            "July",
                                                                            "August",
                                                                            "September",
                                                                            "October",
                                                                            "November",
                                                                            "December"
                                                                        ],
                                                                        "firstDay": 1
                                                                    },
                                                                    "startDate": today,
                                                                    "endDate": today,
                                                                    "minDate": today,
                                                                    "maxDate": end,
                                                                    "opens": "center"
                                                                }, function(start, end, label) {
                                                                  console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
                                                                });
                                                            });
                                                        </script>                                                    
                                                    </div>
                                                    <br>
                                                    <label for="exampleFormControlSelect1">Jam Tayang</label><br>
                                                    <div class="form-group" style="padding-top: 14px;">
                                                        <div class="row">
                                                            <div class="col-3">
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="11:00:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    11:00
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="11:30:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    11:30
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="12:00:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    12:00
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="12:30:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    12:30
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="13:00:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    13:00
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="13:30:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    13:30
                                                                </div>
                                                            </div>
                                                            <div class="col-3">
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="14:00:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    14:00
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="14:30:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    14:30
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="15:00:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    15:00
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="15:30:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    15:30
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="16:00:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    16:00
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="16:30:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    16:30
                                                                </div>
                                                            </div>
                                                            <div class="col-3">
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="17:00:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    17:00
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="17:30:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    17:30
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="18:00:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    18:00
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="18:30:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    18:30
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="19:00:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    19:00
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="19:30:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    19:30
                                                                </div>
                                                            </div>
                                                            <div class="col-3">
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="20:00:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    20:00
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="20:30:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    20:30
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="21:00:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    21:00
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="21:30:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    21:30
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="22:00:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    22:00
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="22:30:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    22:30
                                                                </div>
                                                                <div style="margin-bottom: 10px;">
                                                                    <label class="switch">
                                                                          <input name="jam[]" value="23:00:00" type="checkbox">
                                                                          <span class="slider round"></span>
                                                                    </label>
                                                                    23:00
                                                                </div>
                                                            </div>
                                                        </div>       
                                                    </div>
                                                </div>

                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <label for="exampleFormControlSelect1" style="font-weight: bold"></label>
                                                        <button style="margin-top: 14px" type="submit" class="btn btn-success tombol">Tambah Jadwal</button>
                                                    </div>
                                                </div>
                                            </div>
                                            </div>
                                        </form>
                                    </div>
                                        

                                    <div class="row" style="padding: 0px 15px 0px 15px">
                                        <table class="table table-dark table-striped">
                                            <col width="250px">
                                            <col width="200px">
                                            <col width="1000px">
                                            <col width="500px">
                                            
                                            <thead>
                                                <tr>
                                                    <th>Film</th>
                                                    <th>Tanggal</th>
                                                    <th>Waktu</th>
                                                    <th>Kapasitas</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                    foreach ($memutar as $row){
                                                ?>
                                                    <tr>
                                                        <form action="<?php echo base_url().'jadwal/ubahJadwal/'.$theater['id_theater'];?>" style="padding-bottom: 15px; padding-left: 50px;" method="post">
                                                        <td style="padding-top: 30px">
                                                            <div class="row">
                                                                <div class="col-12">
                                                                    <div class="col-12">
                                                                        <div class="film_list_identifier"
                                                                            <?php
                                                                                $dateNow = date("Y-m-d");
                                                                                $tayang = $row['tanggal'];
                                                                                if ($tayang == $dateNow) {
                                                                                    echo "style='background-color: #28A745;'"; // Sedang tayang
                                                                                } else if ($tayang > $dateNow) {
                                                                                    echo "style='background-color: #FFC107;'"; // Akan tayang
                                                                                } else if ($tayang < $dateNow) {
                                                                                    echo "style='background-color: #DC3545;'"; // Sudah tayang
                                                                                }
                                                                            ?>
                                                                        >
                                                                        </div>
                                                                        <img class="film_detail_poster" src="<?php echo base_url()?>other/asset/film/<?php echo $row['id_film']?>_img.jpg" alt="">
                                                                        <br>
                                                                        <p style="font-size: 20px;color: white; font-weight: bold "><?php echo $row['judul']?></p>
                                                                        <p style="font-size: 15px;color: #207ED9 "><?php echo $row['gendre']?></p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div style="display: none;"><input type="text" name="id_film" value="<?php echo $row['id_film']?>"/></div>
                                                        </td>

                                                        <td style="padding-top: 30px">
                                                            <?php echo $row['tanggal']?>
                                                            <div style="display: none;"><input type="text" name="tanggal" value="<?php echo $row['tanggal']?>"/></div>
                                                        </td>


                                                        <?php if($row['status']=="nonactive"){ ?>
                                                            <td style='padding-top: 30px'>
                                                                <?php 
                                                                    $jamList = explode(",",$row['group_concat(j.jam)']);
                                                                ?>

                                                                <div style="display: none;"><input type="text" name="oldJam" value="<?php echo $row['group_concat(j.jam)']?>"/></div>
                                                                <div style="display: none;"><input type="text" name="status" value="<?php echo $row['status']?>"/></div>

                                                                <div class="form-group" style="padding-top: 14px;">
                                                                    <div class="row">
                                                                        <div class="col-3">
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="11:00:00" type="checkbox" <?php if (in_array("11:00:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                11:00
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="11:30:00" type="checkbox" <?php if (in_array("11:30:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                11:30
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="12:00:00" type="checkbox" <?php if (in_array("12:00:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                12:00
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="12:30:00" type="checkbox" <?php if (in_array("12:30:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                12:30
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="13:00:00" type="checkbox" <?php if (in_array("13:00:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                13:00
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="13:30:00" type="checkbox" <?php if (in_array("13:30:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                13:30
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-3">
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="14:00:00" type="checkbox" <?php if (in_array("14:00:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                14:00
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="14:30:00" type="checkbox" <?php if (in_array("14:30:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                14:30
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="15:00:00" type="checkbox" <?php if (in_array("15:00:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                15:00
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="15:30:00" type="checkbox" <?php if (in_array("15:30:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                15:30
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="16:00:00" type="checkbox" <?php if (in_array("16:00:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                16:00
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="16:30:00" type="checkbox" <?php if (in_array("16:30:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                16:30
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-3">
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="17:00:00" type="checkbox" <?php if (in_array("17:00:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                17:00
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="17:30:00" type="checkbox" <?php if (in_array("17:30:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                17:30
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="18:00:00" type="checkbox" <?php if (in_array("18:00:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                18:00
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="18:30:00" type="checkbox" <?php if (in_array("18:30:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                18:30
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="19:00:00" type="checkbox" <?php if (in_array("19:00:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                19:00
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="19:30:00" type="checkbox" <?php if (in_array("19:30:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                19:30
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-3">
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="20:00:00" type="checkbox" <?php if (in_array("20:00:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                20:00
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="20:30:00" type="checkbox" <?php if (in_array("20:30:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                20:30
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="21:00:00" type="checkbox" <?php if (in_array("21:00:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                21:00
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="21:30:00" type="checkbox" <?php if (in_array("21:30:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                21:30
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="22:00:00" type="checkbox" <?php if (in_array("22:00:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                22:00
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="22:30:00" type="checkbox" <?php if (in_array("22:30:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                22:30
                                                                            </div>
                                                                            <div style="margin-bottom: 10px;">
                                                                                <label class="switch">
                                                                                      <input name="jam[]" value="23:00:00" type="checkbox" <?php if (in_array("23:00:00", $jamList)) { echo "checked";} ?> id="<?php echo $row['tanggal']?>" onclick="openButton(this.id)">
                                                                                      <span class="slider round"></span>
                                                                                </label>
                                                                                23:00
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-4">
                                                                            <div class="form-group">
                                                                                <label for="exampleFormControlSelect1" style="font-weight: bold"></label>
                                                                                <button id="<?php echo $row['tanggal'].'_b'?>" style="margin-top: 14px" type="submit" class="btn btn-secondary tombol" disabled="">Simpan Perubahan</button>
                                                                            </div>
                                                                        </div>
                                                                    </div>       
                                                                </div>

                                                                <script type="text/javascript">
                                                                    function openButton(id) {
                                                                        var opButton = document.getElementById(id+'_b');
                                                                        opButton.classList.add("btn-success");
                                                                        opButton.disabled = false;
                                                                    } 
                                                                </script>
                                                            </td>
                                                        <?php } elseif($row['status']=="active"){ ?>
                                                            <td style='padding-top: 30px'>
                                                                <div class='row'>
                                                                <?php 
                                                                    $jamList = explode(",",$row['group_concat(j.jam)']);
                                                                    foreach ($jamList as $jam) {
                                                                        echo "
                                                                            <div style='background-color: #0052A2; width: 100px; text-align: center; padding-top: 10px; padding-bottom: 10px; border-radius: 15px; margin-right: 20px; margin-bottom: 20px;'>
                                                                                <span style='font-weight: bold'>".substr($jam, 0, 5)."</span>
                                                                            </div>   
                                                                        ";
                                                                    }
                                                                ?>
                                                                </div>         
                                                            </td>
                                                        <?php } ?>
                                                        </form>

                                                        <?php if ($row['status']=="nonactive") {?>
                                                            <td style="padding-top: 30px">
                                                                <div class='row'>
                                                                    <div style='background-color: #565D63; width: 150px; text-align: center; padding-top: 10px; padding-bottom: 10px; border-radius: 15px; margin-right: 20px; margin-bottom: 20px;'>
                                                                        <span style='font-weight: bold'>NONACTIVE</span>
                                                                    </div>   
                                                                </div>
                                                                
                                                                <form action="<?php echo base_url().'jadwal/aktifJadwal/'.$theater['id_theater'];?>" method="post">
                                                                    Advance Ticket<br><br>
                                                                    Jadwal yang sudah diaktifkan berarti jadwal sudah diperiksa, siap tayang, dan telah sesuai dengan peraturan yang ada. Sehingga sifatnya tetap dan tidak dapat diubah<br><br>
                                                                    <div style="display: none;"><input type="text" name="tanggal" value="<?php echo $row['tanggal']?>"/></div>
                                                                    <input type="checkbox" name="terms" value="yes" required style="margin-right: 12px;">Ya, Aktifkan Jadwal Untuk Advance Ticket
                                                                    
                                                                    <div class="form_contain" style="margin-top: 20px; margin-bottom: 20px;">
                                                                        <button type="submit" class="btn btn-success tombol">Aktifkan Jadwal</button>
                                                                    </div>
                                                                </form>

                                                                <form action="<?php echo base_url().'jadwal/hapusJadwal/'.$theater['id_theater'];?>" method="post">
                                                                    <div style="display: none;"><input type="text" name="tanggal" value="<?php echo $row['tanggal']?>"/></div>
                                                                    
                                                                    <div class="form_contain" style="margin-top: 20px;">
                                                                        <button type="submit" class="btn btn-danger tombol">Kosongkan Jadwal</button>
                                                                    </div>
                                                                </form>
                                                            </td>
                                                        <?php } elseif($row['status']=="active"){ ?>
                                                            <td style="padding-top: 30px">
                                                                <div class='row'>
                                                                    <div style='background-color: #0052A2; width: 150px; text-align: center; padding-top: 10px; padding-bottom: 10px; border-radius: 15px; margin-right: 20px'>
                                                                        <span style='font-weight: bold'>ACTIVE</span>
                                                                    </div>   
                                                                </div>
                                                            </td>
                                                        <?php } ?> 
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                            </div>

                            <div id="hapusTheater" class="col-12" style=";margin-top: 25px; padding: 45px 45px 0px 45px">
                                <div style="display: flex;">
                                    <div class="accessories" style="background-color: #DC3545;"><p></p></div>
                                    <h1 class="heading1">Hapus Bioskop - <span style="color: grey"><?php echo $data['nama_bioskop']?></span></h1>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        Menghapus Bioskop akan juga menghapus <span style="font-weight: bold">seluruh data Theater dan Kursi</span> yang berkaitan dengan bioskop ini dari Database.<br>
                                        Apakah anda yakin ingin <span style="font-weight: bold">menghapus Bioskop</span> ini?<br><br>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-2">
                                        <form action="<?php echo base_url().'bioskop/hapus/'.$data['id_bioskop'];?>">
                                            <div class="form_contain">
                                                <input type="checkbox" name="terms" value="yes" required style="margin-right: 12px;">Ya, hapus Bioskop ini
                                            </div>
                                            <div class="form_contain">
                                                <button type="submit" class="btn btn-danger tombol">Hapus Bioskop</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <script>
                                var x = document.getElementById("formTamJadwal");
                                x.style.display = "none";    
                                var y = document.getElementById("hapusTheater");                                
                                y.style.display = "none";

                                function formTamJadwalSh() {
                                    if (x.style.display === "none") {
                                        x.style.display = "block";
                                        y.style.display = "none";
                                    } else {
                                        x.style.display = "none";
                                    }
                                }

                                function hapus_bioskop() {
                                    if (y.style.display === "none") {
                                        y.style.display = "block";
                                        x.style.display = "none";
                                    }
                                } 
                            </script>
                        </div> 
                    </div>
                </div>                   
            </div>
        </div>
    </div>
</div>