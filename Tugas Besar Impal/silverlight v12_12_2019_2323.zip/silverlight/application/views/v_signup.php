<div style="background-image: url('<?php echo base_url()?>other/asset/latar/page2.png'); background-size: cover; background-repeat: repeat-y; background-position: 50% 10px; background-size: 1850px;">

<div class="container-fluid contain" style="margin-top: 90px;">
	<div class="row">
		<div class="col-12">
			<div style="display: flex;">
				<div class="accessories"><p></p></div>
				<h1 class="heading1">Sign Up</h1>	
			</div>	
		</div>
	</div>
	<div class="row">
		<div class="col-md-4" style="padding-right: 27px;">
			<?php  
				if (empty($this->session->flashdata('update'))==false) {
                    echo "
                        <div class='col-12 alert alert-success' role='alert' style='margin-bottom: 40px;'>
                                    ".$this->session->flashdata('update')."
                        </div>
                    ";
                }
                if (empty($this->session->flashdata('error'))==false) {
                    echo "
                        <div class='col-12 alert alert-danger' role='alert' style='margin-bottom: 40px;'>
                            ".$this->session->flashdata('error')."
                        </div>
                    ";
                }
            ?>
			<div class="sign_box">
				<form action="<?php echo base_url(). 'users/register';?>" style="padding-bottom: 15px;" method="post">
					<div class="form_contain">
						Email
						<input type="email" name="email" required class="form-control form-rounded">
						<ul style='color: #b94a48; padding-top: 5px;'>
							<?php echo $this->session->flashdata('message2');?>
						</ul>	
					</div>
					<div class="form_contain">
						Nomor Hp
						<input type="tel" name="nomorHp" pattern="[0-9]{12}" required class="form-control form-rounded">	
					</div>
					<div class="form_contain">
						Nama Lengkap
						<input type="text" name="nama" required class="form-control form-rounded">	
					</div>
					<div class="form_contain">
						Sandi
						<input type="password" minlength="8" name="sandi" required class="form-control form-rounded">
					</div> 
					<div class="form_contain">
						Konfirmasi Sandi
						<input type="password" minlength="8" name="confsandi" required class="form-control form-rounded">	
					</div> 
					<div class="form_contain">
						<input type="checkbox" name="terms" value="yes" required style="margin-right: 12px;">I accept the terms of use & privacy policy
					</div>
					<div class="form_contain">
						<button type="submit" class="btn btn-primary tombol">Sign Up</button>
					</div>
				</form>

				<div style="text-align: center;">
					Sudah punya akun ? <a style="color: #0069d9" href="<?php echo base_url() ?>users/signin/">Sign In Here</a>
				</div>
			</div>
		</div>
		<div class="col-md-8" style="padding-left: 27px;">
			<div style="background-color: gray; height: 650px; border-radius: 2rem">
				
			</div>
		</div>
	</div>


</div>