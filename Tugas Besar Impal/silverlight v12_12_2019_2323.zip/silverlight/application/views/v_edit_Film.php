        <div class="col-10 dashboard-right" style="margin-left: 300px;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-10">
                        <div style="display: flex;">
                            <div class="accessories" style="height: 100px;"><p></p></div>
                            <h1 class="heading1" style="font-size: 80px"><a style="color: white" href="<?php echo base_url()?>admin/admin_Film">Film</a> > <span style="color: #007bff"><?php echo $data['judul'] ?></span></h1> 
                        </div> 
                    </div>
                    
                </div>

            <form action="<?php echo base_url(). 'film/edit/'.$data['id_film'];?>" style="padding-bottom: 15px;" method="post" enctype='multipart/form-data'>
                <div class="row">
                    <?php  
                        if (empty($this->session->flashdata('error'))==false) {
                            echo "
                                <div class='col-12 alert alert-danger' role='alert' style='margin-bottom: 40px;'>
                                    ".$this->session->flashdata('error')."
                                </div>
                            ";
                        }
                    ?>
                </div>
                <div class="row" style="margin-bottom: 40px;">
                    <div class="col-2">
                        <img id="poster_preview" class="film_detail_poster" src="<?php echo base_url()?>other/asset/film/<?php echo $data['id_film']?>_img.jpg" alt="">
                        <div class="form_contain">
                            Poster (.jpg)<br>
                            <div style="margin-top: 14px; width: 100%" class="tomobol_Upload_Wrapper">
                                <button type="button" class="btn btn-primary tombol">Upload a file</button>
                                <input style="height: 100%" type="file" name="poster" id="poster" height="100%" onchange="return fileValidation(this.id)">
                            </div>
                        </div> 
                    </div>

                    <div class="col-4" style="padding-left: 60px">
                        <div class="row">
                            <p class="tulisan">Judul:</p>
                        </div>
                        <div class="row">
                            <input type="text" style="width: 500px; margin: 0px 0px 25px 0px;" name="judul" required class="form-control form-rounded" value="<?php echo $data['judul'] ?>">
                        </div>
                        <div class="row">
                            <p class="tulisan">Durasi (in Minutes):</p>
                        </div>
                        <div class="row">
                            <input type="number" style="width: 500px; margin: 0px 0px 25px 0px;" name="durasi" required class="form-control form-rounded" value="<?php echo substr($data['durasi'],0,3) ?>">
                        </div>
                        <div class="row">
                            <p class="tulisan">Genre:</p>
                        </div>
                        <div class="row">
                            <input type="text" style="width: 500px; margin: 0px 0px 25px 0px;" name="gendre" required class="form-control form-rounded" value="<?php echo $data['gendre'] ?>">
                        </div>
                        <div class="row">
                            <p class="tulisan">Sutradara:</p>
                        </div>
                        <div class="row">
                            <input type="text" style="width: 500px; margin: 0px 0px 25px 0px;" name="sutradara" required class="form-control form-rounded" value="<?php echo $data['sutradara'] ?>">
                        </div>
                        <div class="row">
                            <p class="tulisan">Link Trailer:</p>
                        </div>
                        <div class="row">
                            <input type="text" style="width: 500px; margin: 0px 0px 25px 0px;" name="link_trailer" required class="form-control form-rounded" value="<?php echo $data['link_trailer'] ?>">
                        </div>
                    </div>

                    <div class="col-4" style="padding-left: 45px;">
                        <div class="row">
                            <p class="tulisan">Tanggal Rilis:</p>
                        </div>
                        <div class="row">
                            <input required id="rilis" style="width: 500px; margin: 0px 0px 25px 0px;" class="form-control form-rounded" type="text" name="rilisRange" value="<?php echo $data['rilis_start'].' - '.$data['rilis_end']?>">
                            <script>
                                // Date Picket
                                $('#rilis').daterangepicker({
                                    "locale": {
                                        "format": "YYYY-MM-DD",
                                        "separator": " - ",
                                        "applyLabel": "Apply",
                                        "cancelLabel": "Cancel",
                                        "fromLabel": "From",
                                        "toLabel": "To",
                                        "customRangeLabel": "Custom",
                                        "weekLabel": "W",
                                        "daysOfWeek": [
                                            "Min",
                                            "Sen",
                                            "Sel",
                                            "Rab",
                                            "Kam",
                                            "Jum",
                                            "Sab"
                                        ],
                                        "monthNames": [
                                            "January",
                                            "February",
                                            "March",
                                            "April",
                                            "May",
                                            "June",
                                            "July",
                                            "August",
                                            "September",
                                            "October",
                                            "November",
                                            "December"
                                        ],
                                        "firstDay": 1
                                    },
                                    "opens": "center"
                                }, function(start, end, label) {
                                    console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
                                });
                            </script>
                        </div>
                        <div class="row">
                            <p class="tulisan">Rating Film:</p>
                        </div>
                        <div class="row">
                            <select name="rating" class="form-control form-rounded" style="width: 500px; margin: 0px 0px 25px 0px; height: 44px" required>
                                <option value="">-- Rating --</option>
                                <option <?php if ($data['rating']=='rating_su') { echo 'selected '; }?> value="rating_su">SU</option>
                                <option <?php if ($data['rating']=='rating_13') { echo 'selected '; }?> value="rating_13">13+</option>
                                <option <?php if ($data['rating']=='rating_17') { echo 'selected '; }?> value="rating_17">17+</option>
                                <option <?php if ($data['rating']=='rating_21') { echo 'selected '; }?> value="rating_21">21+</option>
                            </select>
                        </div>
                        <div class="row">
                            <p class="tulisan">Sinopsis:</p>
                        </div>
                        <div class="row">
                            <textarea class="form-control form-rounded-textarea" name="sinopsis" rows="9" required ><?php echo $data['sinopsis']?></textarea>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="row">
                            <p class="tulisan">Gambar Film (.jpg)</p>
                        </div>
                        <div class="row">
                            <div class="col-3">
                                <div style="margin-top: 14px; margin-bottom: 14px; width: 300px" class="tomobol_Upload_Wrapper">
                                    <button type="button" class="btn btn-primary tombol">Pilih Gambar</button>
                                    <input style="height: 100%" type="file" name="gambarFilm1" id="gambarFilm1" height="100%" onchange="return fileValidation(this.id)">
                                </div>
                                <div>
                                    <img id="gambarFilm1_preview" class="film_detail_img" src="<?php echo base_url()?>other/asset/film/<?php echo $data['id_film']?>_img1.jpg" alt="">
                                </div>
                            </div>
                            <div class="col-3">
                                <div style="margin-top: 14px; margin-bottom: 14px; width: 300px" class="tomobol_Upload_Wrapper">
                                    <button type="button" class="btn btn-primary tombol">Pilih Gambar</button>
                                    <input style="height: 100%" type="file" name="gambarFilm2" id="gambarFilm2" height="100%" onchange="return fileValidation(this.id)">
                                </div>
                                <div>
                                    <img id="gambarFilm2_preview" class="film_detail_img" src="<?php echo base_url()?>other/asset/film/<?php echo $data['id_film']?>_img2.jpg" alt="">
                                </div>
                            </div>
                            <div class="col-3">
                                <div style="margin-top: 14px; margin-bottom: 14px; width: 300px" class="tomobol_Upload_Wrapper">
                                    <button type="button" class="btn btn-primary tombol">Pilih Gambar</button>
                                    <input style="height: 100%" type="file" name="gambarFilm3" id="gambarFilm3" height="100%" onchange="return fileValidation(this.id)">
                                </div>
                                <div>
                                    <img id="gambarFilm3_preview" class="film_detail_img" src="<?php echo base_url()?>other/asset/film/<?php echo $data['id_film']?>_img3.jpg" alt="">
                                </div>
                            </div>    
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-12 film_list">
                        <div class="row">
                            <div class="col-2">
                                <button type="submit" class="btn btn-success" style="width: 100%; height: 100%; border-radius: 1rem; padding: 20px" onclick="tambah_theater()"> 
                                    <div>
                                        <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/save.svg">    
                                    </div> 
                                    <b>Simpan Perubahan</b>
                                </button>
                            </div>
                            <div class="col-2">
                                <a href="<?php echo base_url().'admin/detail_film/'.$data['id_film']?>">
                                    <button type="button" class="btn btn-danger" style="width: 100%; height: 100%; border-radius: 1rem; padding: 20px" onclick="tambah_theater()"> 
                                        <div>
                                            <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/xicon.svg">    
                                        </div> 
                                        <b>Batalkan Perubahan</b>
                                    </button>
                                </a>
                            </div>
                        </div> 
                    </div>
                </div>
            </form>
            </div>
        </div>
    </div>  
</div>

<script>
    function fileValidation(id){
    var fileInput = document.getElementById(id);
    var filePath = fileInput.value;
    var allowedExtensions = /(\.jpg)$/i;
        if(!allowedExtensions.exec(filePath)){
            alert('Tong upload gambar dalam bentuk .jpg saja.');
            fileInput.value = '';
            return false;
        }else{
            //Image preview
            if (fileInput.files && fileInput.files[0]) {
            var reader = new FileReader();
                reader.onload = function(e) {
                    if (id=='poster') {
                        var p = 'poster'
                    } else {
                        var p = 'img'
                    }
                    document.getElementById(id+'_preview').src = e.target.result;
                };
                reader.readAsDataURL(fileInput.files[0]);
            }
        }
    }
</script>