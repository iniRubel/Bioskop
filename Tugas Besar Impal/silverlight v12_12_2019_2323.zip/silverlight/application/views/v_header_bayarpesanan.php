<div style="color: white;position: fixed; z-index: 9999; top: 0;" class="container-fluid navigation">
    <div class="row">
        <div cstyle="padding-left: 30px;">
            <p  style="color: #207ED9;font-size: 25px;"><b><c id="judulfilm"></c></b></p>
            <div style="display: flex;">
                <p  style="margin-right: 20px;font-size: 20px;"><b><c id="namabioskop"></c></b></p>
                <p  style="margin-right: 20px;font-size: 20px;"><b><c id="haritanggal"></c></b></p>
                <p  style="font-size: 20px;"><b><c id="jam" ></c></b></p>
            </div>
            <p style="font-size: 12px;"><c id="alamat"></c></p>
        </div>

        <div class="col" style="padding: 0px; margin: 0px;">
            
        </div>

        <div style="padding-right: 30px;">
            <div style="display: flex;">
                <div style="width: 100%; padding: 10px 15px 10px 10px;">registered as</div>
                <div class="tombol" style="background-color: #0052A2; text-align: center; line-height: 53px; width: 100%; padding-left: 25px; padding-right: 25px;margin-right: 50px;">
                    <?php echo $this->session->userdata('email')?>
                </div>
                <form method="POST" action="<?php echo base_url(). 'tiket/pilih_makmin';?>">
                    <div style="display: none;">
                        <input id="formjudulfilm" type="text" name="judulfilm">
                        <input id="formnamabioskop" type="text" name="namabioskop">
                        <input id="formharitanggal" type="text" name="haritanggal">
                        <input id="formjam" type="text" name="jam">
                        <input id="formalamat" type="text" name="alamat">
                        <input id="formseats" type="text" name="seats">
                        <input id="formjumkursi" type="text" name="jumkursi">
                    </div>
                </form>
            </div>

            <script type="text/javascript">
                $(document).ready(function(){
                    // console.log(judulfilm+"hahahahah");
                    // $("#hargatotal").text(hargatotal);
                    // $("#hargaseats").text(hargaseats);
                    // $("#hargaservice").text(hargaservice);
                    $("#judulfilm").text(judulfilm);
                    $("#namabioskop").text(namabioskop);
                    $("#haritanggal").text(haritanggal);
                    $("#jam").text(jam);
                    $("#alamat").text(alamat);
                    // console.log(jumlahservice);
                    // $("#jumlahservice").text(jumlahservice);
                    // for (i = 0; i < (seats.length)-1; i++) {
                    //     $("#kursi").append(seats[i]+", ");
                    // }
                    // $("#kursi").append(seats[i]);

                })
            </script>
        </div>
        <div>
            <form id="formbatal" action="<?php echo base_url(). 'home/'?>"></form>
            <button onclick="batal()" style="display: block;color: white;cursor: pointer; font-size: 50px;background-color: #000B18;border: none;" >
                <img style="width: 30px; padding-bottom: 50px;" src="<?php echo base_url().'other/asset/icon/close.svg'?>">
            </button>
        </div>
    </div>
</div>
