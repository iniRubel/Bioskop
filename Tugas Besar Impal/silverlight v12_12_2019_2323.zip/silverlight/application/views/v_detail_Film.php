        <div class="col-10 dashboard-right" style="margin-left: 300px;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-10">
                        <div style="display: flex;">
                            <div class="accessories" style="height: 100px;"><p></p></div>
                            <h1 class="heading1" style="font-size: 80px"><a style="color: white" href="<?php echo base_url()?>admin/admin_Film">Film</a> > <span style="color: #007bff"><?php echo $data['judul'] ?></span></h1> 
                        </div> 
                    </div>
                    
                </div>

                <div class="row" style="margin-bottom: 40px;">
                    <?php  
                        if (empty($this->session->flashdata('update'))==false) {
                            echo "
                                <div class='col-12 alert alert-success' role='alert' style='margin-bottom: 40px;'>
                                    ".$this->session->flashdata('update')."
                                </div>
                            ";
                        }
                        if (empty($this->session->flashdata('error'))==false) {
                            echo "
                                <div class='col-12 alert alert-danger' role='alert' style='margin-bottom: 40px;'>
                                    ".$this->session->flashdata('error')."
                                </div>
                            ";
                        }
                    ?>
                    <div class="col-2">
                        <div class="col-12">
                            <div class="film_list_identifier"
                                <?php
                                    $dateNow = date("Y-m-d");
                                    $rilisStart = $data['rilis_start'];
                                    $rilisEnd = $data['rilis_end'];
                                    if ($rilisStart <= $dateNow and $dateNow <= $rilisEnd) {
                                        echo "style='background-color: #28A745;'"; // Sedang tayang
                                    } else if ($rilisStart > $dateNow and $dateNow < $rilisEnd) {
                                            echo "style='background-color: #FFC107;'"; // Akan tayang
                                    } else if ($rilisStart < $dateNow and $dateNow > $rilisEnd) {
                                            echo "style='background-color: #DC3545;'"; // Sudah tayang
                                    }
                                ?>
                            >
                            </div>
                            <img class="film_detail_poster" src="<?php echo base_url()?>other/asset/film/<?php echo $data['id_film']?>_img.jpg" alt="">
                        </div>
                        <div class="col-5">
                            <img class="film_detail_poster" src="<?php echo base_url()?>other/asset/icon/<?php echo $data['rating']?>.svg" alt="">  
                        </div>
                    </div>
                    <div class="col-9" style="padding-left: 40px">
                        <div class="row" style="margin-bottom: 25px">
                            
                            <span class="tulisan" style="font-weight: bold; font-size: 30px"><?php echo $data['judul']?></span>
                        </div>
                        <div class="row">
                            <p style="font-size: 15px;color: #207ED9"><?php echo $data['gendre'] ?></p>
                        </div>
                        <div class="row">
                            <p class="tulisan"><?php echo $data['sinopsis']?></p>
                        </div>
                        <div class="row">
                            <p class="tulisan"><span style="font-weight: bold;">Durasi: </span><?php echo $data['durasi']?></p>
                        </div>
                        <div class="row">
                            <p class="tulisan"><span style="font-weight: bold;">Sutradara: </span><?php echo $data['sutradara']?></p>
                        </div>
                        <div class="row">
                            <p class="tulisan"><span style="font-weight: bold;">Rilis: </span><?php echo $data['rilis_start']." - ".$data['rilis_end'];?></p>
                        </div>
                        <div class="row" style="margin-top: 25px;">
                            <div class="col-3">
                                <iframe style="height: 176px;" class="film_detail_vid" src="<?php echo $data['link_trailer'] ?>" frameborder="0" allowfullscreen></iframe>
                            </div>
                            <div class="col-3">
                                <img class="film_detail_img" src="<?php echo base_url()?>other/asset/film/<?php echo $data['id_film']?>_img1.jpg" alt="">
                            </div>
                            <div class="col-3">
                                <img class="film_detail_img" src="<?php echo base_url()?>other/asset/film/<?php echo $data['id_film']?>_img2.jpg" alt="">
                            </div>
                            <div class="col-3">
                                <img class="film_detail_img" src="<?php echo base_url()?>other/asset/film/<?php echo $data['id_film']?>_img3.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 film_list">
                        <div class="row">
                            <div class="col-2">
                                <a href="<?php echo base_url() ?>admin/edit_film/<?php echo $data['id_film']?>">
                                <button type="button" class="btn btn-primary" style="width: 100%; height: 100%; border-radius: 1rem; padding: 20px"> 
                                    <div>
                                        <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/edit.svg">    
                                    </div> 
                                    <b>Edit Film</b>
                                </button>
                                </a>   
                            </div>
                            <div class="col-2">
                                <button id="tambah_theater_button" type="button" class="btn btn-danger" style="width: 100%; height: 100%; border-radius: 1rem; padding: 20px" onclick="hapus_bioskop()"> 
                                    <div>
                                        <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/delete.svg">    
                                    </div> 
                                    <b>Hapus Film</b>
                                </button>
                            </div>


                        
                            <div id="hapusBioskop" class="col-12" style=";margin-top: 25px; padding: 45px 45px 0px 45px">
                                <div style="display: flex;">
                                    <div class="accessories" style="background-color: #DC3545;"><p></p></div>
                                    <h1 class="heading1">Hapus Film - <span style="color: grey"><?php echo $data['judul']?></span></h1>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        Menghapus Film akan juga <span style="font-weight: bold">menghapus seluruh data</span> yang berkaitan dengan film ini dari Database.<br>
                                        Apakah anda yakin ingin <span style="font-weight: bold">menghapus Film</span> ini?<br><br>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-2">
                                        <form action="<?php echo base_url().'film/hapus/'.$data['id_film'];?>" method="post">
                                            <div class="form_contain">
                                                <input type="checkbox" name="terms" value="yes" required style="margin-right: 12px;">Ya, hapus Film ini
                                            </div>
                                            <div class="form_contain">
                                                <button type="submit" class="btn btn-danger tombol">Hapus Film</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <script>
                                var y = document.getElementById("hapusBioskop");
                                y.style.display = "none";

                                function hapus_bioskop() {
                                    if (y.style.display === "none") {
                                        y.style.display = "block";
                                    } else {
                                        y.style.display = "none";
                                    }
                                } 
                            </script>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>