<div style="color: white; position: fixed; z-index: 9999; top: 0;" class="container-fluid navigation">
	<div class="row">
		<div>
			<a href="<?php echo base_url()?>film/book/<?php echo $tiket['id_film'];?>">
				<button onclick="formFunction2()" style="display: block;color: white;cursor: pointer; font-size: 80px;background-color: #000B18;border: none;" type="button">
					<img style="width: 30px; padding-bottom: 100px;" src="<?php echo base_url().'other/asset/icon/back.svg'?>">
				</button>
			</a>
		</div>

		<div style="padding-left: 30px;">
			<p  style="color: #207ED9;font-size: 25px;"><b><c id="judulfilm"></c></b></p>
				<div style="display: flex;">
					<p  style="margin-right: 20px;font-size: 20px;"><b><c id="namabioskop"></c></b></p>
					<p  style="margin-right: 20px;font-size: 20px;"><b><c id="haritanggal"></c></b></p>
					<p  style="font-size: 20px;"><b><c id="jam" ></c></b></p>
				</div>
			<p style="font-size: 12px;"><c id="alamat"></c></p>
		</div>

		<div class="col" style="padding: 0px; margin: 0px;"></div>

		<div style="padding-right: 30px;">
			<div style="display: flex; margin-bottom: 20px;">
				<div style="width: 100%; padding: 10px 15px 10px 10px;">registered as</div>
				<div class="tombol" style="background-color: #0052A2; text-align: center; line-height: 53px; width: 100%; padding-left: 25px; padding-right: 25px">
					<?php echo $this->session->userdata('email')?>
				</div>
				<form method="POST" action="<?php echo base_url(). 'tiket/pilih_makmin/'.$tiket['id_jadwal'];?>">
					<div style="display: none;">
						<input id="formseats" type="text" name="seats">
						<input id="formjumkursi" type="text" name="jumkursi">
					</div>
					<button onclick="bookFunction()" style="display: block;width: 280px; margin-left: 50px;" type="submit" class="btn btn-primary tombol">Book Now</button>	
				</form>
            </div>
            <?php  
                if (empty($this->session->flashdata('warning'))==false) {
                    echo "
                        <div class='col-12 alert alert-warning' role='alert' style='margin-bottom: 40px;'>
                            ".$this->session->flashdata('warning')."
                        </div>
                    ";
                }
                if (empty($this->session->flashdata('error'))==false) {
                    echo "
                        <div class='col-12 alert alert-error' role='alert' style='margin-bottom: 40px;'>
                            ".$this->session->flashdata('error')."
                        </div>
                    ";
                }
            ?>
		</div>
		<div>
			<form id="formbatal" action="<?php echo base_url(). 'home/'?>"></form>
			<button onclick="batal()" style="display: block;color: white;cursor: pointer; font-size: 50px;background-color: #000B18;border: none;" >
	            <img style="width: 30px; padding-bottom: 50px;" src="<?php echo base_url().'other/asset/icon/close.svg'?>">
	        </button>
		</div>
	</div>
</div>
