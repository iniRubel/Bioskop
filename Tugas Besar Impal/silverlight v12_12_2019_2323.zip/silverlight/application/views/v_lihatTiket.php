<div style="margin-top: 80px;" class="container-fluid contain">
	<div class="row">
		<div class="col-12">
			<div style="display: flex;">
				<div class="accessories"><p></p></div>
				<h1 class="heading1">Tiket Saya</h1>	
			</div>
            <?php 
                $i = 0;
                foreach ($tiket as $row){
                
            ?>
            <div style="display: flex;margin-bottom: 20px;" class="tiket">
                <a href="<?php echo base_url()?>tiket/detail_tiket/<?php echo $row['id_tikets']?>"><img style="height:250px;width: 200px;border-radius: 25px; " src="<?php echo base_url()?>other/asset/film/<?php echo $row['id_film']?>_img.jpg"></a>
                <div style="background-color: #000B18;margin-left: 20px;color: white;border-radius: 30px;padding: 10px;" class="isitiket">
                    <p style="font-size: 25px;"><b><?php echo $row['judul']?></b></p>
                    <div style="display: flex;" class="info">
                        
                            <div style="width: 400px;margin-top:50px;" class="tempat">
                                <p><b><?php echo $row['nama_bioskop']?></b></p>
                                <script type="text/javascript">
                                    console.log("<?php echo $row['nama_bioskop']?>"+"hahahahah");
                                </script>
                                <p><?php echo $row['alamat']?></p>
                            </div>
                            <div style="width: 300px;margin-top:50px;" class="waktu">
                                <p><b><?php echo $row['tanggal']?></b></p>
                                <p><?php echo $row['jam']?></p>
                            </div>
                            <div style="margin-top:50px;width: 250px;" class="jumtiket">
                                <script type="text/javascript">
                                    $(document).ready(function(){
                                        data = "<?php echo $row['kursi']?>"
                                        var jumtiket = data.split(",");
                                        $("#jumtiket<?php echo $i ?>").html("<p><b>"+jumtiket.length+" Tickets </b></p>");
                                        console.log(jumtiket.length+"hahhahh");
                                    });
                                </script>
                                <p id="jumtiket<?php echo $i ?>"><b></b></p>
                                <?php
                                    if ($row['makmin'] == null) { 

                                    }else{
                                        ?>
                                       <p>with snack and drinks</p>
                                       <?php
                                    }
                                
                                ?>
                            </div>
                            <img style="height: 150px;width: 150px;" src="<?php echo base_url()?>other/asset/icon/barcode.png">
                    </div>
                </div>
                
            </div>
            <?php
                $i++;
                }
            ?> 
        </div>
    </div>
</div>
