<div class="container-fluid navigation" style="position: fixed; z-index: 9999; top: 0; ">
	<div class="row justify-content-between">

		<div class="col-auto" style="margin-top: auto; margin-bottom: auto">
			<div class="row">
				<div class="col-auto" style="padding-right: 0px; margin-right: 50px;">
					<a href="<?php echo base_url() ?>home">
						<img style="height: 53px" src="<?php echo base_url()?>other/asset/icon/logo.svg" alt="">	
					</a>
				</div>
				<div class="col-auto" style="margin-top: auto; margin-bottom: auto; padding-left: 0px">
					
				</div>	
			</div>
		</div>

		<div class="col-auto">
			<div class="row">
				<div class="col-auto" style="margin-top: auto; margin-bottom: auto; padding-right: 0px; 
				<?php
					if($this->session->userdata('status') != "login" and $this->session->userdata('type') != "admin"){
						echo "display: none;";
					} else {
						echo "display: block;";
					}
				?>">
					<a href="<?php echo base_url().'admin/signout' ?>" class="linknav">Sign Out</a>	
				</div>
				<div class="col-auto" style="padding-left: 0px">
					<div class="tombol" style="background-color: #0052A2; text-align: center; line-height: 53px; width: 180px">
						Admin Mode
					</div>
				</div>	
			</div>
		</div>
		
	</div>
</div>