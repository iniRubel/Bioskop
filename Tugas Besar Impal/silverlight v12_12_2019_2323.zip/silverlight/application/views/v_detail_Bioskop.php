        <div class="col-10 dashboard-right" style="margin-left: 300px;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-10">
                        <div style="display: flex;">
                            <div class="accessories" style="height: 100px;"><p></p></div>
                            <h1 class="heading1" style="font-size: 80px"><a style="color: white" href="<?php echo base_url()?>admin/admin_Bioskop">Bioskop</a> > <span style="color: #007bff"><?php echo $data['nama_bioskop'] ?></span></h1> 
                        </div> 
                    </div>
                </div>

                <div class="row">
                    <?php  
                        if (empty($this->session->flashdata('update'))==false) {
                            echo "
                                <div class='col-12 alert alert-success' role='alert' style='margin-bottom: 40px;'>
                                    ".$this->session->flashdata('update')."
                                </div>
                            ";
                        }
                        if (empty($this->session->flashdata('error'))==false) {
                            echo "
                                <div class='col-12 alert alert-danger' role='alert' style='margin-bottom: 40px;'>
                                    ".$this->session->flashdata('error')."
                                </div>
                            ";
                        }
                    ?>
                </div>

                <div class="row" style="margin-bottom: 40px;">
                    <div class="col-3">
                        <img class="bioskop_list_img" src="<?php echo base_url()?>other/asset/bioskop/<?php echo $data['id_bioskop']?>.jpg" alt="">
                    </div>
                    <div class="col-9" style="padding-left: 60px">
                        <div class="row" style="margin-bottom: 25px">
                            <span class="tulisan" style="font-weight: bold; font-size: 30px"><?php echo $data['nama_bioskop']?></span>
                        </div>
                        <div class="row" style="margin-bottom: 25px">
                            <div>
                                <span class="tulisan" style="font-weight: bold;">Alamat:</span><br>
                                <span class="tulisan"><?php echo $data['alamat']?> | </span><span><?php echo $data['kota']?></span>
                            </div>
                        </div>
                        <div class="row" style="margin-bottom: 25px">
                            <div>
                                <span class="tulisan" style="font-weight: bold;">Nomor Telpon: </span><br>
                                <span class="tulisan"><?php echo $data['no_telp']?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 film_list">
                        <div class="row">
                            <div class="col-2">
                                <button id="table_theater_button" type="button" class="btn btn-primary" style="width: 100%; height: 100%; border-radius: 1rem; padding: 20px" onclick="theater_tab()"> 
                                    <div>
                                        <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/bioskop.svg">    
                                    </div> 
                                    <b>Tab Theater</b>
                                </button>
                            </div>

                            <div class="col-2 offset-6">
                                <a href="<?php echo base_url() ?>admin/edit_bioskop/<?php echo $data['id_bioskop']?>">
                                <button type="button" class="btn btn-primary" style="width: 100%; height: 100%; border-radius: 1rem; padding: 20px"> 
                                    <div>
                                        <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/edit.svg">    
                                    </div> 
                                    <b>Edit Bioskop</b>
                                </button>
                                </a>   
                            </div>
                            <div class="col-2 offset-1s">
                                <button id="hapus_theater_button" type="button" class="btn btn-danger" style="width: 100%; height: 100%; border-radius: 1rem; padding: 20px" onclick="hapus_bioskop()"> 
                                    <div>
                                        <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/delete.svg">    
                                    </div> 
                                    <b>Hapus Bioskop</b>
                                </button>
                            </div>


                            <div id="Theater" class="col-12" style=";margin-top: 25px; padding: 45px">
                                <?php  
                                    if (empty($this->session->flashdata('updateTheater'))==false) {
                                        echo "
                                            <div class='col-12 alert alert-success' role='alert' style='margin-bottom: 40px;'>
                                                ".$this->session->flashdata('updateTheater')."
                                            </div>
                                        ";
                                    }
                                    if (empty($this->session->flashdata('errorTheater'))==false) {
                                        echo "
                                            <div class='col-12 alert alert-danger' role='alert' style='margin-bottom: 40px;'>
                                                ".$this->session->flashdata('errorTheater')."
                                            </div>
                                        ";
                                    }
                                ?>
                                <div style="display: flex;">
                                    <div class="accessories"><p></p></div>
                                    <h1 class="heading1">Theater - <span style="color: grey"><?php echo $data['nama_bioskop']?></span></h1>
                                </div>
                                    <div class="add_box">
                                        <span style="font-size: 30px; color: #2196F3"><b>Tambah Theater</b></span><br><br>
                                        <form action="<?php echo base_url(). 'theater/tambah/'. $data['id_bioskop'];?>" style="padding-bottom: 15px; padding-left: 50px;" method="post">
                                        <div class="row" >
                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label for="exampleFormControlSelect1">No Theater</label>
                                                    <div class="row">
                                                        <div class="col-auto" style="padding-right: 0px">
                                                            <span style="color:grey;height: 58px; line-height: 70px;margin-top: 14px; font-size: 25px">thr-</span>
                                                        </div>
                                                        <div class="col" style="padding-right: 0px; padding-left: 3px;">
                                                            <input type="number" name="no_theater" required class="form-control form-rounded" min="1" max="30" style="width: 200px;">
                                                        </div>
                                                    </div>
                                                        
                                                </div>
                                            </div>
                                            <div class="col-4">
                                                <div class="form-group">
                                                    <label for="exampleFormControlSelect1">Kapasitas Theater</label>
                                                    <div class="row">
                                                        <select name="kapasitas" class="form-control form-rounded" style="height: 44px; width: 200px; margin-left: 15px;" required>
                                                            <option value="">--- Kapasitas ---</option>
                                                            <option value="160">160 Seats</option>
                                                            <option value="238">238 Seats</option>
                                                        </select>
                                                    </div>     
                                                </div>
                                            </div>
                                            <div class="col-3 offset-1">
                                                <div class="form-group">
                                                    <label for="exampleFormControlSelect1" style="font-weight: bold"></label>
                                                    <button style="margin-top: 14px" type="submit" class="btn btn-success tombol">Tambah Theater Baru</button>
                                                </div>
                                            </div>
                                        </div>
                                        </form>
                                    </div>
                                        

                                    <div class="row" style="padding: 0px 15px 0px 15px">
                                        <table class="table table-dark table-striped">
                                            <thead>
                                                <tr>
                                                    <th style="width: 20px;">image</th>
                                                    <th style="width: 300px;">Id Theater</th>
                                                    <th style="width: 200px;">Nomor Theater</th>
                                                    <th style="width: 500px;">Kapasitas</th>
                                                    <th style="width: 200px;">Manage</th>
                                                    <th>Hapus</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                    foreach ($theater as $row){
                                                ?>
                                                    <tr>
                                                        <td><img style="width: 90%" src="<?php echo base_url()?>other/asset/icon/cinema.svg"></td>
                                                        <td ><?php echo $row['id_theater']?></td>
                                                        <td><?php echo $row['no_theater']?></td>
                                                        <td>
                                                            <form action="<?php echo base_url().'theater/edit/'.$row['id_theater'];?>" method="post">
                                                                <div class="row">
                                                                    <select name="kapasitas" class="form-control form-rounded" style="height: 44px; width: 200px;" required onchange="openButton('<?php echo $row['id_theater']?>')">
                                                                        <option value="160" <?php if ($row['kapasitas']=='160') { echo "selected";}?>>160 Seats</option>
                                                                        <option value="238" <?php if ($row['kapasitas']=='238') { echo "selected";}?>>238 Seats</option>
                                                                    </select>
                                                                    <input name="id_bioskop" required style="width: 200px; display: none" value="<?php echo $row['id_bioskop']?>">
                                                                    <input name="no_theater" required style="width: 200px; display: none" value="<?php echo $row['no_theater']?>">
                                                                    <button id="<?php echo $row['id_theater']?>" style="margin-top: 14px; margin-left: 20px; width: 200px;" type="submit" class="btn btn-secondary tombol" disabled="">Simpan Perubahan</button>
                                                                </div>
                                                            </form>
                                                        </td>

                                                        <td>
                                                            <a style="color: white;" href="<?php echo base_url().'admin/detail_theater/'.$row['id_theater']?>">
                                                                <button style="margin-top: 14px; margin-bottom: 14px" type="button" class="btn btn-primary tombol">Manage</button>
                                                            </a>
                                                            
                                                        </td>
                                                        <td>
                                                            <form style="margin: 14px 0px 14px 20px" action="<?php echo base_url().'theater/hapus/'.$row['id_theater'];?>" method="post">
                                                                <input type="checkbox" name="terms" value="yes" required style="margin-right: 12px; margin-bottom: 15px;">Ya, hapus Theater ini
                                                                <button type="submit" class="btn btn-danger tombol" >Hapus Theater</button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                            </div>

                            <script type="text/javascript">
                                function openButton(id) {
                                    var opButton = document.getElementById(id);
                                    opButton.classList.add("btn-success");
                                    opButton.disabled = false;
                                } 
                            </script>

                            <div id="hapusBioskop" class="col-12" style=";margin-top: 25px; padding: 45px 45px 0px 45px">
                                <div style="display: flex;">
                                    <div class="accessories" style="background-color: #DC3545;"><p></p></div>
                                    <h1 class="heading1">Hapus Bioskop - <span style="color: grey"><?php echo $data['nama_bioskop']?></span></h1>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        Menghapus Bioskop akan juga menghapus <span style="font-weight: bold">seluruh data Theater dan Kursi</span> yang berkaitan dengan bioskop ini dari Database.<br>
                                        Apakah anda yakin ingin <span style="font-weight: bold">menghapus Bioskop</span> ini?<br><br>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-2">
                                        <form action="<?php echo base_url().'bioskop/hapus/'.$data['id_bioskop'];?>" method="post">
                                            <div class="form_contain">
                                                <input type="checkbox" name="terms" value="yes" required style="margin-right: 12px;">Ya, hapus Bioskop ini
                                            </div>
                                            <div class="form_contain">
                                                <button type="submit" class="btn btn-danger tombol">Hapus Bioskop</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <script>
                                var x = document.getElementById("Theater");

                                var y = document.getElementById("hapusBioskop");                                
                                y.style.display = "none";

                                function theater_tab() {
                                    if (x.style.display === "none") {
                                        x.style.display = "block";
                                        y.style.display = "none";
                                        z.style.display = "none";
                                        document.getElementById("table_theater_button").classList.remove("btn-secondary");
                                        document.getElementById("table_theater_button").classList.add("btn-primary");
                                    }
                                }

                                function hapus_bioskop() {
                                    if (y.style.display === "none") {
                                        y.style.display = "block";
                                        x.style.display = "none";
                                        z.style.display = "none";
                                        document.getElementById("hapus_theater_button").classList.remove("btn-secondary");
                                        document.getElementById("hapus_theater_button").classList.add("btn-primary");

                                        document.getElementById("table_theater_button").classList.remove("btn-primary");
                                        document.getElementById("table_theater_button").classList.add("btn-secondary");
                                    }
                                } 
                            </script>
                        </div> 
                    </div>
                </div>


                                    
            </div>
        </div>
    </div>

   
</div>