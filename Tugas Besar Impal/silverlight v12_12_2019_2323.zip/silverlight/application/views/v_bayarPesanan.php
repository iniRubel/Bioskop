
        <script type="text/javascript">
            // $(document).ready(function(){
                var makmintotal = 0;
                // var judulfilm = "Once Upon a Time in Hollywood";
                // var namabioskop = "Center Poin Silverlight";
                // var haritanggal = "Rabu, 4 September";
                // var jam = "14.00 WIB";
                // var alamat = "Central Point Mall Lt.3A Jl. Pradana No.9, Bandung, Jawa Barat"

                var judulfilm = "<?php echo $tiket['judul']; ?>";
                var namabioskop = "<?php echo $tiket['nama_bioskop']; ?>";
                var haritanggal = "<?php echo $tiket['tanggal']; ?>";
                var jam = "<?php echo $tiket['jam']; ?>";
                var alamat = "<?php echo $tiket['alamat']; ?>";
                var jumkursi = "<?php echo $list['jumkursi']; ?>";
                console.log("<?php echo $list['jumkursi']; ?>");
                var i;  
                var data = "<?php echo $list['makmin']; ?>";
                var makanan = "";
                if (data != "") {
                    makanan = data.split(",");
                }
                var seats = "<?php echo $list['seats']; ?>";
                
                makmintotal = parseInt("<?php echo $list['makmintotal']; ?>");
                console.log(makanan[1]+"hahah");
                // console.log(makmintotal);
                // console.log(seats);
                console.log(data);
                console.log(jumkursi+"hahahahjumkursi");
                var hargaseats = 30000 * jumkursi;
                var hargaservice = 3000 * jumkursi;
                var jumlahservice = jumkursi;
                var hargatotal = hargaseats + hargaservice + makmintotal; 
                var datamakmin;
                function bookFunction() {
                    $("#formjudulfilm").val(judulfilm);
                    $("#formnamabioskop").val(namabioskop);
                    $("#formharitanggal").val(haritanggal);
                    $("#formjam").val(jam);
                    $("#formseats").val(seats);
                    $("#formalamat").val(alamat);
                    $("#formjumkursi").val(jumkursi);
                    console.log($("#formmakmin").val())

                }
                function conFunction() {
                  console.log("hahahahs")
                  var r = confirm("Apakah anda yakin menyelesaikan transaksi ?");
                  if (r == true) {
                    $("#formsimpantiket").submit();
                  } else {
                    
                  }
                }
                function batal() {
                var t = confirm("Apakah anda yakin ingin membatalkan pesanan ?");
                  if (t == true) {
                    $("#formbatal").submit();
                  } else {
                    
                  }
                }
                
            // })
            
        </script>
                <script type="text/javascript">
            $(document).ready(function(){
                $("#formtotal").val(hargatotal);    
                $("#hargatotal").text(hargatotal);
                $("#hargaseats").text(hargaseats);
                $("#hargaservice").text(hargaservice);
                $("#jumlahseats").text(jumkursi);
                $("#makmintotal").text(makmintotal);
                
                // $("#judulfilm").text(judulfilm);
                // $("#namabioskop").text(namabioskop);
                // $("#haritanggal").text(haritanggal);
                // $("#jam").text(jam);
                // $("#alamat").text(alamat);
                $("#jumlahservice").text(jumlahservice);
                for (i = 0; i < (seats.length)-1; i++) {
                    $("#kursi").append(seats[i]);
                    // console.log(i);
                }
                $("#kursi").append(seats[i]);
                if (makanan != "") {
                    var m = 1;
                    while (m <= makanan.length) {
                        $("#makmin").append("<p>"+makanan[m]+"</p>");
                        m = m+5;
                    } 
                    m = 2;
                    while (m <= makanan.length) {
                        $("#hargamakmin").append("<p>"+makanan[m]+" x "+makanan[m+1]+"</p>");
                        m = m+5;
                    }
                    console.log(makanan.length);    
                } else {
                    $("#makmin").append("<p>-</p>");
                }
            })
            
        </script>

<div class="container-fluid contain" style="margin-top: 174px;" >
    <div class="row">
        <div class="col-4">
            <img style="width: 500px;" src="<?php echo base_url()?>other/asset/icon/carabayar.png">
        </div>
        <div style="padding-left: 70px;color: white;" class="col-4">
            <center>
            <form id="formsimpantiket" method="post" action="<?php echo base_url()?>tiket/simpan_tiket">
                <div style="display: none;">
                <?php 
                        $id_tiket = uniqid('TKTS-');
                ?>      
                </script>
                <input id="idtik" type="text" name="id_tikets" value="<?php echo $id_tiket; ?>">
                <input type="text" name="email" value="<?php echo $this->session->userdata('email') ?>">
                <input type="text" name="nohp" value="<?php echo $this->session->userdata('nohp') ?>">
                <input type="text" name="tanggal" value="<?php echo date("Y-m-d"); ?>">
                <input type="text" name="id_jadwal" value="<?php echo $tiket['id_jadwal']; ?>">
                <input type="text" name="makmin" value="<?php echo $list['makmin']; ?>">
                <input type="text" name="kursi" value="<?php echo $list['seats']; ?>">
                <input id="formtotal" type="text" name="harga">
                </div>
            </form>
            <button onclick="conFunction()" style="background-color:#000B18;border: none;cursor: pointer; "><img src="<?php echo base_url()?>other/asset/icon/barcode.png"></button>
        <!--     <script type="text/javascript">
                $(document).ready(function(){
                function myFunction() {
                  var txt;
                  var r = confirm("Anda yakin menyelesaikan transaksi ?");
                  if (r == true) {
                    $("#formsimpantiket").submit();
                  } else {
                    
                  }
                    }
            });
            </script> -->
            <p>Harap selesaikan pembayaran sebelum 4 September 10.15 WIB</p>
            <p><b>3m 34d</b></p>
            </center>
        </div>
        <div class="col-4">
                    <div style="position:fixed;color: white;z-index: 99;">
        <div style="background-color: #000B18;border-radius: 30px;" class="harga">
        <div style="padding: 15px;">
        <div style="display: flex;" class="seats">
            <div style="width: 380px;">
                <p><b>Seats</b></p>
                <p id="kursi"></p>
            </div>
            <div>
                <p><b>Rp. <c id="hargaseats"></c></b></p>
                <p>30000 x <c id="jumlahseats"></c></p>
            </div>
            
        </div>
        <div style="display: flex;" class="sad">
            <div id="makmin" style="margin-right: 228px;">
                <p><b>Snacks and Drinks</b></p>
            </div>
            <div id="hargamakmin">
                <p><b>Rp. <c id="makmintotal">0</c></b></p>
            </div>
            
        </div>
        <div style="display: flex;" class="service">
            <div id="service" style="margin-right: 210px;">
                <p><b>Service</b></p>
                <p>Internet Handling Fee</p>
            </div>
            <div>
                <p><b>Rp. <c id="hargaservice"></c></b></p>
                <p>3000 x <c id="jumlahservice"></c></p>
            </div>

            
        </div>

        
        </div>
        <div style="display: flex;background-color: #0EA34A;border-bottom-left-radius: 30px;border-bottom-right-radius: 30px;padding-left: 20px;color: white;font-size: 25px;height: 60px;padding-top: 10px;">
            <p style="margin-right: 220px;"><b>TOTAL :</b></p>
            <p><b>Rp. <c id="hargatotal"></c></b></p>
            
        </div>
        </div>
        <p style="margin-top: 10px;">Payment by</p>
        <img style="margin-left: 20px;" src="<?php echo base_url()?>other/asset/icon/gopay.png">
    </div>
        </div>
    </div>
</div>
