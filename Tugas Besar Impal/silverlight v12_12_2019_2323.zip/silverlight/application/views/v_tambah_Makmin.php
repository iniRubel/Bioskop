        <div class="col-10 dashboard-right" style="margin-left: 300px;"> 
            <div class="container-fluid">
                <div class="row">
                    <div class="col-10">
                        <div style="display: flex;"> 
                            <div class="accessories" style="height: 100px;"><p></p></div>
                            <h1 class="heading1" style="font-size: 80px"><a style="color: white" href="<?php echo base_url()?>admin/admin_Makmin">Makmin</a> > <span style="color: #007bff">Tambah Makmin</span></h1> 
                        </div> 
                    </div>
                </div>
                <div class="row">
                    <div class="col-8" style="padding-right: 27px;">
                        <?php  
                            if (empty($this->session->flashdata('error'))==false) {
                                echo "
                                    <div class='col-12 alert alert-danger' role='alert' style='margin-bottom: 40px;'>
                                        ".$this->session->flashdata('error')."
                                    </div>
                                ";
                            }
                        ?>
                        <div class="sign_box">
                            <form action="<?php echo base_url(). 'makmin/tambah';?>" style="padding-bottom: 15px;" method="post" enctype='multipart/form-data'>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form_contain">
                                            Nama Makmin
                                            <input type="text" name="nama_makmin" required class="form-control form-rounded">
                                            <ul style='color: #b94a48; padding-top: 5px;'>
                                                <?php echo $this->session->flashdata('message0');?>
                                            </ul>
                                        </div>
                                        <div class="form_contain">
                                            Keterangan
                                            <input type="text" name="keterangan" required class="form-control form-rounded">    
                                        </div>
                                        <div class="form_contain">
                                            Harga
                                            <input type="number" name="harga" required class="form-control form-rounded">    
                                        </div>
                                    </div>

                                    <div class="col-6">
                                        <div class="form_contain">
                                            Gambar (.png)<br>
                                            <div style="margin-top: 14px; width: 300px" class="tomobol_Upload_Wrapper">
                                                <button type="button" class="btn btn-primary tombol">Pilih Gambar</button>
                                                <input style="height: 100%" type="file" required name="gambarMakmin" id="imageFile" height="100%" onchange="return fileValidation()" accept=".png">
                                                <script>
                                                    function fileValidation(){
                                                        var fileInput = document.getElementById('imageFile');
                                                        var filePath = fileInput.value;
                                                        var allowedExtensions = /(\.png)$/i;
                                                        if(!allowedExtensions.exec(filePath)){
                                                            alert('Tolong upload gambar dalam bentuk .png saja.');
                                                            fileInput.value = '';
                                                            return false;
                                                        }else{
                                                            //Image preview
                                                            if (fileInput.files && fileInput.files[0]) {
                                                                var reader = new FileReader();
                                                                reader.onload = function(e) {
                                                                    document.getElementById('imagePreview').innerHTML = '<img class="makmin_list_img" src="'+e.target.result+'"/>';
                                                                };
                                                                reader.readAsDataURL(fileInput.files[0]);
                                                            }
                                                        }
                                                    }
                                                </script>
                                            </div>
                                            <div class="col-10" id="imagePreview"></div>
                                        </div>
                                    </div>
                                </div>
                                <div style="margin-top: 20px;">
                                    <button type="submit" class="btn btn-success tombol">Tambah Makmin</button>
                                </div>                          
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

   
</div>