        <div class="col-10 dashboard-right" style="margin-left: 300px;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-10">
                        <div style="display: flex;"> 
                            <div class="accessories" style="height: 100px;"><p></p></div>
                            <h1 class="heading1" style="font-size: 80px"><a style="color: white" href="<?php echo base_url()?>admin/admin_Film">Film</a> > <span style="color: #007bff">Tambah Film</span></h1> 
                        </div> 
                    </div>
                </div>
                <div class="row">
                    <div class="col-12" style="padding-right: 27px;">
                        <?php  
                            if (empty($this->session->flashdata('error'))==false) {
                                echo "
                                    <div class='col-12 alert alert-danger' role='alert' style='margin-bottom: 40px;'>
                                        ".$this->session->flashdata('error')."
                                    </div>
                                ";
                            }
                        ?>
                        <div class="sign_box">
                            <form action="<?php echo base_url(). 'film/tambah';?>" style="padding-bottom: 15px;" method="post" enctype='multipart/form-data'>
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form_contain">
                                            Judul
                                            <input type="text" name="judul" required class="form-control form-rounded"> 
                                        </div>
                                        <div class="form_contain">
                                            Durasi (in Minutes)
                                            <input type="number" name="durasi" required class="form-control form-rounded" style="width: 200px">
                                        </div>
                                        <div class="form_contain">
                                            Gendre
                                            <input type="text" name="gendre" required class="form-control form-rounded">    
                                        </div>
                                        <div class="form_contain">
                                            Sutradara
                                            <input type="text" name="sutradara" required class="form-control form-rounded"> 
                                        </div>
                                        <div class="form_contain">
                                            Link Trailer
                                            <input type="url" name="link_trailer" required class="form-control form-rounded">
                                        </div>
                                        
                                    </div>

                                    <div class="col-4">
                                        <div class="form_contain">
                                            Tanggal Rilis
                                            <input id="rilis" class="form-control form-rounded" type="text" name="rilisRange" required>
                                            <script>
                                                // Date Picket
                                                var today = new Date();
                                                var dd = String(today.getDate()).padStart(2, '0');
                                                var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
                                                var yyyy = today.getFullYear();

                                                today = yyyy + '-' + mm + '-' + dd;
                                                $('#rilis').daterangepicker({
                                                    "locale": {
                                                        "format": "YYYY-MM-DD",
                                                        "separator": " - ",
                                                        "applyLabel": "Apply",
                                                        "cancelLabel": "Cancel",
                                                        "fromLabel": "From",
                                                        "toLabel": "To",
                                                        "customRangeLabel": "Custom",
                                                        "weekLabel": "W",
                                                        "daysOfWeek": [
                                                            "Min",
                                                            "Sen",
                                                            "Sel",
                                                            "Rab",
                                                            "Kam",
                                                            "Jum",
                                                            "Sab"
                                                        ],
                                                        "monthNames": [
                                                            "January",
                                                            "February",
                                                            "March",
                                                            "April",
                                                            "May",
                                                            "June",
                                                            "July",
                                                            "August",
                                                            "September",
                                                            "October",
                                                            "November",
                                                            "December"
                                                        ],
                                                        "firstDay": 1
                                                    },
                                                    "startDate": today,
                                                    "endDate": today,
                                                    "opens": "center"
                                                }, function(start, end, label) {
                                                  console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
                                                });
                                            </script>                             
                                        </div>

                                        <div class="form_contain">
                                            Rating Film
                                            <select name="rating" class="form-control form-rounded" style="height: 44px; width: 200px;" required>
                                                <option value="">-- Rating --</option>
                                                <option value="rating_su">SU</option>
                                                <option value="rating_13">13+</option>
                                                <option value="rating_17">17+</option>
                                                <option value="rating_21">21+</option>
                                            </select>
                                        </div>
                                        
                                        <div class="form_contain">
                                            Sinopsis
                                            <textarea class="form-control form-rounded-textarea" name="sinopsis" rows="11" required></textarea>
                                        </div>  
                                        
                                    </div>
                                    <div class="col-3">
                                        <div class="form_contain">
                                            Poster (.jpg)<br>
                                            <div style="margin-top: 14px; width: 300px" class="tomobol_Upload_Wrapper">
                                                <button type="button" class="btn btn-primary tombol">Pilih Gambar</button>
                                                <input style="height: 100%" type="file" required name="poster" id="poster" onchange="return fileValidation(this.id)" accept=".jpg">
                                            </div>
                                            <div class="col-12" id="poster_preview"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        Gambar Film(.jpg)<br>
                                    </div>
                                    <div class="col-3">
                                        <div class="form_contain">
                                            <div style="margin-top: 14px; margin-bottom: 14px; width: 300px" class="tomobol_Upload_Wrapper">
                                                <button type="button" class="btn btn-primary tombol">Pilih Gambar</button>
                                                <input style="height: 100%" type="file" required name="gambarFilm1" id="gambarFilm1" height="100%" onchange="return fileValidation(this.id)" accept=".jpg">
                                            </div>
                                            <div id="gambarFilm1_preview"></div>
                                        </div>
                                    </div>

                                    <div class="col-3">
                                        <div class="form_contain">
                                            <div style="margin-top: 14px; margin-bottom: 14px; width: 300px" class="tomobol_Upload_Wrapper">
                                                <button type="button" class="btn btn-primary tombol">Pilih Gambar</button>
                                                <input style="height: 100%" type="file" required name="gambarFilm2" id="gambarFilm2" height="100%" onchange="return fileValidation(this.id)" accept=".jpg">
                                            </div>
                                            <div id="gambarFilm2_preview"></div>
                                        </div>
                                    </div>

                                    <div class="col-3">
                                        <div class="form_contain">
                                            <div style="margin-top: 14px; margin-bottom: 14px; width: 300px" class="tomobol_Upload_Wrapper">
                                                <button type="button" class="btn btn-primary tombol">Pilih Gambar</button>
                                                <input style="height: 100%" type="file" required name="gambarFilm3" id="gambarFilm3" height="100%" onchange="return fileValidation(this.id)" accept=".jpg">
                                            </div>
                                            <div id="gambarFilm3_preview"></div>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div style="margin-top: 20px;">
                                    <button type="submit" class="btn btn-success tombol">Tambah Film</button>
                                </div>                           
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function fileValidation(id){
    var fileInput = document.getElementById(id);
    var filePath = fileInput.value;
    var allowedExtensions = /(\.jpg)$/i;
        if(!allowedExtensions.exec(filePath)){
            alert('Upload gambar dalam bentuk .jpg');
            fileInput.value = '';
            return false;
        }else{
            //Image preview
            if (fileInput.files && fileInput.files[0]) {
            var reader = new FileReader();
                reader.onload = function(e) {
                    if (id=='poster') {
                        var p = 'poster'
                    } else {
                        var p = 'img'
                    }
                    document.getElementById(id+'_preview').innerHTML = '<img class="film_detail_'+p+'" src="'+e.target.result+'"/>';
                };
                reader.readAsDataURL(fileInput.files[0]);
            }
        }
    }
</script>