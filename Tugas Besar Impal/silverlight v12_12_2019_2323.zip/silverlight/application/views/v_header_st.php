<div style="position: fixed; z-index: 9999; top: 0; height: 90px;padding-top: 28px" class="container-fluid navigation" >
	<div class="row 	justify-content-between">
		<div class="col-auto" style="margin-top: auto; margin-bottom: auto">
			<a href="" class="linknav">Film</a>
			<a href="" class="linknav">Bioskop</a>
		</div>

		<div class="col-auto">
			<div class="row">
				<div class="col-auto" style='margin-top: auto; margin-bottom: auto; padding-right: 0px;
				<?php
					if($this->session->userdata('status') == "login" and $this->session->userdata('type') == "users"){
						echo "display: none;";
					} else {
						echo "display: block;";
					}
				?>'>
					<a href="<?php echo base_url() ?>users/signup/" class="linknav">Sign Up</a>
					<a href="<?php echo base_url() ?>users/signin/" class="linknav">Sign In</a>	
				</div>
				<div class="col-auto" style='margin-top: auto; margin-bottom: auto; padding-right: 0px;
				<?php
					if($this->session->userdata('status') == "login" and $this->session->userdata('type') == "users"){
						echo "display: block;";
					} else {
						echo "display: none;";
					}
				?>'>
					<a href="<?php echo base_url() ?>users/signout/" class="linknav">Sign Out</a>	
				</div>
				<div class="col-auto" style='padding-left: 0px;<?php
					if($this->session->userdata('status') == "login" and $this->session->userdata('type') == "users"){
						echo "display: block;";
					} else {
						echo "display: none;";
					}
				?>'>
					<a href="<?php echo base_url().'tiket/lihat_tiket/'.$this->session->userdata('nohp') ?>" class="linknav"><button type="button tombol" class="btn btn-primary tombol" style="width: 100%"><?php echo $this->session->userdata('email')?></button></a>
				</div>
			</div>
		</div>
	</div>
</div>