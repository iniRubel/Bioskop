<div class="container-fluid" style="margin-top: 90px;">
    <div class="row">
        <div class="col dashboard-left" style="height: 1080px; position: fixed; z-index: 9998; top: 90px; width: 300px;">
            <div>
                <div>
                    <a href="<?php echo base_url()?>admin"><button class="btn btn-primary dashboard-leftButton">Home</button></a>
                </div>
                <div>
                    <a href="<?php echo base_url()?>admin/admin_Film"><button class="btn btn-primary dashboard-leftButton">Film</button></a>
                </div>
                <div>
                    <a href="<?php echo base_url()?>admin/admin_Makmin"><button class="btn btn-primary dashboard-leftButton">Makanan Minuman</button></a>
                </div>
                <div>
                    <a href="<?php echo base_url()?>admin/admin_Bioskop"><button class="btn btn-primary dashboard-leftButton">Bioskop</button></a>
                </div>
                <div>
                    <a href="<?php echo base_url()?>admin/admin_Users"><button class="btn btn-primary dashboard-leftButton">Users</button></a>
                </div>
            </div>
        </div>
    
