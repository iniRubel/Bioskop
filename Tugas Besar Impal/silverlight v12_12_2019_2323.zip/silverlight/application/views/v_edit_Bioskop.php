        <div class="col-10 dashboard-right" style="margin-left: 300px;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-10">
                        <div style="display: flex;">
                            <div class="accessories" style="height: 100px;"><p></p></div>
                            <h1 class="heading1" style="font-size: 80px"><a style="color: white" href="<?php echo base_url()?>admin/admin_Bioskop">Bioskop</a> > <span style="color: #007bff"><?php echo $data['nama_bioskop'] ?></span></h1> 
                        </div> 
                    </div>
                    
                </div>


            <form action="<?php echo base_url(). 'bioskop/edit/'.$data['id_bioskop'];?>" style="padding-bottom: 15px;" method="post" enctype='multipart/form-data'>
                <div class="row">
                    <?php  
                        if (empty($this->session->flashdata('error'))==false) {
                            echo "
                                <div class='col-12 alert alert-danger' role='alert' style='margin-bottom: 40px;'>
                                    ".$this->session->flashdata('error')."
                                </div>
                            ";
                        }
                    ?>
                </div>
                <div class="row" style="margin-bottom: 40px;">
                    
                    <div class="col-3">
                        <img id="imagePreview" class="bioskop_list_img" src="<?php echo base_url()?>other/asset/bioskop/<?php echo $data['id_bioskop']?>.jpg" alt="">
                        <div class="form_contain">
                            Gambar (.jpg)<br>
                            <div style="margin-top: 14px; width: 300px" class="tomobol_Upload_Wrapper">
                                <button type="button" class="btn btn-primary tombol">Upload a file</button>
                                <input style="height: 100%" type="file" name="gambarBioskop" id="imageFile" height="100%" onchange="return fileValidation()">
                                <script>
                                    function fileValidation(){
                                        var fileInput = document.getElementById('imageFile');
                                        var filePath = fileInput.value;
                                        var allowedExtensions = /(\.jpg)$/i;
                                        if(!allowedExtensions.exec(filePath)){
                                            alert('Please upload file having extensions .jpg only.');
                                            fileInput.value = '';
                                            return false;
                                        }else{
                                            //Image preview
                                            if (fileInput.files && fileInput.files[0]) {
                                                var reader = new FileReader();
                                                reader.onload = function(e) {
                                                    document.getElementById("imagePreview").src = e.target.result;
                                                };
                                                reader.readAsDataURL(fileInput.files[0]);
                                            }
                                        }
                                    }
                                </script>
                            </div>
                        </div> 
                    </div>

                    <div class="col-9" style="padding-left: 60px">
                        <div class="row">
                            <p class="tulisan" style="font-weight: bold">Nama Bioskop:</p>
                        </div>
                        <div class="row">
                            <input style="width: 300px; margin: 0px 0px 25px 0px;" type="text" name="nama_bioskop" required class="form-control form-rounded" value="<?php echo $data['nama_bioskop'] ?>">
                            <ul style='color: #b94a48; padding-top: 5px;'>
                                <?php echo $this->session->flashdata('message0');?>
                            </ul>
                        </div>
                        <div class="row">
                            <p class="tulisan" style="font-weight: bold">Alamat:</p>
                        </div>
                        <div class="row">
                            <input style="width: 500px; margin: 0px 0px 25px 0px;" type="text" name="alamat" required class="form-control form-rounded" value="<?php echo $data['alamat'] ?>">
                        </div>
                        <div class="row">
                            <p class="tulisan" style="font-weight: bold">Kota:</p>
                        </div>
                        <div class="row">
                            <input style="width: 500px; margin: 0px 0px 25px 0px;" type="text" name="kota" required class="form-control form-rounded" value="<?php echo $data['kota'] ?>">
                        </div>
                        <div class="row">
                            <p class="tulisan" style="font-weight: bold">Nomor Telpon:</p>
                        </div>
                        <div class="row">
                            <input style="width: 500px; margin: 0px 0px 25px 0px;" type="tel" pattern="[0-9]{12}" name="no_telp" required class="form-control form-rounded" value="<?php echo $data['no_telp'] ?>">
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-12 film_list">
                        <div class="row">
                            <div class="col-2">
                                <button type="submit" class="btn btn-success" style="width: 100%; height: 100%; border-radius: 1rem; padding: 20px" onclick="tambah_theater()"> 
                                    <div>
                                        <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/save.svg">    
                                    </div> 
                                    <b>Simpan Perubahan</b>
                                </button>
                            </div>
                            <div class="col-2">
                                <a href="<?php echo base_url().'admin/detail_bioskop/'.$data['id_bioskop']?>">
                                    <button type="button" class="btn btn-danger" style="width: 100%; height: 100%; border-radius: 1rem; padding: 20px" onclick="tambah_theater()"> 
                                        <div>
                                            <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/xicon.svg">    
                                        </div> 
                                        <b>Batalkan Perubahan</b>
                                    </button>
                                </a>
                            </div>
                        </div> 
                    </div>
                </div>
            </form>
            </div>
        </div>
    </div>  
</div>