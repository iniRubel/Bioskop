<div class="container-fluid contain" style="margin-top: 174px;" >
	<div class="row">
		<div class="col-12">
			<div style="display: flex;">
				<div class="accessories"><p></p></div>
				<h1 class="heading1">Snack and Drinks</h1>	
			</div>	
		</div>
        <div style="padding-left: 45px; color: white; margin-bottom: 48px;" >
            Temani waktu nontonmu dengan makanan dan minuman dari kami. Pesan langsung disini
        </div>
	</div>
    <div style="display: flex;" class="col-12">
        <div class="col-8">
        	<div class="row justify-content-between">
                <?php
                    $x = 1;
                    $makmintotal = 0; 
                    $judulfilm = $tiket['judul'];  
                ?>

                <script type="text/javascript">
                        var makmintotal = 0;

                        var judulfilm = "<?php echo $tiket['judul']; ?>";
                        var namabioskop = "<?php echo $tiket['nama_bioskop']; ?>";
                        var haritanggal = "<?php echo $tiket['tanggal']; ?>";
                        var jam = "<?php echo $tiket['jam']; ?>";
                        var alamat = "<?php echo $tiket['alamat']; ?>";
                        var jumkursi = "<?php echo $seatslist['jumkursi']; ?>";
                        var i;  
                        var data = [];
                        var seats = "<?php echo $seatslist['seats']; ?>";
                        
                        // console.log(haritanggal+"hahahha");
                        var hargaseats = 30000 * jumkursi;
                        var hargaservice = 3000 * jumkursi;
                        var jumlahservice = jumkursi;
                        var hargatotal = hargaseats + hargaservice; 
                        var datamakmin;
                        function formFunction() {
                            console.log(seats);
                            $("#formseats1").val(seats);
                            $("#formmakmin").val(data);
                            $("#formjumkursi").val(jumkursi);
                            $("#formmakmintotal").val(makmintotal);
                            console.log($("#formmakmin").val())

                        }
                        function formFunction2() {
                            $("#formjudulfilm1").val(judulfilm);
                            $("#formnamabioskop1").val(namabioskop);
                            $("#formharitanggal1").val(haritanggal);
                            $("#formjam1").val(jam);
                            $("#formalamat1").val(alamat);

                        }
                        function batal() {
                        var t = confirm("Apakah anda yakin ingin membatalkan pesanan ?");
                          if (t == true) {
                            $("#formbatal").submit();
                          } else {
                            
                          }
                        }
                </script>

                <script type="text/javascript">
                    $(document).ready(function(){
                        $("#hargatotal").text(hargatotal);
                        $("#hargaseats").text(hargaseats);
                        $("#hargaservice").text(hargaservice);
                        $("#jumlahseats").text(jumkursi);
                        console.log(jumlahservice);
                        $("#jumlahservice").text(jumlahservice);
                        
                        for (i = 0; i < (seats.length)-1; i++) {
                            $("#kursi").append(seats[i]);
                            console.log(i);
                        }
                        $("#kursi").append(seats[i]);
                    })
                </script>
                <?php 
                    foreach ($list as $row){
                ?>
                    <div class="col-lg-3">
                        <div class="film_list">
                            <img class="makmin_list_img" src="<?php echo base_url()?>other/asset/makmin/<?php echo $row['id_makmin']?>.png" alt="">
                            <div style="height: 210px;">

                                <div style="height: 160px;">
                                    <div style="height: 60px;">
                                        <p><b><?php echo $row['nama_makmin'] ?></b></p>
                                    </div>
                                    <div style="height: 45px;">
                                        <p style="font-size: 15px;color: #207ED9"><?php echo $row['keterangan'] ?></p>
                                    </div>
                                    <p style="color: #39C268"><b> Rp. <?php echo $row['harga'] ?> /Item</b></p>
                                </div>

                                <button id="b<?php echo $x ?>" style="display: block;" type="button" class="btn btn-primary tombol">Tambah</button>

                                <div id="butt<?php echo $x ?>" style="display: none;margin-left: 10px;">
                                    <div style="display: flex;">
                                        <button id="tambah<?php echo $x ?>" style="width: 45px;border-radius: 100px;height: 45px;padding-bottom: 8px;" type="button" class="btn btn-primary tombol"><b>+</b></button>
                                        <div style="background-color: white;color: black;border-radius: 20px;width: 60px;text-align: center;margin-left: 10px;margin-right: 10px;height: 50px;">
                                            <p id="isi<?php echo $x ?>" style="margin-top: 10px;">1</p>
                                        </div>
                                        <button id="kurang<?php echo $x ?>" style="width: 45px;border-radius: 100px;height: 45px;padding-bottom: 8px;" type="button" class="btn btn-primary tombol"><b>-</b></button>
                                    </div>
                                </div>

                                <script type="text/javascript">
                                    $(document).ready(function(){
                                        var jumlah<?php echo $x ?>;
                                        $("#b<?php echo $x ?>").click(function(){
                                            // if (jumlah<?php echo $x ?> == 0) {
                                                jumlah<?php echo $x ?> = 1;
                                                console.log('Hello_'+jumlah<?php echo $x ?>);
                                                $("#b<?php echo $x ?>").css("display","none");
                                                $("#butt<?php echo $x ?>").css("display","block");
                                                $("#makmin").append("<p id="+"nama"+<?php echo $x ?>+"><?php echo $row['nama_makmin'] ?></p")
                                                $("#hargamakmin").append("<p id="+"harga"+<?php echo $x ?>+"><?php echo $row['harga'] ?> x <c id='jumlah<?php echo $x ?>'>1</c></p>")
                                                makmintotal = makmintotal + (<?php echo $row['harga'] ?>);
                                                $("#makmintotal").text(makmintotal);
                                                hargatotal = hargatotal + parseInt(<?php echo $row['harga'] ?>);
                                                console.log(hargatotal);
                                                $("#hargatotal").html(hargatotal);
                                                datamakmin = ["<?php echo $row['id_makmin'] ?>","<?php echo $row['nama_makmin'] ?>",<?php echo $row['harga'] ?>,jumlah<?php echo $x?>,'#'];
                                                data.push(datamakmin);
                                                console.log(data);    
                                            // }
                                        })
                                        $("#tambah<?php echo $x ?>").click(function(){
                                            // if (jumlah<?php echo $x ?> <= 7) {
                                                jumlah<?php echo $x ?>++;
                                                console.log('Hello_'+jumlah<?php echo $x ?>);
                                                makmintotal = makmintotal + <?php echo $row['harga'] ?>;
                                                i = 0;
                                                while (data[i][1] != "<?php echo $row['nama_makmin'] ?>") {
                                                    i++;
                                                }
                                                data[i].pop();
                                                data[i].pop();
                                                data[i].push(jumlah<?php echo $x ?>,'#');
                                                console.log(data);
                                                hargatotal = hargatotal + <?php echo $row['harga'] ?>;
                                                $("#hargatotal").text(hargatotal);
                                                $("#isi<?php echo $x ?>").text(jumlah<?php echo $x ?>);
                                                $("#jumlah<?php echo $x ?>").text(jumlah<?php echo $x ?>);
                                              
                                                $("#makmintotal").text(makmintotal);
                                            // }
                                        })
                                        $("#kurang<?php echo $x ?>").click(function(){
                                            // if (jumlah<?php echo $x ?> >0) {
                                                jumlah<?php echo $x ?>--;
                                                console.log('Hello_'+jumlah<?php echo $x ?>);
                                                i = 0;
                                                while (data[i][1] != "<?php echo $row['nama_makmin'] ?>") {
                                                    i++;
                                                }
                                                data[i].pop();
                                                data[i].pop();
                                                data[i].push(jumlah<?php echo $x ?>,'#');
                                                hargatotal = hargatotal - <?php echo $row['harga'] ?>;
                                                $("#hargatotal").text(hargatotal);
                                                makmintotal = makmintotal - <?php echo $row['harga'] ?>;
                                                if (jumlah<?php echo $x ?> <= 0) {
                                                    while (data[i][1] != "<?php echo $row['nama_makmin'] ?>") {
                                                        i++;
                                                    }
                                                    data.splice(i,1);
                                                    $("#b<?php echo $x ?>").css("display","block");
                                                    $("#butt<?php echo $x ?>").css("display","none");
                                                    $("#nama<?php echo $x ?>").remove();
                                                    $("#harga<?php echo $x ?>").remove();
                                                    $("#makmintotal").text(makmintotal);
                                                    
                                                }else{
                                                    $("#isi<?php echo $x ?>").text(jumlah<?php echo $x ?>);
                                                    $("#jumlah<?php echo $x ?>").text(jumlah<?php echo $x ?>);
                                                    $("#makmintotal").text(makmintotal);
                                                    
                                                }    
                                            // }
                                        })
                                    })
                                </script>
                            </div>
                        </div>
                    </div>
                <?php 
                    $x = $x + 1;
                } ?> 
        	</div>
        </div>

        <div class="col-4" style="padding-left: 60px">
            <div style="position: fixed;color: white;z-index: 99;">
                <div style="background-color: #000B18;border-radius: 30px;" class="harga">
                    <div style="padding: 15px;">
                        <div style="display: flex;" class="seats">
                            <div style="width: 380px;">
                                <p><b>Seats</b></p>
                                <p id="kursi"></p>
                            </div>
                            <div>
                                <p><b>Rp. <c id="hargaseats"></c></b></p>
                                <p>30000 x <c id="jumlahseats"></c></p>
                            </div>
                            
                        </div>
                        <div style="display: flex;" class="sad">
                            <div id="makmin" style="margin-right: 228px;">
                                <p><b>Snacks and Drinks</b></p>
                            </div>
                            <div id="hargamakmin">
                                <p><b>Rp. <c id="makmintotal">0</c></b></p>
                            </div>
                            
                        </div>
                        <div style="display: flex;" class="service">
                            <div id="service" style="margin-right: 210px;">
                                <p><b>Service</b></p>
                                <p>Internet Handling Fee</p>
                            </div>
                            <div>
                                <p><b>Rp. <c id="hargaservice"></c></b></p>
                                <p>3000 x <c id="jumlahservice"></c></p>
                            </div>
                        </div>
                    </div>
                    <div style="display: flex;background-color: #0EA34A;border-bottom-left-radius: 30px;border-bottom-right-radius: 30px;padding-left: 20px;color: white;font-size: 25px;height: 60px;padding-top: 10px;">
                        <p style="margin-right: 220px;"><b>TOTAL :</b></p>
                        <p><b>Rp. <c id="hargatotal"></c></b></p>
                        
                    </div>
                </div>
                <p style="margin-top: 40px;">Payment by</p>
                <img style="margin-left: 20px;" src="<?php echo base_url()?>other/asset/icon/gopay.png">
            </div>
        </div>
    </div>
</div>

<div style="background-color: #000B18; margin-top: 100px; padding: 20px; color: white">
    <center>
        Silverlight 2019
    </center>
</div>