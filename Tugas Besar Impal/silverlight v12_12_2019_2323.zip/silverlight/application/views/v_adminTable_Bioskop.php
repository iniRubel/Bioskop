        <div class="col-10 dashboard-right" style="margin-left: 300px;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-10">
                        <div style="display: flex;">
                            <div class="accessories" style="height: 100px;"><p></p></div>
                            <h1 class="heading1" style="font-size: 80px">Bioskop</h1> 
                        </div> 
                    </div>
                    <div class="col-2">
                        <div class="film_list">
                            <a href="<?php echo base_url() ?>admin/tambah_bioskop">
                            <button type="button" class="btn btn-primary" style="width: 100%; height: 100%; border-radius: 1rem; padding: 20px"> 
                                <div>
                                    <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/plus.svg">    
                                </div> 
                                <b>Tambah Bioskop</b>
                            </button>
                            </a>
                        </div> 
                    </div>
                </div>
                <div class="row">
                    <?php  
                        if (empty($this->session->flashdata('update'))==false) {
                            echo "
                                <div class='col-12 alert alert-success' role='alert' style='margin-bottom: 40px;'>
                                    ".$this->session->flashdata('update')."
                                </div>
                            ";
                        }
                    ?>
                    <div class="col-12">
                        <form style="width: 900px; padding-left: 15px;"  class="example" action="<?php echo base_url().'admin/cari_bioskop/'; ?>" style="margin:auto; max-width:900px" method="get">
                            <div class="row">
                                <div class="col-4" style="padding:0px;">
                                    <input style="width: 100%" type="text" placeholder="Cari Bioskop" name="scTabBioskop">    
                                </div>
                                <div class="col-1" style="padding:0px;">
                                    <button type="submit" style="width: 100%">
                                        <img style="width: 20px" src="<?php echo base_url()?>other/asset/icon/search.svg">
                                    </button>
                                </div>
                            </div>       
                        </form>
                    </div>
                    <div class="col-lg-12">
                        <p style="color: white;margin: 15px 0px 30px 0px">
                            <?php 
                                if ($search!='') {
                                    echo "Hasil pencarian: ". $search; 
                                }
                            ?>
                        </p>
                        <div class="row">
                            <?php 
                                foreach ($list as $row){
                            ?>
                                <div class="col-3" style="margin-bottom: 30px;">
                                    <div class="film_list" style="height: 100%; position: relative; width: 100%;">
                                        <img class="bioskop_list_img" src="<?php echo base_url()?>other/asset/bioskop/<?php echo $row['id_bioskop']?>.jpg" alt="">
                                        <p><b><?php echo $row['nama_bioskop'] ?></b></p>
                                         <p style="font-size: 15px;color: #207ED9 "><?php echo $row['kota'] ?></p>
                                        <br>
                                        <div style="position: absolute; width: 100%; bottom: 15px; padding-right: 30px;">
                                            <a href="<?php echo base_url()?>admin/detail_bioskop/<?php echo $row['id_bioskop']?>"><button type="button" class="btn btn-primary tombol">Detail</button></a>   
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>                            
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

   
</div>