<div style="color: white;  position: fixed; z-index: 9999; top: 0;" class="container-fluid navigation"> 
	<div class="row">
        <div> 
            <form method="POST" action="<?php echo base_url(). 'tiket/pilih_kursi/'.$tiket['id_jadwal'];?>">
                <div style="display: none;">
                    <input id="formseats" type="text" name="seats" value='<?php echo $seatslist['seats']?>'>
                </div>
                <button style="display: block;color: white;cursor: pointer; font-size: 80px;background-color: #000B18;border: none;" type="submit" >
                    <img style="width: 30px; padding-bottom: 100px;" src="<?php echo base_url().'other/asset/icon/back.svg'?>">
                </button>
            </form>
        </div>

		<div style="padding-left: 30px;">
			<p  style="color: #207ED9;font-size: 25px;"><b><c id="judulfilm"></c></b></p>
			<div style="display: flex;">
				<p  style="margin-right: 20px;font-size: 20px;"><b><c id="namabioskop"></c></b></p>
				<p  style="margin-right: 20px;font-size: 20px;"><b><c id="haritanggal"></c></b></p>
				<p  style="font-size: 20px;"><b><c id="jam" ></c></b></p>
			</div>
			<p style="font-size: 12px;"><c id="alamat"></c></p>
		</div>

		<div class="col" style="padding: 0px; margin: 0px;"></div>
			
		<div style="padding-right: 30px;">
			<div style="display: flex;">
    			<div style="width: 100%; padding: 10px 15px 10px 10px;">registered as</div>
                <div class="tombol" style="background-color: #0052A2; text-align: center; line-height: 53px; width: 100%; padding-left: 25px; padding-right: 25px;margin-right: 50px;">
                    <?php echo $this->session->userdata('email')?>
                </div>
    			<form method="post" action="<?php echo base_url(). 'tiket/pembayaran/'.$tiket['id_jadwal'];?>">
    				<div style="display: none;">
        				<input id="formseats1" type="text" name="seats">
        				<input id="formmakmin" type="text" name="makmin">
                        <input id="formjumkursi" type="text" name="jumkursi">
                        <input id="formmakmintotal" type="text" name="makmintotal">
    				</div>
                    <button onclick="formFunction()" style="display: block;width: 280px;"class="btn btn-primary tombol" type="submit">Bayar</button>	
    			</form>
    	   
                <script type="text/javascript">
                    // $(document).ready(function(){
                        // var makmintotal = 0;
                       
                        // console.log(seats);
                        // var hargaseats = 90000;
                        // var hargaservice = 3000 * seats.length;
                        // var jumlahservice = seats.length;
                        // var datamakmin;
                        // function formFunction() {
                        //     $("#formjudulfilm").val(judulfilm);
                        //     $("#formnamabioskop").val(namabioskop);
                        //     $("#formharitanggal").val(haritanggal);
                        //     $("#formjam").val(jam);
                        //     $("#formseats").val(seats);
                        //     $("#formmakmin").val(data);
                        //     $("#formbayar").val(hargatotal);
                        //     console.log($("#formmakmin").val())

                        // }
                        
                    // })
                    
                </script>

                <script type="text/javascript">
                    $(document).ready(function(){
                        // console.log(judulfilm+"hahahahah");
                        // $("#hargatotal").text(hargatotal);
                        // $("#hargaseats").text(hargaseats);
                        // $("#hargaservice").text(hargaservice);
                        $("#judulfilm").text(judulfilm);
                        $("#namabioskop").text(namabioskop);
                        $("#haritanggal").text(haritanggal);
                        $("#jam").text(jam);
                        $("#alamat").text(alamat);
                        console.log(haritanggal);
                        // console.log(jumlahservice);
                        // $("#jumlahservice").text(jumlahservice);
                        // for (i = 0; i < (seats.length)-1; i++) {
                        //     $("#kursi").append(seats[i]+", ");
                        // }
                        // $("#kursi").append(seats[i]);

                    })                  
                </script>
			</div>
		</div>
        <div>
            <form id="formbatal" action="<?php echo base_url(). 'home/'?>"></form>
            <button onclick="batal()" style="display: block;color: white;cursor: pointer; font-size: 50px;background-color: #000B18;border: none;" >
                <img style="width: 30px; padding-bottom: 50px;" src="<?php echo base_url().'other/asset/icon/close.svg'?>">
            </button>
        </div>
	</div>
</div>