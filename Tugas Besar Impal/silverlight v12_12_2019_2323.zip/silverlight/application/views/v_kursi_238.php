<div style="margin-top: 174px;"></div>
<div style="background-color: #0EA34A;font-size:18px;height:60px;display:flex;padding-top:15px;padding-left:275px;color:white;padding-right:215px; margin: 0px;  position: fixed; z-index: 9999; top: 174; width: 100%" class="harga row">
    <div>
         <p><b><c id="jumlahseats">0</c> X Rp 30.000 / seat</b></p>    
    </div>
    <div class="col" style="padding: 0px; margin: 0px;"></div>
    <div>
        <p><b>Total : Rp. <c id="totalkursi">0</c></b></p>    
    </div>
    
</div>

        <script type="text/javascript">
                <?php 
                    $id = $tiket['id_jadwal'];
                ?>
                var makmintotal = 0;
                var pilihkursi = 0;
                var hargakursi = 0;
                // var judulfilm = "Once Upon a Time in Hollywood";
                // var namabioskop = "Center Poin Silverlight";
                // var haritanggal = "Rabu, 4 September";
                // var jam = "14.00 WIB";
                // var alamat = "Central Point Mall Lt.3A Jl. Pradana No.9, Bandung, Jawa Barat"
                var judulfilm = "<?php echo $tiket['judul']; ?>";
                var namabioskop = "<?php echo $tiket['nama_bioskop']; ?>";
                var haritanggal = "<?php echo $tiket['tanggal']; ?>";
                var jam = "<?php echo $tiket['jam']; ?>";
                var alamat = "<?php echo $tiket['alamat']; ?>";
                var i;  
                var kursi;
                var data = [];
                var hargatotal = 99000; 
                var seats = [15,17,80,20,148];
                var bookseats = [];
                var hargaseats = 90000;
                var hargaservice = 3000 * seats.length;
                var jumlahservice = seats.length;
                var datamakmin;
                function bookFunction() {
                    $("#formseats").val(bookseats);
                    $("#formjumkursi").val(pilihkursi);
                    console.log($("#formmakmin").val())

                }
                function batal() {
                var t = confirm("Apakah anda yakin ingin membatalkan pesanan ?");
                  if (t == true) {
                    $("#formbatal").submit();
                  } else {
                    
                  }
                }
        </script>

        <script type="text/javascript">
            $(document).ready(function(){
                $("#hargatotal").text(hargatotal);
                $("#hargaseats").text(hargaseats);
                $("#hargaservice").text(hargaservice);
                $("#judulfilm").text(judulfilm);
                $("#namabioskop").text(namabioskop);
                $("#haritanggal").text(haritanggal);
                $("#jam").text(jam);
                $("#alamat").text(alamat);
                console.log(jumlahservice);
                $("#jumlahservice").text(jumlahservice);
                for (i = 0; i < (seats.length)-1; i++) {
                    $("#kursi").append(seats[i]+", ");
                }
                $("#kursi").append(seats[i]);

            })
            
        </script>

<div class="" style="padding-top: 135px;" >
    <center>
    <?php
    foreach(range('A','J') as $aplh){
        
    ?>
    <div class="row justify-content-md-center" style="margin-bottom: 20PX;">
        <div style="color: white; font-weight: bold; padding-top: 17px; padding-right: 25px;">
            <?php echo $aplh?>
        </div>
        <div>
            <div class="row justify-content-md-center">
                <?php
                    for ($i=1; $i < 5; $i++) { 
                ?>
                    <div id="buttputih<?php echo $i.$aplh ?>" style="margin-right: 10px;margin-left: 10px;display: block; padding-left: 0px;">
                        <button class="kursi_putih"><?php echo $i.$aplh; ?></button>
                    </div>
                    <div id="buttbiru<?php echo $i.$aplh ?>" style="margin-right: 10px;margin-left: 10px;display: none;color: white; padding-left: 0px;">
                        <button class="kursi_biru"><b><?php echo $i.$aplh; ?></b></button>
                    </div>
                    <div id="butthitam<?php echo $i.$aplh ?>" style="margin-right: 10px;margin-left: 10px;display: none;color: white; padding-left: 0px;" >
                        <button class="kursi_hitam"><b><?php echo $i.$aplh; ?></b></button>
                    </div>

                    <script type="text/javascript">
                        $(document).ready(function(){
                            $("#buttputih<?php echo $i.$aplh ?>").click(function(){
                                if (pilihkursi < 8) {
                                    $("#buttputih<?php echo $i.$aplh ?>").css("display","none");
                                    $("#buttbiru<?php echo $i.$aplh ?>").css("display","block");
                                    bookseats.push('<?php echo $i.$aplh ?>');
                                    console.log(bookseats);
                                    pilihkursi++;
                                    $("#jumlahseats").text(pilihkursi);
                                    hargakursi = pilihkursi * 30000;
                                    $("#totalkursi").text(hargakursi);    
                                }
                                console.log(pilihkursi);
                                
                            })
                            $("#buttbiru<?php echo $i.$aplh ?>").click(function(){
                                $("#buttputih<?php echo $i.$aplh ?>").css("display","block");
                                $("#buttbiru<?php echo $i.$aplh ?>").css("display","none");
                                i = 0;
                                while (bookseats[i] != "<?php echo $i.$aplh?>") {
                                    console.log(bookseats[i]);
                                    i++;
                                }
                                // console.log(bookseats[1]);
                                bookseats.splice(i,1);
                                console.log(bookseats);
                                pilihkursi--;
                                $("#jumlahseats").text(pilihkursi);
                                hargakursi = pilihkursi * 30000;
                                $("#totalkursi").text(hargakursi);
                            })
                        })
                    </script>
                <?php
                    } 
                ?>
            </div>
        </div>

        <div style="width: 130px">
            
        </div>

        <div>
            <div class="row justify-content-md-center">
                <?php
                    for ($i=5; $i < 14; $i++) { 
                ?>
                    <div id="buttputih<?php echo $i.$aplh ?>" style="margin-right: 10px;margin-left: 10px;display: block; padding-left: 0px;">
                        <button class="kursi_putih"><?php echo $i.$aplh; ?></button>
                    </div>
                    <div id="buttbiru<?php echo $i.$aplh ?>" style="margin-right: 10px;margin-left: 10px;display: none;color: white; padding-left: 0px;">
                        <button class="kursi_biru"><b><?php echo $i.$aplh; ?></b></button>
                    </div>
                    <div id="butthitam<?php echo $i.$aplh ?>" style="margin-right: 10px;margin-left: 10px;display: none;color: white; padding-left: 0px;" >
                        <button class="kursi_hitam"><b><?php echo $i.$aplh; ?></b></button>
                    </div>

                    <script type="text/javascript">
                        $(document).ready(function(){
                            $("#buttputih<?php echo $i.$aplh ?>").click(function(){
                                if (pilihkursi < 8) {
                                    $("#buttputih<?php echo $i.$aplh ?>").css("display","none");
                                    $("#buttbiru<?php echo $i.$aplh ?>").css("display","block");
                                    bookseats.push('<?php echo $i.$aplh ?>');
                                    console.log(bookseats);
                                    pilihkursi++;
                                    $("#jumlahseats").text(pilihkursi);
                                    hargakursi = pilihkursi * 30000;
                                    $("#totalkursi").text(hargakursi);    
                                }
                                console.log(pilihkursi);
                                
                            })
                            $("#buttbiru<?php echo $i.$aplh ?>").click(function(){
                                $("#buttputih<?php echo $i.$aplh ?>").css("display","block");
                                $("#buttbiru<?php echo $i.$aplh ?>").css("display","none");
                                i = 0;
                                while (bookseats[i] != "<?php echo $i.$aplh?>") {
                                    console.log(bookseats[i]);
                                    i++;
                                }
                                // console.log(bookseats[1]);
                                bookseats.splice(i,1);
                                console.log(bookseats);
                                pilihkursi--;
                                $("#jumlahseats").text(pilihkursi);
                                hargakursi = pilihkursi * 30000;
                                $("#totalkursi").text(hargakursi);
                            })
                        })
                    </script>
                <?php
                    } 
                ?>
            </div>
        </div>
        <div style="width: 130px">
            
        </div>
        <div>
            <div class="row justify-content-md-center">
                <?php
                    for ($i=14; $i < 18; $i++) { 
                ?>
                    <div id="buttputih<?php echo $i.$aplh ?>" style="margin-right: 10px;margin-left: 10px;display: block; padding-left: 0px;">
                        <button class="kursi_putih"><?php echo $i.$aplh; ?></button>
                    </div>
                    <div id="buttbiru<?php echo $i.$aplh ?>" style="margin-right: 10px;margin-left: 10px;display: none;color: white; padding-left: 0px;">
                        <button class="kursi_biru"><b><?php echo $i.$aplh; ?></b></button>
                    </div>
                    <div id="butthitam<?php echo $i.$aplh ?>" style="margin-right: 10px;margin-left: 10px;display: none;color: white; padding-left: 0px;" >
                        <button class="kursi_hitam"><b><?php echo $i.$aplh; ?></b></button>
                    </div>

                    <script type="text/javascript">
                        $(document).ready(function(){
                            $("#buttputih<?php echo $i.$aplh ?>").click(function(){
                                if (pilihkursi < 8) {
                                    $("#buttputih<?php echo $i.$aplh ?>").css("display","none");
                                    $("#buttbiru<?php echo $i.$aplh ?>").css("display","block");
                                    bookseats.push('<?php echo $i.$aplh ?>');
                                    console.log(bookseats);
                                    pilihkursi++;
                                    $("#jumlahseats").text(pilihkursi);
                                    hargakursi = pilihkursi * 30000;
                                    $("#totalkursi").text(hargakursi);    
                                }
                                console.log(pilihkursi);
                                
                            })
                            $("#buttbiru<?php echo $i.$aplh ?>").click(function(){
                                $("#buttputih<?php echo $i.$aplh ?>").css("display","block");
                                $("#buttbiru<?php echo $i.$aplh ?>").css("display","none");
                                i = 0;
                                while (bookseats[i] != "<?php echo $i.$aplh?>") {
                                    console.log(bookseats[i]);
                                    i++;
                                }
                                // console.log(bookseats[1]);
                                bookseats.splice(i,1);
                                console.log(bookseats);
                                pilihkursi--;
                                $("#jumlahseats").text(pilihkursi);
                                hargakursi = pilihkursi * 30000;
                                $("#totalkursi").text(hargakursi);
                            })
                        })
                    </script>
                <?php
                    } 
                ?>
            </div>
        </div>
        <div style="color: white; font-weight: bold; padding-top: 17px; padding-left: 25px;">
            <?php echo $aplh?>
        </div>
    </div>
    <?php
        }
    ?>
    </center>

    <?php 
        foreach ($kursi as $row){
    ?>
        <script type="text/javascript">
            data = "<?php echo $row['kursi'] ?>";
            kursi = data.split(",");
            for (var i = 0; i < kursi.length; i++) {
                console.log(kursi[i]);
                $("#butthitam"+kursi[i]).css("display","block");
                $("#buttputih"+kursi[i]).css("display","none");
                $("#buttbiru"+kursi[i]).css("display","none");
            }
        </script>
    <?php
        }
    ?>

    <?php
        if (empty($kursi_prev)==false) {
    ?>
        <script type="text/javascript">
            data = "<?php echo $kursi_prev?>";
            kursi = data.split(",");
            for (var i = 0; i < kursi.length; i++) {
                $("#butthitam"+kursi[i]).css("display","none");
                $("#buttputih"+kursi[i]).css("display","none");
                $("#buttbiru"+kursi[i]).css("display","block");
                bookseats.push(kursi[i]);
                pilihkursi++;
                $("#jumlahseats").text(pilihkursi);
                hargakursi = pilihkursi * 30000;
                $("#totalkursi").text(hargakursi);
            }
        </script>
    <?php
        }
    ?>
    <center>
        <div style="width: 1500px;background-color: #002850;color: white;margin-top: 150px;border-radius: 15px;" class="layar">
            <h3><b>LAYAR</b></h3>
        </div>
    </center>
</div>

<div style="background-color: #000B18; margin-top: 100px; padding: 20px; color: white">
    <center>
        Silverlight 2019
    </center>
</div>


