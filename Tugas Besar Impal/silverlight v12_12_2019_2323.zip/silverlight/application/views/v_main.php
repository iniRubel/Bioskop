<!DOCTYPE html>
<html lang="en">
     <head>
          <!-- Required meta tags -->
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

          <!-- Bootstrap CSS -->
          <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>other/css/bootstrap.min.css">
          <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>other/css/style.css">
          <link rel="stylesheet" href="<?php echo base_url() ?>other/plugin/daterangepicker/daterangepicker.css">
          <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>

          <title>Silverlight</title>
     </head>
     <body>

          <!-- Optional JavaScript -->
          <!-- jQuery first, then Popper.js, then Bootstrap JS -->
          <script src="<?php echo base_url() ?>other/js/jquery-3.4.0.js"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
          <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
          <script src="<?php echo base_url() ?>other/plugin/daterangepicker/moment.min.js"></script>
          <script src="<?php echo base_url() ?>other/plugin/daterangepicker/daterangepicker.js"></script>
     </body>
</html>