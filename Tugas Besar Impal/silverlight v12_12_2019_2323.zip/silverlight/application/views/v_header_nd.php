<div class="container-fluid navigation" style="position: fixed; z-index: 9999; top: 0; ">
	<div class="row justify-content-between">

		<div class="col-auto" style="margin-top: auto; margin-bottom: auto">
			<div class="row">
				<div class="col-auto" style="padding-right: 0px; margin-right: 50px;">
					<a href="<?php echo base_url() ?>home">
						<img style="height: 53px" src="<?php echo base_url()?>other/asset/icon/logo.svg" alt="">	
					</a>
				</div>
				<div class="col-auto" style="margin-top: auto; margin-bottom: auto; padding-left: 0px">
					<a href="" class="linknav">Film</a>
					<a href="" class="linknav">Bioskop</a>	
				</div>	
			</div>
		</div>

		<div class="col-auto" style="margin-top: auto; margin-bottom: auto;">
			<div class="row">
				<div class="col-auto" style='margin-top: auto; margin-bottom: auto; padding-right: 0px;
				<?php
					if($this->session->userdata('status') == "login" and $this->session->userdata('type') == "users"){
						echo "display: none;";
					} else {
						echo "display: block;";
					}
				?>'>
					<a href="<?php echo base_url() ?>users/signup/" class="linknav">Sign Up</a>
					<a href="<?php echo base_url() ?>users/signin/" class="linknav">Sign In</a>	
				</div>
				<div class="col-auto" style='margin-top: auto; margin-bottom: auto; padding-right: 0px;
				<?php
					if($this->session->userdata('status') == "login" and $this->session->userdata('type') == "users"){
						echo "display: block;";
					} else {
						echo "display: none;";
					}
				?>'>
					<a href="<?php echo base_url() ?>users/signout/" class="linknav">Sign Out</a>	
				</div>
				<div class="col-auto" style='padding-left: 0px;<?php
					if($this->session->userdata('status') == "login" and $this->session->userdata('type') == "users"){
						echo "display: block;";
					} else {
						echo "display: none;";
					}
				?>'>
					<a href="<?php echo base_url().'tiket/lihat_tiket/'.$this->session->userdata('nohp') ?>" class="linknav"><button type="button tombol" class="btn btn-primary tombol" style="width: 100%"><?php echo $this->session->userdata('email')?></button></a>
				</div>
				<form>
					<div style="display: none;">
						<input id="formjudulfilm" type="text" name="judulfilm">
						<input id="formnamabioskop" type="text" name="namabioskop">
						<input id="formharitanggal" type="text" name="haritanggal">
						<input id="formjam" type="text" name="jam">
						<input id="formalamat" type="text" name="alamat">
					</div>
				</form>
			</div>
		</div>
		
	</div>
</div>