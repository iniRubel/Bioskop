        <div class="col-10 dashboard-right" style="margin-left: 300px;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-10">
                        <div style="display: flex;">
                            <div class="accessories" style="height: 100px;"><p></p></div>
                            <h1 class="heading1" style="font-size: 80px"><a style="color: white" href="<?php echo base_url()?>admin/admin_Makmin">Makmin</a> > <span style="color: #007bff"><?php echo $data['nama_makmin'] ?></span></h1> 
                        </div> 
                    </div>
                </div>

                <div class="row">
                    <?php  
                        if (empty($this->session->flashdata('update'))==false) {
                            echo "
                                <div class='col-12 alert alert-success' role='alert' style='margin-bottom: 40px;'>
                                    ".$this->session->flashdata('update')."
                                </div>
                            ";
                        }
                        if (empty($this->session->flashdata('error'))==false) {
                            echo "
                                <div class='col-12 alert alert-danger' role='alert' style='margin-bottom: 40px;'>
                                    ".$this->session->flashdata('error')."
                                </div>
                            ";
                        }
                    ?>
                </div>

                <div class="row" style="margin-bottom: 40px;">
                    <div class="col-3">
                        <img class="makmin_list_img" src="<?php echo base_url()?>other/asset/makmin/<?php echo $data['id_makmin']?>.png" alt="">
                    </div>
                    <div class="col-9" style="padding-left: 60px">
                        <div class="row" style="margin-bottom: 25px">
                            <span class="tulisan" style="font-weight: bold; font-size: 30px"><?php echo $data['nama_makmin']?></span>
                        </div>
                        <div class="row" style="margin-bottom: 25px">
                            <div>
                                <span class="tulisan" style="font-weight: bold;">Keterangan:</span><br>
                                <span class="tulisan"><?php echo $data['keterangan']?></span>
                            </div>
                        </div>
                        <div class="row" style="margin-bottom: 25px">
                            <div>
                                <span class="tulisan" style="font-weight: bold;">Harga: </span><br>
                                <span class="tulisan"><?php echo $data['harga']?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 film_list">
                        <div class="row">
                            <div class="col-2">
                                <a href="<?php echo base_url() ?>admin/edit_makmin/<?php echo $data['id_makmin']?>">
                                <button type="button" class="btn btn-primary" style="width: 100%; height: 100%; border-radius: 1rem; padding: 20px"> 
                                    <div>
                                        <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/edit.svg">    
                                    </div> 
                                    <b>Edit Makmin</b>
                                </button>
                                </a>   
                            </div>
                            <div class="col-2">
                                <button id="tambah_theater_button" type="button" class="btn btn-danger" style="width: 100%; height: 100%; border-radius: 1rem; padding: 20px" onclick="hapus_makmin()"> 
                                    <div>
                                        <img style="width: 15%;" src="<?php echo base_url()?>other/asset/icon/delete.svg">
                                    </div> 
                                    <b>Hapus Makmin</b>
                                </button>
                            </div>


                            
                            <div id="hapusMakmin" class="col-12" style=";margin-top: 25px; padding: 45px 45px 0px 45px">
                                <div style="display: flex;">
                                    <div class="accessories" style="background-color: #DC3545;"><p></p></div>
                                    <h1 class="heading1">Hapus Bioskop - <span style="color: grey"><?php echo $data['nama_makmin']?></span></h1>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        Menghapus Makanan/Minuman akan juga menghapus <span style="font-weight: bold">seluruh data</span> yang berkaitan dengan Makanan/Minuman ini dari Database.<br>
                                        Apakah anda yakin ingin <span style="font-weight: bold">menghapus Makanan/Minuman</span> ini?<br><br>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-2">
                                        <form action="<?php echo base_url().'makmin/hapus/'.$data['id_makmin'];?>" method="post">
                                            <div class="form_contain" style="width: 300px">
                                                <input type="checkbox" name="terms" value="yes" required style="margin-right: 12px;">Ya, hapus Makanan/Minuman ini
                                            </div>
                                            <div class="form_contain" style="width: 300px">
                                                <button type="submit" class="btn btn-danger tombol">Hapus Makanan/Minuman</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <script>
                                var y = document.getElementById("hapusMakmin");
                                y.style.display = "none";

                                function hapus_makmin() {
                                    if (y.style.display === "none") {
                                        y.style.display = "block";
                                    } else {
                                        y.style.display = "none";
                                    }
                                } 
                            </script>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>

   
</div>