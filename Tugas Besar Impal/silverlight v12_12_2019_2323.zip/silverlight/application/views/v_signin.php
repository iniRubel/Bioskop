<div style="background-image: url('<?php echo base_url()?>other/asset/latar/page2.png'); background-size: cover; background-repeat: repeat-y; background-position: 50% 10px; background-size: 1850px;">

<div class="container-fluid contain" style="margin-top: 90px;">
	<div class="row">
		<div class="col-12">
			<div style="display: flex;">
				<div class="accessories"><p></p></div>
				<h1 class="heading1">Sign In</h1>	
			</div>	
		</div>
	</div>
	<div class="row">
		<div class="col-md-4" style="padding-right: 27px;">
			<?php  
				if (empty($this->session->flashdata('update'))==false) {
                    echo "
                        <div class='col-12 alert alert-success' role='alert' style='margin-bottom: 40px;'>
                                    ".$this->session->flashdata('update')."
                        </div>
                    ";
                }
                if (empty($this->session->flashdata('error'))==false) {
                    echo "
                        <div class='col-12 alert alert-danger' role='alert' style='margin-bottom: 40px;'>
                            ".$this->session->flashdata('error')."
                        </div>
                    ";
                }
            ?>
			<div class="sign_box">
				<form action="<?php echo base_url(). 'users/masuk';?>" style="padding-bottom: 15px;" method="post">
					<div class="form_contain">
						Email
						<input type="email" name="email" required class="form-control form-rounded">	
					</div>
					<div class="form_contain">
						Sandi
						<input minlength="8" type="password" name="sandi" required class="form-control form-rounded">
						<div style="text-align: right; color: #0069d9; margin-top: 20px;">
							Lupa Sandi?
						</div>
					</div>
					<div class="form_contain">
						<button type="submit" class="btn btn-primary tombol">Sign In</button>
					</div>
				</form>
				<div style="text-align: center;">
					Belum punya akun ? <a style="color: #0069d9" href="<?php echo base_url() ?>users/signup/">Sign Up Here</a>
				</div>
			</div>
		</div>
		<div class="col-md-8" style="padding-left: 27px;">
			<div style="background-color: gray; height: 650px; border-radius: 2rem">
				
			</div>
		</div>
	</div>


</div>