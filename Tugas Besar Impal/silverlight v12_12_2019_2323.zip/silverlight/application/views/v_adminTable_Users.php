<div class="col-10 dashboard-right" style="margin-left: 300px;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-10">
                        <div style="display: flex;">
                            <div class="accessories" style="height: 100px;"><p></p></div>
                            <h1 class="heading1" style="font-size: 80px">Users</h1> 
                        </div> 
                    </div>
                </div>

                <div class="row">
                    <?php  
                        if (empty($this->session->flashdata('update'))==false) {
                            echo "
                                <div class='col-12 alert alert-success' role='alert' style='margin-bottom: 40px;'>
                                    ".$this->session->flashdata('update')."
                                </div>
                            ";
                        }
                    ?>
                    <div class="col-lg-12">
                        <form style="width: 900px; padding-left: 15px;"  class="example" action="<?php echo base_url().'admin/cari_user/'; ?>" style="margin:auto; max-width:900px" method="get">
                            <div class="row">
                                <div class="col-4" style="padding:0px;">
                                    <input style="width: 100%" type="text" placeholder="Cari Users" name="scTabMakmin">    
                                </div>
                                <div class="col-1" style="padding:0px;">
                                    <button type="submit" style="width: 100%">
                                        <img style="width: 20px" src="<?php echo base_url()?>other/asset/icon/search.svg">
                                    </button>
                                </div>
                            </div>       
                        </form>
                    </div>
                    <div class="col-lg-5">
                        <p style="color: white;margin: 15px 0px 30px 0px">
                            <?php 
                                if ($search!='') {
                                    echo "Hasil pencarian: ". $search; 
                                }
                            ?>
                        </p>
                        <div class="row">
                            <table class="table table-dark table-striped">
                                <thead>
                                    <tr>
                                        <th style="width: 20px;">image</th>
                                        <th style="width: 300px;">Email</th>
                                        <th style="width: 200px;">Nomor Hp</th>
                                    </tr>
                                </thead>
                                 <tbody>
                                    <?php 
                                        foreach ($list as $row){
                                    ?>
                                        <tr>
                                            <td><img style="width: 90%" src="<?php echo base_url()?>other/asset/icon/user.svg"></td>
                                            <td ><?php echo $row['email']?></td>
                                            <td ><?php echo $row['nohp']?></td>
                                        </tr>
                                    <?php } ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>