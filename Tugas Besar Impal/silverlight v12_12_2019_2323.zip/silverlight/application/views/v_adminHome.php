        <div class="col-10 dashboard-right" style="margin-left: 300px;">
            <div class="row justify-content-between">
                <div class="col dashboard-rightPanel">
                    <div class="row" style="margin-top: 20px; margin-bottom: 20px;">
                        <div class="col-3">
                            <img  style="width: 100%" src="<?php echo base_url()?>other/asset/icon/film.svg" alt="">
                        </div>
                        <div class="col-9">
                            <span style="font-size: 25px; font-weight: bold; color: white">Jumlah Film<br></span>
                            <span style="font-size: 50px;font-weight: bold; color: #314252;"><?php echo $countFilm?></span>
                        </div>
                    </div>
                </div>
                <div class="col dashboard-rightPanel">
                    <div class="row" style="margin-top: 20px; margin-bottom: 20px;">
                        <div class="col-3">
                            <img  style="width: 100%" src="<?php echo base_url()?>other/asset/icon/makmin.svg" alt="">
                        </div>
                        <div class="col-9">
                            <span style="font-size: 25px; font-weight: bold; color: white">Jumlah Mak-Min<br></span>
                            <span style="font-size: 50px;font-weight: bold; color: #314252;"><?php echo $countMakmin?></span>
                        </div>
                    </div>
                </div>
                <div class="col dashboard-rightPanel">
                    <div class="row" style="margin-top: 20px; margin-bottom: 20px;">
                        <div class="col-3">
                            <img  style="width: 100%" src="<?php echo base_url()?>other/asset/icon/bioskop.svg" alt="">
                        </div>
                        <div class="col-9">
                            <span style="font-size: 25px; font-weight: bold; color: white">Jumlah Bioskop<br></span>
                            <span style="font-size: 50px;font-weight: bold; color: #314252;"><?php echo $countBioskop?></span>
                        </div>
                    </div>
                </div>
                <div class="col dashboard-rightPanel">
                    <div class="row" style="margin-top: 20px; margin-bottom: 20px;">
                        <div class="col-3">
                            <img  style="width: 100%" src="<?php echo base_url()?>other/asset/icon/user.svg" alt="">
                        </div>
                        <div class="col-9">
                            <span style="font-size: 25px; font-weight: bold; color: white">Jumlah User<br></span>
                            <span style="font-size: 50px;font-weight: bold; color: #314252;"><?php echo $countUsers?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
</div>